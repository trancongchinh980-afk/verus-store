# Trạng thái chức năng V6 (phân loại trung thực)

Chú giải: ✅ Hoàn thành và đã kiểm thử · 🟡 Đã viết, **chưa chạy thử trên Supabase thật** · 🎭 Chỉ mô phỏng · ⬜ Chưa triển khai · 🔌 Cần dịch vụ ngoài

## Giao diện & trải nghiệm
| Chức năng | Trạng thái | Ghi chú |
|---|---|---|
| Giữ nguyên giao diện/chức năng V5.0 (DEMO) | ✅ | Chạy lại trên 390px, không lỗi console |
| Outfit Builder (xem bộ, đổi món, chọn size, thêm cả bộ, tổng giá) | ✅ DEMO · 🟡 ONLINE | Bộ phối do admin tạo (Admin → Outfit) |
| Lọc theo phong cách (tag), tìm kiếm có trạng thái rỗng | ✅ | |
| Tư vấn size theo cao/nặng, gợi ý phối, hoàn cảnh | ✅ | Chỉ hiện khi sản phẩm có dữ liệu thật |
| Câu chuyện thương hiệu + lợi ích (không số liệu bịa) | ✅ | |
| Đánh giá từ người mua đã xác thực (hiển thị) | ✅ qua giả lập · 🟡 | Xác minh mua hàng nằm ở SQL |
| Thư viện video, phóng to ảnh | ⬜ | Video qua URL có từ V5 |
## Backend & bảo mật
| Chức năng | Trạng thái |
|---|---|
| Schema, ràng buộc, trigger, sổ cái chỉ-thêm | 🟡 |
| RLS + khóa quyền cột + phân quyền admin/staff/customer | 🟡 (kèm `tests.sql` để bạn tự kiểm) |
| Đặt hàng qua RPC (giá/tồn/voucher/điểm/cọc tính ở server) | 🟡 · phần gọi từ frontend ✅ (giả lập) |
| Khách chưa đăng nhập bị yêu cầu đăng nhập khi đặt hàng | ✅ |
| Đơn hiện ngay trên thiết bị admin khác | 🟡 (cần Supabase thật) |
| Tra cứu đơn bằng mã + SĐT | ✅ qua giả lập · 🟡 |
## Vận hành
| Chức năng | Trạng thái |
|---|---|
| Quy trình 1688: xác nhận → cọc 20% → đặt NCC → ETA +15 ngày | 🟡 |
| Đối soát cọc/COD thủ công, từ chối, hoàn tiền | 🟡 |
| Ví (sổ cái), yêu cầu rút tiền → duyệt → "đã chuyển thủ công" | 🟡 · 🎭 không chuyển tiền thật |
| Vận chuyển thủ công (hãng + mã vận đơn) | 🟡 · API vận chuyển 🔌 |
| QR chuyển khoản / xác minh ngân hàng tự động | 🔌 (chưa có) |
| Admin: Tổng quan, Đơn, Đối soát, Ví, Sản phẩm (nhanh+nâng cao), Voucher, VIP, Outfit, Đánh giá, Chat, CRM, Nhật ký, Phân quyền | 🟡 · mở/đăng nhập/đơn/đổi trạng thái ✅ (giả lập) |
## Giữ chân
| Chức năng | Trạng thái |
|---|---|
| Tài khoản, hồ sơ, địa chỉ nhận hàng, lịch sử đơn, yêu thích | 🟡 |
| Điểm thưởng (tích khi đã giao + thu đủ; đổi ở checkout, trần 30%) | 🟡 |
| VIP Hybrid (hạng 12 tháng + cột mốc cao nhất; ngưỡng chỉnh được) | 🟡 · ngưỡng là GIẢ ĐỊNH |
| Mã giới thiệu + thưởng sau đơn đầu hoàn tất | 🟡 |
| CRM: 6 nhóm khách, đồng ý nhận tin, giới hạn 1 tin/7 ngày | 🟡 · gửi thật 🔌 |
| Chat/khiếu nại (không thời gian thực) | 🟡 |
| Nhiệm vụ thành viên, quà sinh nhật tự động | ⬜ |
| Theo dõi sự kiện (view/search/wishlist/cart/checkout; purchase/refund do server ghi) | 🟡 |
## Chưa làm / hạn chế đã biết
Tải ảnh/video lên (dùng URL), thao tác hàng loạt, phân trang (hiện giới hạn 200 đơn), thông báo đẩy, đa ngôn ngữ, SEO nâng cao, kiểm thử Android thật, kiểm thử mạng chậm.
