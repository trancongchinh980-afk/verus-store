# Báo cáo kiểm thử V6 — chỉ ghi những gì đã thực sự chạy

## Đã chạy (Chromium headless, viewport 390×844)
**A. Kiểm toán V5.0** (trước khi sửa): ~40 kiểm tra duyệt/giỏ/checkout/tra cứu/admin/giả mạo dữ liệu. Phát hiện: đơn không rời khỏi trình duyệt, admin không có đăng nhập, sửa giá/số dư bằng console được chấp nhận, XSS tên khách đã được chặn. (Bảng đầy đủ trong tin nhắn kiểm toán.)

**B. `tests/demo_test.py` — chế độ DEMO** → 0 lỗi console, kết quả đạt:
nhãn DEMO · 4 sản phẩm hiển thị · Outfit Builder mở 3 món, **chặn thêm giỏ khi chưa chọn size**, thêm đủ 3 dòng sau khi chọn · phần mở rộng trang sản phẩm **còn nguyên sau khi đổi màu** · tư vấn size (168cm/60kg → M) · lọc phong cách · checkout DEMO V5 vẫn chạy · Tài khoản ở DEMO giải thích cần Supabase · Admin DEMO vẫn mở · không cuộn ngang.

**C. `tests/online_test.py` — chế độ ONLINE với Supabase GIẢ** (kiểm tra phần nối dây frontend, **không** kiểm tra SQL) → 0 lỗi, đạt:
danh mục lấy từ "server" (không lẫn dữ liệu demo) · voucher qua RPC xem trước (260.100₫) · `place_order` được gọi **1 lần** với payload **không có trường giá/tổng**, chỉ `variant_id,size,qty` + `idempotency key` · giỏ được dọn sau khi đặt · sự kiện view_product/add_to_cart/begin_checkout được gửi · Tài khoản hiện đơn + điểm · tra cứu đơn bằng mã+SĐT · **khách thường bị từ chối vào Admin** · khách chưa đăng nhập bị chuyển tới đăng nhập khi đặt hàng · admin mở được 13 tab, liệt kê đơn, gọi `admin_set_order_status`.

**D. `tools/v5_export_to_sql.py`** chạy trên dữ liệu V5 thật → sinh 16 dòng SQL hợp lệ về mặt cú pháp bằng mắt (chưa chạy trên Postgres).

**E. Kiểm tra tĩnh SQL**: cặp `$$` chẵn, ngoặc cân bằng, đã rà tay và sửa 3 lỗi tiềm ẩn (FORCE RLS làm hỏng hàm admin; `gen_random_bytes` nằm ngoài search_path; trigger chặn xóa tài khoản).

## CHƯA chạy — rủi ro lớn nhất
1. **Toàn bộ SQL (001–003, seed, tests) chưa được thực thi trên PostgreSQL/Supabase thật** (môi trường tôi không có Postgres, không có mạng). Có thể còn lỗi cú pháp hoặc ngữ nghĩa. Kiểm tra: chạy theo `docs/SETUP.md` rồi `supabase/tests.sql` (các dòng PASS/FAIL, gồm: giá server, cọc làm tròn, idempotency, chặn bán lố, voucher 1 lần, khách không sửa điểm/role/đơn/giá vốn/sổ cái, không gọi hàm admin, chặn đặt nhà cung cấp khi chưa xác nhận cọc, ETA +15 ngày, không nhảy cóc trạng thái, không rút/hoàn quá số).
2. `supabase-js` thật (tôi ghim `@2.45.4` qua jsDelivr nhưng không tải được để xác minh), đăng ký/đăng nhập thật, email xác nhận.
3. Thiết bị Android thật, mạng chậm, Safari/Firefox.
4. Tải đồng thời (khóa dòng tồn kho), hoàn tiền một phần, thưởng giới thiệu, thăng hạng VIP, rút tiền end-to-end, chat 2 chiều, duyệt đánh giá, CRM — **chỉ có mã, chưa chạy**.

## Rủi ro/hạn chế đã biết
- `events` cho phép `anon` ghi → có thể bị spam; cần CAPTCHA/giới hạn tần suất ở hạ tầng khi production.
- Đặt hàng **bắt buộc đăng nhập** (đánh đổi: giảm ma sát vs chống spam & đánh giá xác thực). Nếu muốn khách vãng lai, cần CAPTCHA + giới hạn riêng.
- Xóa biến thể trong Admin chưa hỗ trợ (chỉ thêm/sửa). Ảnh/video qua URL.
- "đã bán" ở trang sản phẩm luôn 0 (chưa tổng hợp từ đơn hoàn tất).
- Admin: `staff` xác nhận được thanh toán; chỉ `admin` hoàn tiền/rút tiền. Chưa tách người đề nghị–người duyệt rút tiền.
