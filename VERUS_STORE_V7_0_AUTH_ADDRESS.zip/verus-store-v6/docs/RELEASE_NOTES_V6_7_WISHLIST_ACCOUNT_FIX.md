# VERUS STORE V6.7 — Wishlist/account fix

## Fixed in source
- Replaced stale `readGuestWish` / `writeGuestWish` calls in customer-dashboard wishlist actions with the canonical `guestWishRead` / `guestWishWrite` helpers.
- Unified the mobile dock wishlist view with the shared `wishMarkup` renderer and added error feedback if loading fails.
- Kept the V6.5 customer dashboard, cart/order flow, and original files untouched; this release is a copy of the prior V6.6 project.

## Verification status
- `node --check js/backend.js` passes.
- Inline JavaScript syntax checks and ZIP integrity should be run on the packaged archive before release.
- Real browser interaction is not verified in this environment. Supabase login/Google OAuth and cross-device sync require valid Supabase configuration and provider redirect settings.
