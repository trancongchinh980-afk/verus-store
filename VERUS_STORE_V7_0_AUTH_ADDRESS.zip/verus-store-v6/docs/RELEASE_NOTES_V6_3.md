# VERUS STORE V6.3 — Customer account, wishlist & order history

## Fixed
- Customer account now opens in DEMO mode instead of only showing a login/configuration notice.
- DEMO account shows customer profile fields and all orders saved in the current browser, newest first.
- Each DEMO order has a direct tracking/detail view with item list, total, deposit, balance and status timeline. Customers do not need to copy an order code to find their own order.
- Customer profile name/phone is saved locally and prefilled from the most recently placed DEMO order.
- Wishlist now works locally in DEMO mode and persists in the same browser. Product heart buttons add/remove items; the wishlist page displays saved products and links to product details.
- Mobile bottom navigation opens wishlist directly in DEMO mode.
- Existing ONLINE/Supabase account, order and wishlist flows are retained.
- Existing admin order-management panel remains available: top navigation > Quản trị > Đơn hàng. Status changes are appended to the order history.

## Important limitations
- This ZIP still has blank Supabase credentials by default. DEMO orders, account profile and wishlist are stored only in the browser's localStorage. They do not sync to the shop owner or other customer devices and can be lost if browser data is cleared.
- The admin order panel in DEMO can only see orders created in that same browser. Do not use DEMO mode to accept real orders or money.
- To operate a real public TikTok-bio storefront, configure Supabase, run the migrations, test customer auth/RLS and order workflows, then deploy. Never expose the Supabase service_role key in frontend code.

## Validation
- `node --check js/backend.js`: PASS
- `node --check js/admin.js`: PASS
- Inline JavaScript syntax checks: PASS
- HTML duplicate-ID and browser end-to-end checks have not been rerun in this release. Real Supabase behavior has not been verified.
