# VERUS STORE V7.0 — Auth & Saved Addresses

## Changes
- Reworked authentication into separate Login and Create Account screens, with responsive branded layout, labeled inputs, password autocomplete, and a password-reset action.
- Google OAuth errors now show a clear hint when the Google provider is disabled in Supabase.
- Checkout can load a customer's saved addresses from `public.addresses`, autofill recipient/phone/province/ward/street, and offer to save/update the address after an order is successfully created.
- Existing SQL schema already includes `public.addresses` with owner-based RLS in `003_rls.sql`; the SQL setup/migrations must be run before this feature can persist data.

## External configuration still required
1. Supabase Dashboard → Authentication → Sign In / Providers → Google: enable Google and enter Google OAuth Client ID and Client Secret from Google Cloud Console.
2. Supabase Authentication → URL Configuration: set Site URL and add the actual hosted HTTPS domain to Redirect URLs.
3. Opening `index.html` directly through Android `content://` is not a valid production OAuth origin. Deploy the static site to an HTTPS host (e.g. Cloudflare Pages/Netlify) to test Google OAuth reliably.
4. Run the SQL migrations/schema before using accounts, saved addresses, wishlist sync, or orders.
5. Google OAuth was not verified against a live Google client in this environment. Database persistence and browser interactions must be tested after configuration.
