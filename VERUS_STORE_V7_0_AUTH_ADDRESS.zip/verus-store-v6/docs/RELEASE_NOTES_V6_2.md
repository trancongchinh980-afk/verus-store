# VERUS STORE V6.2 — Typography & spacing refinement

## Mục tiêu
Điều chỉnh theo ảnh kiểm tra trên điện thoại: chữ bớt dày đặc, phân cấp tiêu đề rõ hơn, tăng khoảng cách giữa các vùng và làm thẻ sản phẩm dễ quét thông tin.

## Thay đổi
- Tiêu đề chính và tiêu đề các khối nội dung ngắn được chuyển sang IN HOA có chọn lọc; đoạn mô tả và tên sản phẩm vẫn giữ kiểu chữ thường để dễ đọc.
- Giảm cỡ chữ tiêu đề lớn trên màn hình nhỏ, tăng line-height và khoảng cách trên/dưới.
- Tăng khoảng cách giữa thanh danh mục, ô tìm kiếm, bộ lọc và lưới sản phẩm.
- Chuẩn hóa thẻ sản phẩm: tỷ lệ ảnh 4:5, tên tối đa hai dòng, giá và thông tin phụ có khoảng cách riêng.
- Ảnh sản phẩm bị lỗi tải sẽ ẩn alt-text quá lớn và hiện nền thay thế VERUS STORE, tránh cảm giác chữ bị tràn/chồng lên ảnh.
- Giữ màu đen – trắng – đỏ, logo, chức năng và cấu trúc backend hiện có.

## Kiểm tra
- Đã kiểm tra cú pháp JavaScript inline và các tệp JS bằng Node.js.
- Đã kiểm tra HTML parse, ID trùng và ZIP integrity.
- Không tuyên bố đã kiểm thử E2E trên trình duyệt thật hoặc Supabase thật; các giới hạn V6.1 vẫn còn hiệu lực. Xem `TEST_REPORT.md` và `SETUP.md`.
