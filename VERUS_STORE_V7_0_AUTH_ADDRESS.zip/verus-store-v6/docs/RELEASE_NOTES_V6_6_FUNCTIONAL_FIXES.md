# VERUS STORE V6.6 — Fix điều hướng & yêu thích

## Đã chỉnh trong mã nguồn
- Thống nhất mục Yêu thích với danh sách khách lưu trong `localStorage` khi chưa đăng nhập; không còn đọc nhầm `db.wishlist` ở luồng cũ.
- Nút Yêu thích trên thanh điều hướng dưới mở danh sách dùng cùng nguồn dữ liệu với trái tim trên thẻ sản phẩm.
- Trái tim phản hồi trực quan: trạng thái đã thích chuyển sang tim đỏ, `aria-pressed`/nhãn trợ năng cập nhật; danh sách sản phẩm được render lại sau thao tác.
- Nút Tài khoản mở cửa sổ đăng nhập nếu chưa có phiên; khi đã đăng nhập sẽ mở dashboard khách hàng.
- Thêm nút đăng nhập Google bằng Supabase OAuth; khách lưu wishlist trước khi đăng nhập sẽ được thử đồng bộ sau khi OAuth trả về.

## Cần cấu hình trước khi dùng thật
- `config.js`: điền `SUPABASE_URL` và `SUPABASE_ANON_KEY`.
- Supabase Authentication: bật Google provider, cấu hình Google OAuth Client ID/Secret và thêm URL website vào Redirect URLs.
- Chạy các migration SQL và kiểm tra RLS trong `docs/SETUP.md`.

## Kiểm chứng
- `node --check js/backend.js`: PASS.
- Inline JavaScript trong `index.html`: kiểm tra cú pháp bằng Node.
- ZIP integrity: kiểm tra sau khi đóng gói.
- Chưa xác nhận tương tác trình duyệt thật vì môi trường này không có browser Playwright khả dụng; chưa kết nối Supabase thật nên đăng nhập, OAuth, đồng bộ wishlist, checkout và admin vẫn cần kiểm tra trên dự án đã cấu hình.
