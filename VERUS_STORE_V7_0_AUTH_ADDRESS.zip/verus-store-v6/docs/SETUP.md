# Hướng dẫn cài đặt Verus Store V6 (Supabase)

Tổng thời gian: ~20 phút. Chi phí: **0đ** với gói Free của Supabase (đủ để thử nghiệm và bán quy mô nhỏ; xem giới hạn ở cuối).
Tôi KHÔNG tự đăng ký dịch vụ, không triển khai công khai, không kết nối thanh toán thật. Các bước dưới đây là phần bạn phải tự làm.

## 0. Chạy thử DEMO (không cần Supabase)
```bash
cd verus-store-v6
python3 -m http.server 8080      # hoặc: npx serve .
# mở http://localhost:8080
```
`config.js` để trống → chế độ DEMO (nhãn vàng ở đầu trang). Dữ liệu chỉ nằm trong trình duyệt.

## 1. Tạo dự án Supabase
1. Vào https://supabase.com → New project (chọn vùng gần Việt Nam, ví dụ Singapore). Ghi nhớ mật khẩu database.
2. Authentication → Providers → Email: bật. Khuyến nghị bật "Confirm email" khi chạy thật (cần cấu hình SMTP; mặc định Supabase giới hạn rất ít email/giờ).
3. Authentication → URL Configuration: điền Site URL là địa chỉ web của bạn (khi chạy local: `http://localhost:8080`).
4. Để bật đăng nhập Google: Supabase → Authentication → Providers → Google, bật provider và điền Google OAuth Client ID/Secret lấy từ Google Cloud Console. Thêm URL website đang chạy vào Redirect URLs của Supabase (khi thử local, thêm `http://localhost:8080/**`). Sau đó kiểm tra lại luồng đăng nhập trên đúng domain triển khai. Google OAuth không thể hoạt động chỉ bằng cách sửa file web nếu chưa cấu hình provider/credential.

## 2. Nạp cơ sở dữ liệu (đúng thứ tự)
Supabase Dashboard → **SQL Editor** → New query, dán và Run lần lượt nội dung:
1. `supabase/migrations/001_schema.sql`
2. `supabase/migrations/002_functions.sql`
3. `supabase/migrations/003_rls.sql`
4. `supabase/seed.sql` (dữ liệu MẪU: VIP, cài đặt, sản phẩm minh họa, voucher VERUS10)

> **Quan trọng:** các file SQL này **chưa được chạy thử trên PostgreSQL thật** trong môi trường tôi làm việc (xem `docs/TEST_REPORT.md`). Nếu có lỗi cú pháp, dán thông báo lỗi cho tôi để sửa. Sau khi nạp, chạy bước 5.

## 3. Tạo tài khoản admin đầu tiên (bước BẮT BUỘC do bạn làm)
1. Mở web ở chế độ ONLINE (bước 4), bấm **Tài khoản → Đăng ký** bằng email của bạn.
2. Trong SQL Editor chạy (thay email):
```sql
update public.profiles set role = 'admin'
where id = (select id from auth.users where email = 'email-cua-ban@example.com');
```
Chỉ cách này (hoặc admin hiện tại dùng tab **Phân quyền**) mới nâng quyền được. Khách không thể tự nâng quyền: cột `role` bị khóa bằng quyền cột + RLS.

## 4. Kết nối web với Supabase
Supabase → Project Settings → API. Mở `config.js`, điền:
```js
SUPABASE_URL: 'https://your-project.supabase.co',
SUPABASE_ANON_KEY: 'sb_publishable_...'   // publishable key
```
- Chỉ dùng **anon public key**. **Không bao giờ** dán `service_role` key vào web.
- Tải lại trang: nhãn chuyển sang xanh "ONLINE".

## 5. Kiểm tra bảo mật (khuyến nghị làm ngay)
Dán `supabase/tests.sql` vào SQL Editor → Run → mở tab **Messages**, mọi dòng phải là `PASS`. Script chạy trong 1 transaction rồi ROLLBACK (không để lại dữ liệu). Nếu phần `insert into auth.users` báo thiếu cột, bổ sung cột theo phiên bản Supabase của bạn.
Sau đó tự kiểm tay: đăng ký tài khoản khách thứ hai, thử đặt hàng bằng điện thoại, và xem đơn xuất hiện trong Admin trên máy tính.

## 6. Nạp dữ liệu từ V5.0 (tùy chọn)
Trong Admin DEMO cũ bấm "Xuất dữ liệu" → file JSON, rồi:
```bash
python3 tools/v5_export_to_sql.py verus-store-v4-backup.json > migrate_products.sql
```
Chạy file kết quả trong SQL Editor. Chỉ chuyển sản phẩm/biến thể/tồn/voucher. **Đơn hàng và tài chính trong localStorage là dữ liệu DEMO nên cố ý không chuyển.**

## 7. Triển khai (khi bạn sẵn sàng; tôi không tự làm)
Web là file tĩnh: có thể đặt lên Cloudflare Pages / Netlify / GitHub Pages (miễn phí). Trước khi bán thật xem `docs/ARCHITECTURE.md` mục "Trước khi production".

## Giới hạn gói Free cần biết
- Dự án bị **tạm dừng nếu không hoạt động ~1 tuần** (phải bấm khôi phục).
- Không có sao lưu tự động theo ngày ở gói Free: hãy định kỳ xuất dữ liệu (Dashboard → Database → Backups / `pg_dump`).
- Giới hạn email xác nhận mặc định rất thấp → cấu hình SMTP riêng khi chạy thật.
- Kiểm tra lại giới hạn hiện hành trên trang giá của Supabase vì có thể đã thay đổi.
