# VERUS STORE — Chính sách cọc 30% bằng QR

## Quy tắc bắt buộc
- Tỷ lệ cọc mặc định: 30% giá trị đơn hàng cuối cùng sau giảm giá/voucher/điểm.
- Số dư còn lại: 70%.
- Làm tròn tiền cọc lên bội số 1.000 VND theo công thức hiện có trong `place_order`.
- Cọc bằng chuyển khoản ngân hàng qua QR. Nội dung chuyển khoản nên có mã đơn để đối soát.
- Khách có thể báo đã chuyển; trạng thái vẫn là chờ đối soát cho đến khi quản trị viên xác minh giao dịch thực tế.
- Quản trị viên chỉ xác nhận khi tiền đã vào tài khoản. Ảnh chụp màn hình không phải bằng chứng tự động.
- Không hiển thị nhà cung cấp, nguồn hàng, giá vốn hoặc quy trình mua hàng nội bộ trên giao diện khách hàng.

## Các vị trí đã cập nhật
- Giá trị mặc định trong storefront demo: 30%.
- Giá trị mặc định trong `place_order`: 30% nếu chưa có cấu hình trong `site_settings`.
- Seed `site_settings.deposit_percent`: 30%.
- Chính sách mua hàng mẫu: cọc 30% qua QR, xác minh thủ công, còn lại 70%.
- Thông báo khách hàng: không tuyên bố đã thanh toán trước khi shop đối soát.

## Cần cấu hình trước khi hiển thị QR ngân hàng thật
Chưa có thông tin ngân hàng của chủ shop trong dự án, vì vậy không được tự tạo QR giả hoặc dùng tài khoản minh họa. Cần nhập tên ngân hàng, số tài khoản, tên chủ tài khoản và kiểm tra QR thực tế. Sau đó mới nối QR động theo số tiền cọc và mã đơn. Không đưa thông tin đăng nhập ngân hàng hoặc mã OTP vào website.

## Áp dụng cho dự án Supabase đã tồn tại
`seed.sql` dùng `ON CONFLICT DO NOTHING`, nên chạy lại seed không ghi đè giá trị cũ. Nếu dự án đã được seed trước đây, chạy lệnh sau trong SQL Editor để chuyển cấu hình hiện tại sang 30%:

```sql
update public.site_settings
set value = '30'::jsonb
where key = 'deposit_percent';

update public.site_settings
set value = to_jsonb('Khách đặt hàng và thanh toán trước 30% giá trị đơn hàng bằng chuyển khoản QR sau khi shop xác nhận đơn. Shop kiểm tra giao dịch ngân hàng thủ công trước khi xác nhận đã nhận cọc. 70% còn lại thanh toán khi nhận hàng hoặc theo phương thức được hiển thị tại bước đặt hàng. Nếu sản phẩm không thể cung cấp, shop liên hệ khách để thống nhất phương án hoặc hoàn lại khoản tiền đã nhận.'::text)
where key = 'policy_text';
```
