# VERUS STORE V6.8 — Android direct-file fix

## Why V6.7 could still appear unchanged
The store UI and cart are implemented in inline scripts, while account/wishlist/auth functions were loaded from sibling files (`js/backend.js`, `js/admin.js`) and configuration from `config.js`. Opening `index.html` via an Android file manager `content://` URI can prevent relative sibling scripts from resolving. That leaves the homepage and cart usable while account/wishlist handlers are missing.

## Changes
- Embedded `config.js`, `js/backend.js`, and `js/admin.js` into `index.html` so those functions do not depend on relative file paths.
- Kept the Supabase CDN as an optional online dependency. DEMO mode does not require it.
- Added safer local-storage handling and an in-memory/database fallback for guest wishlist state.
- Kept the source JS files in the package for normal hosting/development.

## Test status
- JavaScript syntax checks and ZIP integrity checks are run for this release.
- No claim of Android device/browser interaction testing: the device is not directly accessible from this environment.
- Supabase login/Google OAuth and online sync still require real Supabase configuration and testing.
