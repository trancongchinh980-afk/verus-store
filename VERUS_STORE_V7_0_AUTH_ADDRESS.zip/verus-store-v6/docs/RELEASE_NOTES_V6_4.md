# VERUS STORE V6.4 — Customer account, wishlist and checkout guard

## Fixes
- Guest wishlist now works whether the storefront is in DEMO mode or ONLINE without a signed-in session. It stores multiple product IDs in a dedicated localStorage key and can be opened from the wishlist navigation.
- Favorite toggle now consistently adds/removes items; the guest list is merged into the signed-in account wishlist after authentication when possible.
- Account entry now opens a clear customer account view. In DEMO it shows locally saved profile, guest wishlist and any existing local demo order history, with an explicit server-setup notice. ONLINE guests see login/register entry and guest wishlist; signed-in customers continue to see their profile and server order history.
- Checkout is blocked in DEMO because no server account/order processing exists. ONLINE checkout requires an authenticated session. This prevents guest orders and false claims that demo orders reached the shop.
- Admin access is visible from the DEMO account view; ONLINE staff/admin users get an admin shortcut in their account view. Online admin route continues to enforce staff/admin role checks and server-side RLS/RPC authorization.
- Favorite button overlay and modal stacking adjusted for touch devices.

## Important deployment status
- `config.js` is still intentionally blank. Until the owner configures Supabase URL + anon public key and applies all SQL migrations, account registration, real orders, customer order history and centralized admin order management cannot operate across devices.
- DEMO admin is local-only and not secure. It is for preview/testing only and must not be used to accept real orders or payments.
- No real Supabase project, email delivery, payment provider, or production browser session was available for end-to-end verification in this environment.

## Checks performed
- `node --check` on `js/backend.js` and `js/admin.js`.
- `node --check` on all inline scripts extracted from `index.html`.
- HTML parse and duplicate-ID check.
- ZIP integrity check.

## VERUS STORE — chính sách cọc 30% qua QR
- Cố định tỷ lệ cọc storefront demo ở 30%; trang cài đặt không cho đổi tỷ lệ này.
- Cập nhật seed mặc định và fallback `place_order` lên 30%.
- Thêm migration `004_verus_deposit_30_qr.sql` để cập nhật cấu hình Supabase đã seed trước đó.
- Nội dung khách hàng giải thích chuyển khoản QR và shop xác minh thủ công; trạng thái không được tự chuyển thành đã thanh toán khi khách báo chuyển.
- Ẩn cách gọi nội bộ về nhà cung cấp/nguồn hàng khỏi các nhãn trạng thái khách hàng; admin vẫn giữ các trạng thái vận hành nội bộ.
- Chưa tạo QR ngân hàng thật vì dự án chưa có ngân hàng, số tài khoản và tên chủ tài khoản đã được xác nhận. Không dùng QR giả.
