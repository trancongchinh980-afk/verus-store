# VERUS STORE V6.5 — Customer Account Dashboard

## Changes
- Replaced the basic customer account modal with a responsive customer dashboard using the existing account entry point.
- Added sections for Overview, Orders, Wishlist, Profile, and VIP/Points.
- Added responsive layout rules for desktop and mobile.
- Added customer profile editing; DEMO mode saves the profile locally, while ONLINE mode updates the signed-in user's profile through Supabase.
- Added wishlist removal and links to product detail pages.
- Added order status summaries and links to existing order-detail / review flows.
- Clearly labels DEMO mode and warns that the current backend VIP RPC reports 12-month spend, not lifetime spend.

## Important limitations
- This update is a storefront/customer UI improvement, not a production launch certification.
- `config.js` still needs the shop's Supabase URL and anon public key for ONLINE mode.
- Google OAuth has not been implemented by this update.
- The existing VIP SQL still calculates spend over 12 months. Lifetime-spend rules and refund handling still need a separate backend/migration change before treating VIP totals as official.
- The app's existing schema/migrations have not been run against a live Supabase project as part of this UI update.

## Validation
- `node --check js/backend.js` passed.
- Inline JavaScript blocks in `index.html` passed syntax checks.
- A browser interaction test could not run in this environment because Chromium navigation was blocked by the execution environment; interactive ONLINE behavior remains unverified.
