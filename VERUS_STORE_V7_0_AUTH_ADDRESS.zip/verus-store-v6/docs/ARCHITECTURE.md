# Kiến trúc Verus Store V6

**Quyết định:** giữ nguyên giao diện V5.0 (HTML/CSS/JS thuần, 1 trang) và thêm lớp `js/backend.js` + `js/admin.js` nói chuyện với Supabase. Không viết lại bằng framework khác (lý do: giao diện V5.0 đã ổn, chi phí viết lại cao, ngân sách thấp). Ảnh hưởng: không có build step; đổi lại `index.html` vẫn là một file lớn.

```
Trình duyệt (index.html + js/*.js)  ──HTTPS──▶  Supabase
  • anon key (công khai)                           • Auth (email/mật khẩu)
  • JWT người dùng                                 • PostgREST (đọc bảng, qua RLS)
                                                   • RPC (SECURITY DEFINER: mọi thao tác tiền/đơn/điểm)
                                                   • PostgreSQL (ràng buộc, trigger, sổ cái chỉ-thêm)
```

## Nguyên tắc bảo mật
1. **Mặc định từ chối**: RLS bật trên mọi bảng; quyền bị thu hồi rồi cấp lại tối thiểu (`003_rls.sql`).
2. **Trình duyệt không ghi trực tiếp vào bảng nhạy cảm.** `orders`, `order_items`, `payments`, `ledger_entries`, `loyalty_ledger`, `referrals`, `reviews`, `coupon_redemptions` **không có policy ghi** → chỉ hàm RPC (chạy bằng quyền chủ sở hữu) mới ghi được.
3. **Server tính lại tất cả**: `place_order` nhận chỉ `variant_id, size, qty` + mã voucher + số điểm muốn dùng. Giá lấy từ `products.price`, tồn kho khóa dòng (`FOR UPDATE`) và trừ trong cùng giao dịch, voucher/điểm/cọc 20% tính ở server. Client không có đường gửi giá.
4. **Phân quyền admin ở server**: `is_staff()/is_admin()` đọc `profiles.role`; cột `role`, `points_balance`, `highest_tier` bị khóa với người dùng (`GRANT UPDATE` chỉ cho `full_name, phone, birthday, marketing_opt_in`).
5. **Tiền**: số dư = tổng `ledger_entries` (chỉ-thêm, trigger chặn UPDATE/DELETE). Ảnh chụp chuyển khoản **không** là bằng chứng; admin phải đối soát rồi bấm xác nhận. Rút tiền: không số tài khoản đầy đủ (chỉ 4 số cuối), không chuyển tiền thật.
6. **Giá vốn** ở bảng `product_costs` riêng (chỉ admin) → không bao giờ lộ qua API khách.
7. **Chống trùng**: `idem_key` (user_id, key) duy nhất; tối đa 5 đơn "chờ xác nhận"/khách; mã đơn ngẫu nhiên (khó đoán).
8. **XSS**: mọi chuỗi từ server đi qua `esc()`; mô tả sản phẩm qua `cleanHTML()`.

## Bảng chính
| Nhóm | Bảng |
|---|---|
| Tài khoản | `profiles`, `addresses`, `referrals` |
| Danh mục hàng | `categories`, `products`, `product_costs`, `product_variants`, `variant_sizes`, `outfits`, `outfit_items` |
| Bán hàng | `orders`, `order_items`, `order_events`, `coupons`, `coupon_redemptions` |
| Tiền | `payments`, `ledger_entries`, `withdrawal_requests` |
| Giữ chân | `vip_tiers`, `loyalty_ledger`, `reviews`, `wishlist`, `cart_snapshots`, `crm_outbox` |
| Hỗ trợ & dữ liệu | `chat_threads`, `chat_messages`, `events`, `audit_log`, `site_settings` |

## Luồng đơn hàng (đúng mô hình 1688)
`pending` → (shop xác nhận) `confirmed` → `sourcing` → *[cần cọc đã xác nhận]* `supplier_ordered` (ETA = ngày đó + 15) → `in_transit_vn` → `inspecting` → `shipping` → `delivered` (tạo khoản COD chờ đối soát) → admin xác nhận COD → cộng điểm, xét VIP, thưởng giới thiệu. Hết nguồn cung: hủy → hoàn tồn kho, voucher, điểm; admin hoàn cọc 100% qua `admin_refund`. Máy trạng thái nằm trong `admin_set_order_status` nên không thể nhảy cóc.

## VIP Hybrid
Hạng hoạt động = chi tiêu đủ điều kiện 12 tháng (đơn đã giao + thanh toán đủ − phần hoàn). `profiles.highest_tier` lưu cột mốc cao nhất. Ngưỡng ở `vip_tiers` (chỉnh trong Admin → VIP).

## Chuyển dữ liệu localStorage → backend
Xem `docs/SETUP.md` mục 6. Đơn/tiền/tài khoản localStorage là DEMO nên không chuyển; khách đăng ký lại trên Supabase Auth.

## Trước khi production (việc còn lại)
- Rà soát pháp lý chính sách đổi trả/hoàn tiền/dữ liệu cá nhân (Nghị định 13/2023 về bảo vệ dữ liệu cá nhân).
- Cấu hình SMTP; bật xác nhận email; cân nhắc CAPTCHA (Supabase Auth hỗ trợ Turnstile/hCaptcha) vì `anon` có thể ghi bảng `events` và đăng ký tài khoản.
- Thêm CSP/headers ở host tĩnh; giới hạn tần suất ở mức hạ tầng.
- Lịch sao lưu; kiểm thử tải; kiểm thử trên thiết bị Android thật.
- Tích hợp đối soát ngân hàng/QR, vận chuyển, email/Zalo nếu cần (hiện **không có**).
- Đổi đơn vị kiểm soát "tách người đề nghị và người duyệt rút tiền" nếu có ≥2 admin.
