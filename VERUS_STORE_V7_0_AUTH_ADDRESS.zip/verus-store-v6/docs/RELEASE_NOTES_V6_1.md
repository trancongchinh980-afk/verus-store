# VERUS STORE V6.1 — Customer storefront refresh

## Đã cập nhật
- Nhận diện giao diện đen / trắng / đỏ, wordmark VERUS và hero theo phong cách Gen Z streetwear.
- Header có ô tìm kiếm nhanh đồng bộ với tìm kiếm danh sách sản phẩm.
- Điều hướng mobile dạng dock: Trang chủ, Tìm kiếm, Yêu thích, Tài khoản, Giỏ hàng.
- Bổ sung lọc theo tên/SKU/danh mục/chất liệu/form/biến thể, khoảng giá, màu theo tên biến thể và tag phong cách.
- Thêm nút yêu thích trên thẻ sản phẩm (dùng cơ chế wishlist/Auth của backend hiện có).
- Làm mới thẻ sản phẩm, banner, khu vực dịch vụ, câu chuyện thương hiệu, modal và phần hiển thị Admin.
- Thêm metadata chia sẻ cơ bản (Open Graph), tiêu đề và màu thanh trình duyệt.
- Tôn trọng `prefers-reduced-motion` và bổ sung responsive cho điện thoại/tablet/desktop.
- Giữ nguyên các file SQL, RPC, RLS và luồng Admin/Backend của V6.0; không thay khóa Supabase.

## Kiểm tra đã thực hiện
- `node --check` cho toàn bộ script inline trong `index.html`: PASS.
- `node --check js/backend.js`: PASS.
- `node --check js/admin.js`: PASS.
- Parse HTML bằng BeautifulSoup: PASS; không có ID trùng lặp.
- Đã thử chạy kiểm thử trình duyệt Playwright nhưng môi trường thực thi chặn điều hướng Chromium (`ERR_BLOCKED_BY_ADMINISTRATOR`), vì vậy không ghi nhận đây là kiểm thử giao diện end-to-end thành công.

## Những điều chưa thể xác nhận / cần cấu hình trước khi bán thật
1. `config.js` vẫn để trống. Cần điền Supabase Project URL và anon public key của chủ shop.
2. Các migration SQL chưa được thực thi trên Supabase/PostgreSQL thật. Làm theo `docs/SETUP.md` và chạy `supabase/tests.sql`.
3. Email xác minh, OTP/SMS, email giao dịch cần cấu hình nhà cung cấp; SMS và email có thể phát sinh phí.
4. Chuyển khoản VietQR hiện là hướng dẫn/chờ Admin đối soát thủ công, không tự xác minh ngân hàng.
5. COD, vận chuyển và hoàn tiền vẫn cần thao tác thủ công của Admin; không có kết nối hãng vận chuyển/ngân hàng tự động.
6. Sản phẩm, giá, ảnh, size, voucher trong chế độ DEMO là dữ liệu mẫu. Thay bằng dữ liệu thật và số đo đã kiểm tra trước khi công khai.
7. Chưa có domain riêng; có thể thử nghiệm bằng URL miễn phí của nền tảng hosting tĩnh.

## Chạy thử
- Giải nén ZIP.
- Mở terminal tại thư mục `verus-store-v6`.
- Chạy `python3 -m http.server 8080`.
- Mở `http://localhost:8080`.
- Để `config.js` trống thì web ở DEMO; không nhận đơn/tiền thật.

## Bảo mật
Chỉ dùng Supabase `anon public key` ở frontend. Không đưa `service_role` key, mật khẩu database hoặc khóa bí mật vào `config.js` hay bất kỳ file frontend nào.
