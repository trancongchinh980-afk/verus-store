#!/usr/bin/env python3
"""Chuyển file sao lưu V5.0 (nút "Xuất dữ liệu" trong Admin DEMO) thành SQL để nạp vào Supabase.
Dùng:  python3 tools/v5_export_to_sql.py verus-store-v4-backup.json > migrate_products.sql
Chạy kết quả trong Supabase SQL Editor SAU 001-003.

CHỈ chuyển: sản phẩm, biến thể, size/tồn, giá vốn, voucher.
KHÔNG chuyển: đơn hàng, tài chính, tài khoản trong localStorage — đó là dữ liệu DEMO, không đáng tin
và không có người dùng thật tương ứng (tài khoản phải được khách tự đăng ký trên Supabase Auth).
"""
import json, sys, re, unicodedata

def slugify(t):
    t = unicodedata.normalize('NFD', t.replace('đ', 'd').replace('Đ', 'D'))
    t = ''.join(ch for ch in t if not unicodedata.combining(ch)).lower()
    return re.sub(r'[^a-z0-9]+', '-', t).strip('-') or 'cat'

def q(s):  # SQL string literal
    return "NULL" if s is None or s == "" else "'" + str(s).replace("'", "''") + "'"
def arr(xs):
    xs = [x for x in (xs or []) if x]
    return "ARRAY[" + ",".join(q(x) for x in xs) + "]::text[]" if xs else "'{}'::text[]"
def num(x, d=0):
    try: return str(int(float(x)))
    except Exception: return str(d)

def main(path):
    db = json.load(open(path, encoding="utf-8"))
    out = ["-- Sinh bởi tools/v5_export_to_sql.py. Kiểm tra kỹ trước khi chạy.", "begin;"]
    cats = sorted({p.get("category") or "Phụ kiện" for p in db.get("products", [])})
    for c in cats:
        out.append(f"insert into public.categories(name,slug) values ({q(c)},{q(slugify(c))}) on conflict do nothing;")
    costs = db.get("cost", {}) or {}
    for p in db.get("products", []):
        sku = p.get("sku") or p["id"]
        out.append(
            "insert into public.products(sku,name,category,badge,status,material,fit,care,delivery_note,description_html,price,compare_price) values "
            f"({q(sku)},{q(p['name'])},{q(p.get('category') or 'Phụ kiện')},{q(p.get('badge'))},"
            f"{q('active' if p.get('status') == 'active' else 'draft')},{q(p.get('material'))},{q(p.get('fit'))},{q(p.get('care'))},"
            f"{q(p.get('delivery'))},{q(p.get('description') or '')},{num(p.get('price'))},"
            f"{num(p['compare']) if p.get('compare') and float(p['compare']) > float(p.get('price') or 0) else 'NULL'}) "
            "on conflict (sku) do nothing;")
        c = costs.get(p["id"]) or {}
        if c:
            out.append(f"insert into public.product_costs(product_id,base_cost,extra_cost) select id,{num(c.get('base'))},{num(c.get('extra'))} from public.products where sku={q(sku)} on conflict do nothing;")
        for i, v in enumerate(p.get("variants", [])):
            vsku = v.get("sku") or f"{sku}-V{i+1}"
            out.append(
                "insert into public.product_variants(product_id,name,sku,image_urls,video_urls,sort) "
                f"select id,{q(v.get('name') or 'Mặc định')},{q(vsku)},{arr(v.get('images'))},{arr(v.get('videos'))},{i} from public.products where sku={q(sku)} on conflict (sku) do nothing;")
            for s in v.get("sizes", []):
                out.append(
                    "insert into public.variant_sizes(variant_id,size,stock) "
                    f"select id,{q(s['name'])},{max(0, int(float(s.get('stock') or 0)))} from public.product_variants where sku={q(vsku)} on conflict (variant_id,size) do nothing;")
    for c in db.get("coupons", []):
        kind = "percent" if c.get("kind") == "percent" else "fixed" if c.get("kind") == "fixed" else None
        if not kind:
            out.append(f"-- Bỏ qua voucher {c.get('code')} (loại '{c.get('kind')}' chưa hỗ trợ ở V6)"); continue
        out.append(
            "insert into public.coupons(code,name,kind,value,min_subtotal,max_discount,usage_limit,active) values "
            f"({q((c.get('code') or '').upper())},{q(c.get('name') or c.get('code'))},{q(kind)},{num(c.get('value'),1)},{num(c.get('min'))},"
            f"{num(c['max']) if c.get('max') else 'NULL'},{num(c['limit']) if c.get('limit') else 'NULL'},{'true' if c.get('active') else 'false'}) on conflict (code) do nothing;")
    out.append("commit;")
    print("\n".join(out))

if __name__ == "__main__":
    if len(sys.argv) != 2: sys.exit(__doc__)
    main(sys.argv[1])
