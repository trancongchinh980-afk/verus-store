-- =====================================================================
-- VERUS STORE V6 — seed.sql  (DỮ LIỆU MẪU / DEMO — thay bằng dữ liệu thật trước khi bán)
-- Ngưỡng VIP và quyền lợi là GIẢ ĐỊNH, chỉnh được trong Admin > VIP.
-- =====================================================================
insert into public.site_settings(key, value, is_public) values
  ('shop_name',            '"VERUS STORE"', true),
  ('deposit_percent',      '30', true),
  ('lead_days',            '15', true),
  ('earn_vnd_per_point',   '10000', true),   -- 1 điểm / 10.000đ (chưa nhân hệ số hạng)
  ('redeem_vnd_per_point', '500', true),     -- 1 điểm = 500đ khi dùng ở checkout
  ('max_redeem_percent',   '30', true),      -- tối đa 30% giá trị đơn
  ('referral_reward_points','100', true),
  ('target_profit_default','100000', false),
  ('policy_text', to_jsonb('Khách đặt hàng và thanh toán trước 30% giá trị đơn hàng bằng chuyển khoản QR sau khi shop xác nhận đơn. Shop kiểm tra giao dịch ngân hàng thủ công trước khi xác nhận đã nhận cọc. 70% còn lại thanh toán khi nhận hàng hoặc theo phương thức được hiển thị tại bước đặt hàng. Nếu sản phẩm không thể cung cấp, shop liên hệ khách để thống nhất phương án hoặc hoàn lại khoản tiền đã nhận.'::text), true)
on conflict (key) do nothing;

insert into public.vip_tiers(code, name, min_spend_12m, points_multiplier, perks, sort) values
  ('member','Member',0,1.00,'["Tích điểm mọi đơn","Mã giới thiệu bạn bè"]',1),
  ('silver','Silver',2000000,1.10,'["Voucher sinh nhật (giả định)","Điểm x1.1"]',2),
  ('gold','Gold',5000000,1.25,'["Ưu tiên xem bộ sưu tập mới","Điểm x1.25"]',3),
  ('diamond','Diamond',12000000,1.50,'["Chăm sóc ưu tiên","Điểm x1.5"]',4),
  ('royal','Royal',30000000,2.00,'["Quà theo hạng (giả định)","Điểm x2"]',5)
on conflict (code) do nothing;

insert into public.categories(name, slug, sort) values
 ('Áo','ao',1),('Áo khoác','ao-khoac',2),('Quần','quan',3),('Giày','giay',4),('Dép','dep',5),('Mũ','mu',6),('Phụ kiện','phu-kien',7)
on conflict (name) do nothing;

-- Sản phẩm mẫu (giữ nguyên dữ liệu V5.0; ảnh Unsplash chỉ là minh họa)
with p as (
  insert into public.products(sku,name,category,badge,status,material,fit,care,delivery_note,description_html,style_tags,occasion,styling_tips,size_chart,size_rules,price,compare_price,featured)
  values ('VS-SHORT-001','Quần short camo','Quần','NEW DROP','active','Polyester','Form rộng','Giặt nhẹ, lộn trái khi giặt','Đặt trước khoảng 15 ngày (dự kiến)',
   '<h3>Điểm nổi bật</h3><p>Thiết kế streetwear dễ phối cùng áo thun oversize và sneaker. Vui lòng kiểm tra bảng size và thông số thực tế trước khi đặt.</p><p><b>Lưu ý:</b> Đây là dữ liệu mẫu để minh họa. Hãy thay bằng số đo đã kiểm tra của sản phẩm thật.</p>',
   array['streetwear','casual'],'Đi chơi, cuối tuần','Phối cùng áo thun oversize và sneaker (gợi ý mẫu).',
   '[{"size":"S","waist":"70–76 cm","length":"42 cm"},{"size":"M","waist":"76–82 cm","length":"44 cm"},{"size":"L","waist":"82–88 cm","length":"46 cm"},{"size":"XL","waist":"88–94 cm","length":"48 cm"}]',
   '[{"h_min":155,"h_max":165,"w_min":45,"w_max":55,"size":"S"},{"h_min":160,"h_max":170,"w_min":55,"w_max":65,"size":"M"},{"h_min":165,"h_max":175,"w_min":65,"w_max":75,"size":"L"},{"h_min":170,"h_max":185,"w_min":75,"w_max":90,"size":"XL"}]',
   289000,359000,true) on conflict (sku) do nothing returning id),
c as (insert into public.product_costs(product_id, base_cost, extra_cost, target_profit) select id, 150000, 39000, 100000 from p returning product_id),
v as (
  insert into public.product_variants(product_id,name,sku,image_urls,sort)
  select id,'Camo xanh','VS-SHORT-001-GRN',array['https://images.unsplash.com/photo-1591195853828-11db59a44f6b?auto=format&fit=crop&w=900&q=85'],1 from p
  union all
  select id,'Đen','VS-SHORT-001-BLK',array['https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&w=900&q=85'],2 from p
  returning id, sku)
insert into public.variant_sizes(variant_id,size,stock)
select v.id, s.size, case when v.sku like '%GRN' then s.g else s.b end
from v cross join (values ('S',3,2),('M',4,2),('L',3,2),('XL',2,2)) as s(size,g,b);

insert into public.coupons(code,name,kind,value,min_subtotal,max_discount,usage_limit,per_user_limit,active)
values ('VERUS10','Ưu đãi khai trương','percent',10,200000,50000,100,1,true) on conflict (code) do nothing;

-- Outfit mẫu: tạo thêm trong Admin khi có đủ sản phẩm

-- ---- Sản phẩm MINH HỌA để thử Outfit Builder (ảnh trống → giao diện hiển thị ảnh minh họa). XÓA khi có hàng thật. ----
with p as (
  insert into public.products(sku,name,category,badge,status,material,fit,delivery_note,description_html,style_tags,price)
  values
   ('DEMO-TEE-001','Áo thun oversize (mẫu minh họa)','Áo','DEMO','active','Dữ liệu minh họa','Oversize','Đặt trước khoảng 15 ngày (dự kiến)','<p>Sản phẩm minh họa để thử Outfit Builder.</p>',array['streetwear','casual'],219000),
   ('DEMO-SNK-001','Sneaker trắng (mẫu minh họa)','Giày','DEMO','active','Dữ liệu minh họa',null,'Đặt trước khoảng 15 ngày (dự kiến)','<p>Sản phẩm minh họa.</p>',array['streetwear'],549000),
   ('DEMO-CAP-001','Mũ lưỡi trai (mẫu minh họa)','Mũ','DEMO','active','Dữ liệu minh họa',null,'Đặt trước khoảng 15 ngày (dự kiến)','<p>Sản phẩm minh họa.</p>',array['casual'],149000)
  on conflict (sku) do nothing returning id, sku),
v as (
  insert into public.product_variants(product_id,name,sku,sort)
  select id, case sku when 'DEMO-TEE-001' then 'Trắng' when 'DEMO-SNK-001' then 'Trắng' else 'Đen' end, sku || '-V1', 1 from p returning id, sku)
insert into public.variant_sizes(variant_id,size,stock)
select v.id, s.size, 3 from v join lateral (select unnest(case when v.sku like 'DEMO-SNK%' then array['40','41','42'] when v.sku like 'DEMO-CAP%' then array['Free'] else array['M','L','XL'] end) as size) s on true;

with o as (insert into public.outfits(title,description,style_tag) values ('Street Weekend (minh họa)','Quần camo + áo thun + sneaker. Dữ liệu minh họa.','streetwear') returning id)
insert into public.outfit_items(outfit_id,product_id,sort)
select o.id, p.id, row_number() over () from o, public.products p where p.sku in ('VS-SHORT-001','DEMO-TEE-001','DEMO-SNK-001');
