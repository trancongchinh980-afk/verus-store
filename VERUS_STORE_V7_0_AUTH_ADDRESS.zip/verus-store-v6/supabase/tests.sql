-- =====================================================================
-- VERUS STORE V6 — tests.sql
-- Chạy SAU 001-003 + seed trong Supabase SQL Editor. Toàn bộ chạy trong 1 transaction và ROLLBACK
-- => không để lại dữ liệu. Mỗi dòng 'PASS/FAIL' hiện trong tab Messages (RAISE NOTICE).
-- Giả lập đăng nhập bằng set_config('request.jwt.claims', ...) + role authenticated.
-- =====================================================================
begin;
do $$
declare
  cust uuid := '00000000-0000-0000-0000-0000000000c1';
  adm  uuid := '00000000-0000-0000-0000-0000000000a1';
  vid uuid; res jsonb; oid uuid; pid uuid; ok boolean; n int; msg text;
  procedure_ok boolean;
begin
  insert into auth.users(id, instance_id, aud, role, email, raw_user_meta_data, created_at, updated_at)
    values (cust, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'cust@test.local', '{"full_name":"Khach Test"}', now(), now()),
           (adm,  '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'adm@test.local',  '{"full_name":"Admin Test"}', now(), now());
  update public.profiles set role = 'admin' where id = adm;
  select v.id into vid from public.product_variants v where v.sku = 'VS-SHORT-001-GRN';

  -- ===== KHÁCH =====
  perform set_config('request.jwt.claims', json_build_object('sub', cust, 'role', 'authenticated')::text, true);
  set local role authenticated;

  -- T1: khách đặt hàng, server tự tính giá (client gửi giá bậy cũng vô hiệu vì RPC không nhận giá)
  res := public.place_order(jsonb_build_array(jsonb_build_object('variant_id', vid, 'size', 'M', 'qty', 1)),
          'Khach Test', '0901234567', 'An Giang', 'Phường Bình Đức', '12 Duong A', null, 'cod_balance', 'VERUS10', 0, 'idem-1');
  raise notice '%  T1 giá server = 289000 - 10%% (28900) = 260100 | total=%', case when (res->>'total')::int = 260100 then 'PASS' else 'FAIL' end, res->>'total';
  raise notice '%  T2 cọc 20%% làm tròn lên 1000đ = 53000 | deposit=%', case when (res->>'deposit')::int = 53000 then 'PASS' else 'FAIL' end, res->>'deposit';

  -- T3: idempotency — gửi lại cùng khóa không tạo đơn mới
  res := public.place_order(jsonb_build_array(jsonb_build_object('variant_id', vid, 'size', 'M', 'qty', 1)),
          'Khach Test', '0901234567', 'An Giang', 'Phường Bình Đức', '12 Duong A', null, 'cod_balance', 'VERUS10', 0, 'idem-1');
  select count(*) into n from public.orders where user_id = cust;
  raise notice '%  T3 idempotency | orders=%', case when n = 1 and (res->>'duplicate')::boolean then 'PASS' else 'FAIL' end, n;

  -- T4: tồn kho giảm đúng, không bán lố
  begin
    perform public.place_order(jsonb_build_array(jsonb_build_object('variant_id', vid, 'size', 'M', 'qty', 20)),
      'Khach Test', '0901234567', 'An Giang', 'Phường Bình Đức', '12 Duong A', null, 'cod_balance', null, 0, 'idem-2');
    raise notice 'FAIL  T4 bán lố tồn kho';
  exception when others then raise notice '%  T4 chặn bán lố: %', case when sqlerrm like 'OUT_OF_STOCK%' then 'PASS' else 'FAIL' end, sqlerrm; end;

  -- T5: voucher dùng lần 2 bị từ chối
  begin
    perform public.place_order(jsonb_build_array(jsonb_build_object('variant_id', vid, 'size', 'S', 'qty', 1)),
      'Khach Test', '0901234567', 'An Giang', 'Phường Bình Đức', '12 Duong A', null, 'cod_balance', 'VERUS10', 0, 'idem-3');
    raise notice 'FAIL  T5 dùng lại voucher';
  exception when others then raise notice '%  T5 voucher 1 lần/khách: %', case when sqlerrm = 'COUPON_ALREADY_USED' then 'PASS' else 'FAIL' end, sqlerrm; end;

  -- T6: khách không tự cộng điểm / đổi role / sửa đơn / đọc giá vốn / đọc sổ cái
  begin update public.profiles set points_balance = 999999 where id = cust; raise notice 'FAIL  T6a tự sửa điểm';
  exception when others then raise notice 'PASS  T6a chặn tự sửa điểm (%)', left(sqlerrm, 40); end;
  begin update public.profiles set role = 'admin' where id = cust; raise notice 'FAIL  T6b tự nâng admin';
  exception when others then raise notice 'PASS  T6b chặn tự nâng admin (%)', left(sqlerrm, 40); end;
  begin update public.orders set total = 1 where user_id = cust; get diagnostics n = row_count;
    raise notice '%  T6c khách không sửa được đơn | rows=%', case when n = 0 then 'PASS' else 'FAIL' end, n;
  exception when others then raise notice 'PASS  T6c chặn sửa đơn (%)', left(sqlerrm, 40); end;
  begin perform 1 from public.product_costs limit 1; get diagnostics n = row_count;
    raise notice '%  T6d khách không thấy giá vốn | rows=%', case when n = 0 then 'PASS' else 'FAIL' end, n;
  exception when others then raise notice 'PASS  T6d khách không đọc được giá vốn'; end;
  begin perform 1 from public.ledger_entries limit 1; get diagnostics n = row_count;
    raise notice '%  T6e khách không thấy sổ cái | rows=%', case when n = 0 then 'PASS' else 'FAIL' end, n;
  exception when others then raise notice 'PASS  T6e khách không đọc được sổ cái'; end;
  begin perform public.admin_confirm_payment(gen_random_uuid()); raise notice 'FAIL  T6f khách gọi hàm admin';
  exception when others then raise notice '%  T6f khách không gọi được hàm admin: %', case when sqlerrm = 'FORBIDDEN' then 'PASS' else 'FAIL' end, sqlerrm; end;
  begin insert into public.reviews(product_id, user_id, order_item_id, rating, body)
        select product_id, cust, id, 5, 'review lậu' from public.order_items limit 1;
    raise notice 'FAIL  T6g tạo review không qua RPC';
  exception when others then raise notice 'PASS  T6g chặn insert review trực tiếp'; end;

  select id into oid from public.orders where user_id = cust limit 1;
  perform public.report_deposit_transfer(oid, 'CK VS TEST');

  -- ===== ADMIN =====
  reset role;
  perform set_config('request.jwt.claims', json_build_object('sub', adm, 'role', 'authenticated')::text, true);
  set local role authenticated;
  select id into pid from public.payments where order_id = oid and kind = 'deposit';
  -- T7: chưa xác nhận cọc thì không được đặt nhà cung cấp
  perform public.admin_set_order_status(oid, 'confirmed', 'ok');
  perform public.admin_set_order_status(oid, 'sourcing', null);
  begin perform public.admin_set_order_status(oid, 'supplier_ordered', null); raise notice 'FAIL  T7 đặt NCC khi chưa nhận cọc';
  exception when others then raise notice '%  T7 chặn đặt NCC khi chưa xác nhận cọc: %', case when sqlerrm = 'DEPOSIT_NOT_CONFIRMED' then 'PASS' else 'FAIL' end, sqlerrm; end;
  perform public.admin_confirm_payment(pid);
  res := public.wallet_summary();
  raise notice '%  T8 sổ cái ghi cọc 53000 | available=%', case when (res->>'available')::bigint = 53000 then 'PASS' else 'FAIL' end, res->>'available';
  perform public.admin_set_order_status(oid, 'supplier_ordered', null);
  select (eta_date = current_date + 15) into ok from public.orders where id = oid;
  raise notice '%  T9 ETA = ngày đặt NCC + 15 ngày', case when ok then 'PASS' else 'FAIL' end;
  begin perform public.admin_set_order_status(oid, 'delivered', null); raise notice 'FAIL  T10 nhảy cóc trạng thái';
  exception when others then raise notice '%  T10 chặn nhảy cóc trạng thái', case when sqlerrm like 'INVALID_TRANSITION%' then 'PASS' else 'FAIL' end; end;
  begin perform public.admin_request_withdrawal(99999999, 'Bank', 'Owner', '1234'); raise notice 'FAIL  T11 rút quá số dư';
  exception when others then raise notice '%  T11 chặn rút quá số dư: %', case when sqlerrm = 'INSUFFICIENT_AVAILABLE_BALANCE' then 'PASS' else 'FAIL' end, sqlerrm; end;
  begin perform public.admin_refund(oid, 999999, 'test'); raise notice 'FAIL  T12 hoàn quá số đã nhận';
  exception when others then raise notice '%  T12 chặn hoàn quá số đã nhận: %', case when sqlerrm = 'REFUND_EXCEEDS_RECEIVED' then 'PASS' else 'FAIL' end, sqlerrm; end;

  reset role;
  raise notice 'Hoàn tất. Giao dịch sẽ ROLLBACK, không để lại dữ liệu.';
end $$;
rollback;
