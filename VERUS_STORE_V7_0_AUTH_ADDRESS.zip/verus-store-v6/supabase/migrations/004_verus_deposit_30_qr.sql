-- VERUS STORE: cố định chính sách cọc 30% bằng chuyển khoản QR.
-- Chỉ cập nhật cấu hình chính sách công khai; không chứa thông tin tài khoản ngân hàng.
update public.site_settings
set value = '30'::jsonb, is_public = true
where key = 'deposit_percent';

update public.site_settings
set value = to_jsonb('Khách đặt hàng và thanh toán trước 30% giá trị đơn hàng bằng chuyển khoản QR sau khi shop xác nhận đơn. Shop kiểm tra giao dịch ngân hàng thủ công trước khi xác nhận đã nhận cọc. 70% còn lại thanh toán khi nhận hàng hoặc theo phương thức được hiển thị tại bước đặt hàng. Nếu sản phẩm không thể cung cấp, shop liên hệ khách để thống nhất phương án hoặc hoàn lại khoản tiền đã nhận.'::text), is_public = true
where key = 'policy_text';
