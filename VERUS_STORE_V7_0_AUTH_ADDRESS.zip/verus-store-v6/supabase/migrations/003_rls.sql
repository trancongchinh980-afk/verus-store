-- =====================================================================
-- VERUS STORE V6 — 003_rls.sql
-- Mặc định TỪ CHỐI. Chỉ mở đúng những gì cần.
-- Bảng nhạy cảm (orders, payments, ledger, loyalty, ...) KHÔNG có policy ghi
-- cho trình duyệt: mọi thay đổi bắt buộc đi qua hàm RPC ở 002.
-- =====================================================================

-- 1) Bật RLS trên mọi bảng
do $$ declare t text; begin
  for t in select tablename from pg_tables where schemaname = 'public' loop
    execute format('alter table public.%I enable row level security', t);
  end loop; end $$;

-- 2) Thu hồi quyền mặc định của Supabase, rồi cấp lại tối thiểu
revoke all on all tables in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke all on all functions in schema public from anon, authenticated, public;
alter default privileges in schema public revoke all on tables from anon, authenticated;
alter default privileges in schema public revoke all on functions from anon, authenticated, public;

-- 3) Quyền đọc công khai (không cần đăng nhập): vitrin
grant select on public.categories, public.products, public.product_variants, public.variant_sizes,
  public.outfits, public.outfit_items, public.vip_tiers, public.site_settings to anon, authenticated;

create policy cat_read   on public.categories       for select using (true);
create policy prod_read  on public.products         for select using (status = 'active' or public.is_staff());
create policy var_read   on public.product_variants for select using (exists (select 1 from public.products p where p.id = product_id and (p.status = 'active' or public.is_staff())));
create policy size_read  on public.variant_sizes    for select using (exists (select 1 from public.product_variants v join public.products p on p.id = v.product_id where v.id = variant_id and (p.status = 'active' or public.is_staff())));
create policy outfit_read on public.outfits         for select using (active or public.is_staff());
create policy oitem_read on public.outfit_items     for select using (exists (select 1 from public.outfits o where o.id = outfit_id and (o.active or public.is_staff())));
create policy tier_read  on public.vip_tiers        for select using (true);
create policy set_read   on public.site_settings    for select using (is_public or public.is_admin());

-- 4) Ghi dữ liệu cửa hàng: chỉ ADMIN (kiểm tra ở policy, không tin client)
grant insert, update, delete on public.categories, public.products, public.product_variants, public.variant_sizes,
  public.outfits, public.outfit_items, public.vip_tiers, public.site_settings, public.coupons to authenticated;
create policy cat_w    on public.categories       for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy prod_w   on public.products         for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy var_w    on public.product_variants for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy size_w   on public.variant_sizes    for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy outfit_w on public.outfits          for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy oitem_w  on public.outfit_items     for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy tier_w   on public.vip_tiers        for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy set_w    on public.site_settings    for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Giá vốn & coupon: khách không đọc được (giá vốn không bao giờ lộ ra giao diện khách)
grant select, insert, update, delete on public.product_costs to authenticated;
create policy cost_admin on public.product_costs for all to authenticated using (public.is_admin()) with check (public.is_admin());
grant select on public.coupons to authenticated;
create policy coupon_read  on public.coupons for select to authenticated using (public.is_staff());
create policy coupon_write on public.coupons for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- 5) Hồ sơ: đọc của mình; sửa CHỈ các cột an toàn (role/điểm/hạng bị chặn bằng quyền cột)
grant select on public.profiles to authenticated;
grant update (full_name, phone, birthday, marketing_opt_in) on public.profiles to authenticated;
create policy prof_read   on public.profiles for select to authenticated using (id = auth.uid() or public.is_staff());
create policy prof_update on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

grant select, insert, update, delete on public.addresses to authenticated;
create policy addr_own on public.addresses for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- 6) Đơn hàng: chủ đơn đọc đơn của mình, staff đọc tất cả. KHÔNG có policy insert/update/delete.
grant select on public.orders, public.order_items, public.order_events, public.payments to authenticated;
create policy ord_read  on public.orders       for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy oi_read   on public.order_items  for select to authenticated using (exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_staff())));
create policy oe_read   on public.order_events for select to authenticated using (exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_staff())));
create policy pay_read  on public.payments     for select to authenticated using (exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_staff())));

-- 7) Tài chính nội bộ: chỉ admin đọc; không ai ghi trực tiếp
grant select on public.ledger_entries, public.withdrawal_requests, public.audit_log, public.crm_outbox, public.coupon_redemptions to authenticated;
create policy led_read  on public.ledger_entries     for select to authenticated using (public.is_admin());
create policy wd_read   on public.withdrawal_requests for select to authenticated using (public.is_admin());
create policy aud_read  on public.audit_log          for select to authenticated using (public.is_admin());
create policy crm_read  on public.crm_outbox         for select to authenticated using (public.is_admin());
create policy red_read  on public.coupon_redemptions for select to authenticated using (public.is_staff());

-- 8) Điểm & giới thiệu: chỉ đọc của mình
grant select on public.loyalty_ledger, public.referrals to authenticated;
create policy loy_read on public.loyalty_ledger for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy ref_read on public.referrals      for select to authenticated using (referrer_id = auth.uid() or referee_id = auth.uid() or public.is_staff());

-- 9) Đánh giá: công khai chỉ khi đã duyệt; tạo qua RPC submit_review (xác minh đã mua)
grant select on public.reviews to authenticated;
create policy rev_read on public.reviews for select to authenticated using (user_id = auth.uid() or public.is_staff());
create or replace view public.public_reviews as
  select r.id, r.product_id, r.rating, r.title, r.body, r.photo_urls, r.created_at,
         split_part(coalesce(nullif(p.full_name, ''), 'Khách hàng'), ' ', -1) as reviewer, true as verified_purchase
  from public.reviews r join public.profiles p on p.id = r.user_id where r.status = 'published';
create or replace view public.product_rating_stats as
  select product_id, count(*)::int as review_count, round(avg(rating)::numeric, 1) as rating_avg
  from public.reviews where status = 'published' group by product_id;
grant select on public.public_reviews, public.product_rating_stats to anon, authenticated;

-- 10) Yêu thích, giỏ: của chính mình
grant select, insert, update, delete on public.wishlist, public.cart_snapshots to authenticated;
create policy wl_own   on public.wishlist       for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy cart_own on public.cart_snapshots for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- 11) Chat / khiếu nại
grant select, insert on public.chat_threads, public.chat_messages to authenticated;
grant update (status) on public.chat_threads to authenticated;
grant usage, select on sequence public.chat_messages_id_seq to authenticated;
create policy th_read   on public.chat_threads  for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy th_insert on public.chat_threads  for insert to authenticated with check (user_id = auth.uid() and (order_id is null or exists (select 1 from public.orders o where o.id = order_id and o.user_id = auth.uid())));
create policy th_update on public.chat_threads  for update to authenticated using (public.is_staff()) with check (public.is_staff());
create policy msg_read   on public.chat_messages for select to authenticated using (exists (select 1 from public.chat_threads t where t.id = thread_id and (t.user_id = auth.uid() or public.is_staff())));
create policy msg_insert on public.chat_messages for insert to authenticated with check (exists (select 1 from public.chat_threads t where t.id = thread_id and (t.user_id = auth.uid() or public.is_staff())));

-- 12) Sự kiện phân tích: ai cũng ghi được (không gán user giả), chỉ staff đọc
grant insert on public.events to anon, authenticated;
grant usage, select on sequence public.events_id_seq to anon, authenticated;
grant select on public.events to authenticated;
create policy ev_insert on public.events for insert to anon, authenticated with check (user_id is null or user_id = auth.uid());
create policy ev_read   on public.events for select to authenticated using (public.is_staff());

-- 13) Quyền thực thi hàm: mặc định thu hồi; cấp đúng nhóm
grant execute on function public.is_staff(), public.is_admin(), public.setting_int(text, int) to anon, authenticated;
grant execute on function public.preview_coupon(text, bigint), public.track_order(text, text) to anon, authenticated;
grant execute on function public.place_order(jsonb, text, text, text, text, text, text, text, text, int, text),
  public.report_deposit_transfer(uuid, text), public.my_vip(), public.submit_review(uuid, int, text, text, text[]) to authenticated;
grant execute on function public.admin_set_order_status(uuid, text, text), public.admin_set_shipping(uuid, text, text),
  public.admin_set_internal_note(uuid, text), public.admin_confirm_payment(uuid), public.admin_reject_payment(uuid, text),
  public.admin_refund(uuid, int, text), public.wallet_summary(), public.admin_request_withdrawal(bigint, text, text, text),
  public.admin_decide_withdrawal(uuid, text, text), public.admin_moderate_review(uuid, text), public.admin_set_role(uuid, text),
  public.admin_crm(), public.admin_queue_crm(text, text), public.admin_dashboard(int) to authenticated;
-- Các hàm nội bộ (finalize_order_rewards, active_tier, vip_spend_12m, ...) KHÔNG cấp cho client.
