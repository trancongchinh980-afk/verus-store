-- =====================================================================
-- VERUS STORE V6 — 001_schema.sql
-- Chạy trong Supabase Dashboard > SQL Editor (hoặc supabase db push).
-- Nguyên tắc: trình duyệt KHÔNG ghi trực tiếp vào bảng nhạy cảm.
-- Mọi thay đổi về đơn hàng, tiền, điểm, tồn kho đi qua hàm RPC (002).
-- =====================================================================

-- ---------- Hồ sơ & phân quyền ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  role text not null default 'customer' check (role in ('customer','staff','admin')),
  points_balance int not null default 0 check (points_balance >= 0),
  referral_code text unique,
  referred_by uuid references public.profiles(id),
  marketing_opt_in boolean not null default false,
  birthday date,
  highest_tier text,                       -- cột mốc hạng cao nhất từng đạt
  last_order_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.addresses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  recipient text not null, phone text not null,
  province text not null, ward text not null, street text not null,
  is_default boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- Cấu hình ----------
create table public.site_settings (
  key text primary key,
  value jsonb not null,
  is_public boolean not null default true,
  updated_at timestamptz not null default now()
);

create table public.vip_tiers (
  code text primary key,
  name text not null,
  min_spend_12m bigint not null check (min_spend_12m >= 0),
  points_multiplier numeric(4,2) not null default 1 check (points_multiplier >= 1),
  perks jsonb not null default '[]'::jsonb,
  sort int not null
);

-- ---------- Danh mục & sản phẩm ----------
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique, slug text not null unique, sort int not null default 0
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  sku text not null unique,
  name text not null check (length(name) between 2 and 160),
  category text not null references public.categories(name) on update cascade,
  badge text, status text not null default 'draft' check (status in ('active','draft','hidden')),
  material text, fit text, care text,
  delivery_note text,
  description_html text not null default '',
  style_tags text[] not null default '{}',
  occasion text,
  styling_tips text,                       -- gợi ý phối đồ (chỉ nhập dữ liệu thật)
  size_chart jsonb,                        -- bảng số đo thực tế của mẫu
  size_rules jsonb,                        -- [{h_min,h_max,w_min,w_max,size}]
  price int not null check (price >= 0),   -- giá bán công khai (VNĐ)
  compare_price int check (compare_price is null or compare_price > price),
  featured boolean not null default false,
  created_at timestamptz not null default now()
);

-- Giá vốn tách bảng riêng: khách KHÔNG bao giờ đọc được.
create table public.product_costs (
  product_id uuid primary key references public.products(id) on delete cascade,
  base_cost int not null default 0 check (base_cost >= 0),
  extra_cost int not null default 0 check (extra_cost >= 0),
  target_profit int not null default 100000 check (target_profit >= 0)
);

create table public.product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  name text not null, sku text not null unique,
  image_urls text[] not null default '{}', video_urls text[] not null default '{}',
  sort int not null default 0
);

create table public.variant_sizes (
  id uuid primary key default gen_random_uuid(),
  variant_id uuid not null references public.product_variants(id) on delete cascade,
  size text not null,
  stock int not null default 0 check (stock >= 0),   -- chặn bán lố ở tầng DB
  unique (variant_id, size)
);

-- ---------- Outfit ----------
create table public.outfits (
  id uuid primary key default gen_random_uuid(),
  title text not null, description text, style_tag text, cover_url text,
  active boolean not null default true, created_at timestamptz not null default now()
);
create table public.outfit_items (
  outfit_id uuid references public.outfits(id) on delete cascade,
  product_id uuid references public.products(id) on delete cascade,
  role text, sort int not null default 0,
  primary key (outfit_id, product_id)
);

-- ---------- Voucher ----------
create table public.coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique check (code = upper(code)),
  name text not null,
  kind text not null check (kind in ('percent','fixed')),
  value int not null check (value > 0),
  min_subtotal int not null default 0, max_discount int,
  usage_limit int, used_count int not null default 0,
  per_user_limit int not null default 1,
  min_tier text references public.vip_tiers(code),
  starts_at timestamptz, ends_at timestamptz,
  active boolean not null default true,
  check (kind <> 'percent' or value <= 100)
);

-- ---------- Đơn hàng ----------
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  user_id uuid not null references public.profiles(id),
  idem_key text,
  customer_name text not null, phone text not null,
  province text not null, ward text not null, street text not null, note text,
  pay_method text not null check (pay_method in ('cod_balance','bank_transfer_balance')),
  subtotal int not null, discount int not null default 0, points_discount int not null default 0,
  total int not null check (total >= 0),
  coupon_code text, points_used int not null default 0,
  deposit_percent int not null, deposit_amount int not null, balance_amount int not null,
  status text not null default 'pending' check (status in
    ('pending','confirmed','sourcing','supplier_ordered','in_transit_vn','inspecting','shipping','delivered','return_requested','cancelled','refunded')),
  deposit_status text not null default 'unpaid' check (deposit_status in ('unpaid','pending_review','confirmed','refunded')),
  carrier text, tracking_code text,
  supplier_ordered_at timestamptz, eta_date date, delivered_at timestamptz,
  points_awarded boolean not null default false,
  internal_note text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (user_id, idem_key)
);
create index orders_user_idx on public.orders(user_id, created_at desc);
create index orders_status_idx on public.orders(status, created_at desc);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  variant_id uuid not null references public.product_variants(id),
  size text not null,
  product_name text not null, variant_name text not null, sku text not null,
  unit_price int not null, qty int not null check (qty between 1 and 20),
  line_total int not null
);
create index order_items_order_idx on public.order_items(order_id);

create table public.order_events (
  id bigserial primary key,
  order_id uuid not null references public.orders(id) on delete cascade,
  status text not null, note text, actor uuid, created_at timestamptz not null default now()
);

create table public.coupon_redemptions (
  id uuid primary key default gen_random_uuid(),
  coupon_id uuid not null references public.coupons(id),
  user_id uuid not null references public.profiles(id),
  order_id uuid not null references public.orders(id) on delete cascade,
  created_at timestamptz not null default now()
);

-- ---------- Thanh toán, sổ cái, rút tiền ----------
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id),
  kind text not null check (kind in ('deposit','balance_cod','refund')),
  amount int not null check (amount > 0),
  reference text,                          -- nội dung CK / mã đối soát do khách khai báo (CHƯA phải bằng chứng)
  status text not null default 'pending' check (status in ('pending','confirmed','rejected')),
  confirmed_by uuid, confirmed_at timestamptz,
  created_at timestamptz not null default now()
);

-- Sổ cái chỉ-thêm (append-only). Số dư = tổng sổ cái, không lưu ở frontend.
create table public.ledger_entries (
  id bigserial primary key,
  direction text not null check (direction in ('credit','debit')),
  kind text not null check (kind in ('deposit_received','cod_received','refund_paid','withdrawal_paid','adjustment')),
  amount bigint not null check (amount > 0),
  order_id uuid references public.orders(id), payment_id uuid references public.payments(id),
  note text, created_by uuid, created_at timestamptz not null default now()
);

create table public.withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  amount bigint not null check (amount > 0),
  bank_name text not null, account_owner text not null,
  account_hint text,                       -- chỉ 4 số cuối; KHÔNG lưu số tài khoản đầy đủ
  status text not null default 'pending' check (status in ('pending','approved','rejected','paid_manually')),
  requested_by uuid not null, decided_by uuid, decided_at timestamptz,
  note text, created_at timestamptz not null default now()
);

-- ---------- Loyalty / VIP / giới thiệu ----------
create table public.loyalty_ledger (
  id bigserial primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  delta int not null check (delta <> 0),
  reason text not null check (reason in ('order_reward','redeem_order','refund_redeem','referral_reward','adjustment','reverse_reward')),
  order_id uuid references public.orders(id),
  created_at timestamptz not null default now()
);
create table public.referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_id uuid not null references public.profiles(id),
  referee_id uuid not null unique references public.profiles(id),
  status text not null default 'pending' check (status in ('pending','rewarded')),
  reward_points int not null default 0, created_at timestamptz not null default now(),
  check (referrer_id <> referee_id)
);

-- ---------- Đánh giá, yêu thích, giỏ, chat, sự kiện ----------
create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  order_item_id uuid not null unique references public.order_items(id) on delete cascade,
  rating int not null check (rating between 1 and 5),
  title text check (length(title) <= 120), body text not null check (length(body) between 5 and 2000),
  photo_urls text[] not null default '{}',
  status text not null default 'pending' check (status in ('pending','published','rejected')),
  created_at timestamptz not null default now()
);
create table public.wishlist (
  user_id uuid references public.profiles(id) on delete cascade,
  product_id uuid references public.products(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, product_id)
);
create table public.cart_snapshots (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  items jsonb not null default '[]'::jsonb, updated_at timestamptz not null default now()
);
create table public.chat_threads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  order_id uuid references public.orders(id),
  kind text not null default 'support' check (kind in ('support','complaint')),
  subject text not null, status text not null default 'open' check (status in ('open','closed')),
  last_message_at timestamptz not null default now(), created_at timestamptz not null default now()
);
create table public.chat_messages (
  id bigserial primary key,
  thread_id uuid not null references public.chat_threads(id) on delete cascade,
  sender_id uuid not null, sender_role text not null check (sender_role in ('customer','staff')),
  body text not null check (length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);
create table public.events (
  id bigserial primary key,
  user_id uuid, session_id text,
  name text not null check (name in ('view_product','search','add_to_wishlist','add_to_cart','begin_checkout','purchase','refund','repeat_purchase','view_outfit')),
  props jsonb not null default '{}'::jsonb check (pg_column_size(props) < 1500),
  created_at timestamptz not null default now()
);
create index events_name_time_idx on public.events(name, created_at desc);

create table public.crm_outbox (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  segment text not null, template text not null,
  status text not null default 'queued' check (status in ('queued','sent','failed')), -- 'sent' cần dịch vụ email/Zalo ngoài
  created_at timestamptz not null default now()
);
create table public.audit_log (
  id bigserial primary key, actor uuid, action text not null, entity text, entity_id text,
  detail jsonb, created_at timestamptz not null default now()
);

-- ---------- Trigger: sổ cái điểm & sổ cái tiền là append-only ----------
create or replace function public.forbid_mutation() returns trigger language plpgsql as $$
begin raise exception 'Bảng % chỉ cho phép thêm, không sửa/xóa', tg_table_name; end $$;
create trigger ledger_append_only before update or delete on public.ledger_entries
  for each row execute function public.forbid_mutation();
create trigger loyalty_no_update before update on public.loyalty_ledger
  for each row execute function public.forbid_mutation();
create trigger audit_append_only before update or delete on public.audit_log
  for each row execute function public.forbid_mutation();

-- Điểm: số dư chỉ đổi qua sổ cái điểm.
create or replace function public.apply_loyalty_delta() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.profiles set points_balance = points_balance + new.delta where id = new.user_id;
  return new;
end $$;
create trigger loyalty_apply after insert on public.loyalty_ledger
  for each row execute function public.apply_loyalty_delta();

-- Tự tạo hồ sơ khi đăng ký; gắn người giới thiệu (chỉ liên kết, thưởng sau khi đơn đầu được giao).
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare ref uuid; rc text := nullif(upper(trim(new.raw_user_meta_data->>'referral_code')),'');
begin
  if rc is not null then select id into ref from public.profiles where referral_code = rc; end if;
  insert into public.profiles(id, full_name, referral_code, referred_by)
  values (new.id, left(coalesce(new.raw_user_meta_data->>'full_name',''),120),
          'VS' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,7)), ref);
  if ref is not null then
    insert into public.referrals(referrer_id, referee_id) values (ref, new.id);
  end if;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Tên người viết đánh giá chỉ hiện dạng rút gọn; chat gán sender_role từ DB, không tin client.
create or replace function public.chat_before_insert() returns trigger
language plpgsql security definer set search_path = public as $$
declare r text;
begin
  select role into r from public.profiles where id = auth.uid();
  new.sender_id := auth.uid();
  new.sender_role := case when r in ('staff','admin') then 'staff' else 'customer' end;
  return new;
end $$;
create trigger chat_set_sender before insert on public.chat_messages
  for each row execute function public.chat_before_insert();
create or replace function public.chat_after_insert() returns trigger
language plpgsql security definer set search_path = public as $$
begin update public.chat_threads set last_message_at = now() where id = new.thread_id; return new; end $$;
create trigger chat_touch after insert on public.chat_messages
  for each row execute function public.chat_after_insert();
