-- VERUS STORE: script khởi tạo Supabase gộp cho dự án mới.
-- Chạy một lần trong Supabase SQL Editor trên project verus-store.
-- Lưu ý: schema/functions/RLS chưa được chạy thử trên PostgreSQL thật trong môi trường tạo file.
-- Nếu có lỗi, dừng và gửi thông báo lỗi; không chạy lại toàn bộ từ đầu khi một phần đã thành công.


-- ============================================================
-- BEGIN 001_schema.sql
-- ============================================================
-- =====================================================================
-- VERUS STORE V6 — 001_schema.sql
-- Chạy trong Supabase Dashboard > SQL Editor (hoặc supabase db push).
-- Nguyên tắc: trình duyệt KHÔNG ghi trực tiếp vào bảng nhạy cảm.
-- Mọi thay đổi về đơn hàng, tiền, điểm, tồn kho đi qua hàm RPC (002).
-- =====================================================================

-- ---------- Hồ sơ & phân quyền ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  role text not null default 'customer' check (role in ('customer','staff','admin')),
  points_balance int not null default 0 check (points_balance >= 0),
  referral_code text unique,
  referred_by uuid references public.profiles(id),
  marketing_opt_in boolean not null default false,
  birthday date,
  highest_tier text,                       -- cột mốc hạng cao nhất từng đạt
  last_order_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.addresses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  recipient text not null, phone text not null,
  province text not null, ward text not null, street text not null,
  is_default boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- Cấu hình ----------
create table public.site_settings (
  key text primary key,
  value jsonb not null,
  is_public boolean not null default true,
  updated_at timestamptz not null default now()
);

create table public.vip_tiers (
  code text primary key,
  name text not null,
  min_spend_12m bigint not null check (min_spend_12m >= 0),
  points_multiplier numeric(4,2) not null default 1 check (points_multiplier >= 1),
  perks jsonb not null default '[]'::jsonb,
  sort int not null
);

-- ---------- Danh mục & sản phẩm ----------
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique, slug text not null unique, sort int not null default 0
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  sku text not null unique,
  name text not null check (length(name) between 2 and 160),
  category text not null references public.categories(name) on update cascade,
  badge text, status text not null default 'draft' check (status in ('active','draft','hidden')),
  material text, fit text, care text,
  delivery_note text,
  description_html text not null default '',
  style_tags text[] not null default '{}',
  occasion text,
  styling_tips text,                       -- gợi ý phối đồ (chỉ nhập dữ liệu thật)
  size_chart jsonb,                        -- bảng số đo thực tế của mẫu
  size_rules jsonb,                        -- [{h_min,h_max,w_min,w_max,size}]
  price int not null check (price >= 0),   -- giá bán công khai (VNĐ)
  compare_price int check (compare_price is null or compare_price > price),
  featured boolean not null default false,
  created_at timestamptz not null default now()
);

-- Giá vốn tách bảng riêng: khách KHÔNG bao giờ đọc được.
create table public.product_costs (
  product_id uuid primary key references public.products(id) on delete cascade,
  base_cost int not null default 0 check (base_cost >= 0),
  extra_cost int not null default 0 check (extra_cost >= 0),
  target_profit int not null default 100000 check (target_profit >= 0)
);

create table public.product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  name text not null, sku text not null unique,
  image_urls text[] not null default '{}', video_urls text[] not null default '{}',
  sort int not null default 0
);

create table public.variant_sizes (
  id uuid primary key default gen_random_uuid(),
  variant_id uuid not null references public.product_variants(id) on delete cascade,
  size text not null,
  stock int not null default 0 check (stock >= 0),   -- chặn bán lố ở tầng DB
  unique (variant_id, size)
);

-- ---------- Outfit ----------
create table public.outfits (
  id uuid primary key default gen_random_uuid(),
  title text not null, description text, style_tag text, cover_url text,
  active boolean not null default true, created_at timestamptz not null default now()
);
create table public.outfit_items (
  outfit_id uuid references public.outfits(id) on delete cascade,
  product_id uuid references public.products(id) on delete cascade,
  role text, sort int not null default 0,
  primary key (outfit_id, product_id)
);

-- ---------- Voucher ----------
create table public.coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique check (code = upper(code)),
  name text not null,
  kind text not null check (kind in ('percent','fixed')),
  value int not null check (value > 0),
  min_subtotal int not null default 0, max_discount int,
  usage_limit int, used_count int not null default 0,
  per_user_limit int not null default 1,
  min_tier text references public.vip_tiers(code),
  starts_at timestamptz, ends_at timestamptz,
  active boolean not null default true,
  check (kind <> 'percent' or value <= 100)
);

-- ---------- Đơn hàng ----------
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  user_id uuid not null references public.profiles(id),
  idem_key text,
  customer_name text not null, phone text not null,
  province text not null, ward text not null, street text not null, note text,
  pay_method text not null check (pay_method in ('cod_balance','bank_transfer_balance')),
  subtotal int not null, discount int not null default 0, points_discount int not null default 0,
  total int not null check (total >= 0),
  coupon_code text, points_used int not null default 0,
  deposit_percent int not null, deposit_amount int not null, balance_amount int not null,
  status text not null default 'pending' check (status in
    ('pending','confirmed','sourcing','supplier_ordered','in_transit_vn','inspecting','shipping','delivered','return_requested','cancelled','refunded')),
  deposit_status text not null default 'unpaid' check (deposit_status in ('unpaid','pending_review','confirmed','refunded')),
  carrier text, tracking_code text,
  supplier_ordered_at timestamptz, eta_date date, delivered_at timestamptz,
  points_awarded boolean not null default false,
  internal_note text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (user_id, idem_key)
);
create index orders_user_idx on public.orders(user_id, created_at desc);
create index orders_status_idx on public.orders(status, created_at desc);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  variant_id uuid not null references public.product_variants(id),
  size text not null,
  product_name text not null, variant_name text not null, sku text not null,
  unit_price int not null, qty int not null check (qty between 1 and 20),
  line_total int not null
);
create index order_items_order_idx on public.order_items(order_id);

create table public.order_events (
  id bigserial primary key,
  order_id uuid not null references public.orders(id) on delete cascade,
  status text not null, note text, actor uuid, created_at timestamptz not null default now()
);

create table public.coupon_redemptions (
  id uuid primary key default gen_random_uuid(),
  coupon_id uuid not null references public.coupons(id),
  user_id uuid not null references public.profiles(id),
  order_id uuid not null references public.orders(id) on delete cascade,
  created_at timestamptz not null default now()
);

-- ---------- Thanh toán, sổ cái, rút tiền ----------
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id),
  kind text not null check (kind in ('deposit','balance_cod','refund')),
  amount int not null check (amount > 0),
  reference text,                          -- nội dung CK / mã đối soát do khách khai báo (CHƯA phải bằng chứng)
  status text not null default 'pending' check (status in ('pending','confirmed','rejected')),
  confirmed_by uuid, confirmed_at timestamptz,
  created_at timestamptz not null default now()
);

-- Sổ cái chỉ-thêm (append-only). Số dư = tổng sổ cái, không lưu ở frontend.
create table public.ledger_entries (
  id bigserial primary key,
  direction text not null check (direction in ('credit','debit')),
  kind text not null check (kind in ('deposit_received','cod_received','refund_paid','withdrawal_paid','adjustment')),
  amount bigint not null check (amount > 0),
  order_id uuid references public.orders(id), payment_id uuid references public.payments(id),
  note text, created_by uuid, created_at timestamptz not null default now()
);

create table public.withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  amount bigint not null check (amount > 0),
  bank_name text not null, account_owner text not null,
  account_hint text,                       -- chỉ 4 số cuối; KHÔNG lưu số tài khoản đầy đủ
  status text not null default 'pending' check (status in ('pending','approved','rejected','paid_manually')),
  requested_by uuid not null, decided_by uuid, decided_at timestamptz,
  note text, created_at timestamptz not null default now()
);

-- ---------- Loyalty / VIP / giới thiệu ----------
create table public.loyalty_ledger (
  id bigserial primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  delta int not null check (delta <> 0),
  reason text not null check (reason in ('order_reward','redeem_order','refund_redeem','referral_reward','adjustment','reverse_reward')),
  order_id uuid references public.orders(id),
  created_at timestamptz not null default now()
);
create table public.referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_id uuid not null references public.profiles(id),
  referee_id uuid not null unique references public.profiles(id),
  status text not null default 'pending' check (status in ('pending','rewarded')),
  reward_points int not null default 0, created_at timestamptz not null default now(),
  check (referrer_id <> referee_id)
);

-- ---------- Đánh giá, yêu thích, giỏ, chat, sự kiện ----------
create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  order_item_id uuid not null unique references public.order_items(id) on delete cascade,
  rating int not null check (rating between 1 and 5),
  title text check (length(title) <= 120), body text not null check (length(body) between 5 and 2000),
  photo_urls text[] not null default '{}',
  status text not null default 'pending' check (status in ('pending','published','rejected')),
  created_at timestamptz not null default now()
);
create table public.wishlist (
  user_id uuid references public.profiles(id) on delete cascade,
  product_id uuid references public.products(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, product_id)
);
create table public.cart_snapshots (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  items jsonb not null default '[]'::jsonb, updated_at timestamptz not null default now()
);
create table public.chat_threads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  order_id uuid references public.orders(id),
  kind text not null default 'support' check (kind in ('support','complaint')),
  subject text not null, status text not null default 'open' check (status in ('open','closed')),
  last_message_at timestamptz not null default now(), created_at timestamptz not null default now()
);
create table public.chat_messages (
  id bigserial primary key,
  thread_id uuid not null references public.chat_threads(id) on delete cascade,
  sender_id uuid not null, sender_role text not null check (sender_role in ('customer','staff')),
  body text not null check (length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);
create table public.events (
  id bigserial primary key,
  user_id uuid, session_id text,
  name text not null check (name in ('view_product','search','add_to_wishlist','add_to_cart','begin_checkout','purchase','refund','repeat_purchase','view_outfit')),
  props jsonb not null default '{}'::jsonb check (pg_column_size(props) < 1500),
  created_at timestamptz not null default now()
);
create index events_name_time_idx on public.events(name, created_at desc);

create table public.crm_outbox (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  segment text not null, template text not null,
  status text not null default 'queued' check (status in ('queued','sent','failed')), -- 'sent' cần dịch vụ email/Zalo ngoài
  created_at timestamptz not null default now()
);
create table public.audit_log (
  id bigserial primary key, actor uuid, action text not null, entity text, entity_id text,
  detail jsonb, created_at timestamptz not null default now()
);

-- ---------- Trigger: sổ cái điểm & sổ cái tiền là append-only ----------
create or replace function public.forbid_mutation() returns trigger language plpgsql as $$
begin raise exception 'Bảng % chỉ cho phép thêm, không sửa/xóa', tg_table_name; end $$;
create trigger ledger_append_only before update or delete on public.ledger_entries
  for each row execute function public.forbid_mutation();
create trigger loyalty_no_update before update on public.loyalty_ledger
  for each row execute function public.forbid_mutation();
create trigger audit_append_only before update or delete on public.audit_log
  for each row execute function public.forbid_mutation();

-- Điểm: số dư chỉ đổi qua sổ cái điểm.
create or replace function public.apply_loyalty_delta() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.profiles set points_balance = points_balance + new.delta where id = new.user_id;
  return new;
end $$;
create trigger loyalty_apply after insert on public.loyalty_ledger
  for each row execute function public.apply_loyalty_delta();

-- Tự tạo hồ sơ khi đăng ký; gắn người giới thiệu (chỉ liên kết, thưởng sau khi đơn đầu được giao).
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare ref uuid; rc text := nullif(upper(trim(new.raw_user_meta_data->>'referral_code')),'');
begin
  if rc is not null then select id into ref from public.profiles where referral_code = rc; end if;
  insert into public.profiles(id, full_name, referral_code, referred_by)
  values (new.id, left(coalesce(new.raw_user_meta_data->>'full_name',''),120),
          'VS' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,7)), ref);
  if ref is not null then
    insert into public.referrals(referrer_id, referee_id) values (ref, new.id);
  end if;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Tên người viết đánh giá chỉ hiện dạng rút gọn; chat gán sender_role từ DB, không tin client.
create or replace function public.chat_before_insert() returns trigger
language plpgsql security definer set search_path = public as $$
declare r text;
begin
  select role into r from public.profiles where id = auth.uid();
  new.sender_id := auth.uid();
  new.sender_role := case when r in ('staff','admin') then 'staff' else 'customer' end;
  return new;
end $$;
create trigger chat_set_sender before insert on public.chat_messages
  for each row execute function public.chat_before_insert();
create or replace function public.chat_after_insert() returns trigger
language plpgsql security definer set search_path = public as $$
begin update public.chat_threads set last_message_at = now() where id = new.thread_id; return new; end $$;
create trigger chat_touch after insert on public.chat_messages
  for each row execute function public.chat_after_insert();

-- END 001_schema.sql


-- ============================================================
-- BEGIN 002_functions.sql
-- ============================================================
-- =====================================================================
-- VERUS STORE V6 — 002_functions.sql
-- Toàn bộ logic tiền/đơn/điểm nằm ở đây (SECURITY DEFINER, tự kiểm tra quyền).
-- =====================================================================

-- ---------- Tiện ích quyền ----------
create or replace function public.is_staff() returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select role in ('staff','admin') from public.profiles where id = auth.uid()), false) $$;
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select role = 'admin' from public.profiles where id = auth.uid()), false) $$;
create or replace function public.require_staff() returns void language plpgsql stable security definer set search_path = public as $$
begin if not public.is_staff() then raise exception 'FORBIDDEN'; end if; end $$;
create or replace function public.require_admin() returns void language plpgsql stable security definer set search_path = public as $$
begin if not public.is_admin() then raise exception 'FORBIDDEN'; end if; end $$;
create or replace function public.setting_int(k text, d int) returns int language sql stable security definer set search_path = public as $$
  select coalesce((select (value #>> '{}')::int from public.site_settings where key = k), d) $$;
create or replace function public.log_audit(p_action text, p_entity text, p_id text, p_detail jsonb default null) returns void
language sql security definer set search_path = public as $$
  insert into public.audit_log(actor, action, entity, entity_id, detail) values (auth.uid(), p_action, p_entity, p_id, p_detail) $$;

create or replace function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;
create trigger orders_touch before update on public.orders for each row execute function public.touch_updated_at();

-- Nhật ký tự động cho các bảng cấu hình/giá do admin sửa trực tiếp
create or replace function public.audit_row() returns trigger language plpgsql security definer set search_path = public as $$
declare j jsonb := case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end;
begin
  insert into public.audit_log(actor, action, entity, entity_id, detail)
  values (auth.uid(), tg_op, tg_table_name, coalesce(j->>'id', j->>'key', j->>'product_id', j->>'code'), j);
  return null;
end $$;
create trigger audit_products after insert or update or delete on public.products for each row execute function public.audit_row();
create trigger audit_costs after insert or update or delete on public.product_costs for each row execute function public.audit_row();
create trigger audit_coupons after insert or update or delete on public.coupons for each row execute function public.audit_row();
create trigger audit_settings after insert or update or delete on public.site_settings for each row execute function public.audit_row();
create trigger audit_tiers after insert or update or delete on public.vip_tiers for each row execute function public.audit_row();

-- ---------- VIP Hybrid ----------
-- Chi tiêu 12 tháng: chỉ đơn đã giao + đã thanh toán đủ, trừ phần đã hoàn.
create or replace function public.vip_spend_12m(p_user uuid) returns bigint language sql stable security definer set search_path = public as $$
  select coalesce(sum(greatest(o.total - coalesce((select sum(p.amount) from public.payments p
            where p.order_id = o.id and p.kind = 'refund' and p.status = 'confirmed'), 0), 0)), 0)::bigint
  from public.orders o
  where o.user_id = p_user and o.status = 'delivered' and o.delivered_at > now() - interval '12 months'
    and o.deposit_status = 'confirmed'
    and (o.balance_amount = 0 or exists (select 1 from public.payments p where p.order_id = o.id and p.kind = 'balance_cod' and p.status = 'confirmed')) $$;

create or replace function public.active_tier(p_user uuid) returns text language sql stable security definer set search_path = public as $$
  select code from public.vip_tiers where min_spend_12m <= public.vip_spend_12m(p_user) order by min_spend_12m desc limit 1 $$;

create or replace function public.refresh_highest_tier(p_user uuid) returns void language plpgsql security definer set search_path = public as $$
declare t text := public.active_tier(p_user); cur text;
begin
  select highest_tier into cur from public.profiles where id = p_user;
  if t is not null and (cur is null or (select sort from public.vip_tiers where code = t) > (select sort from public.vip_tiers where code = cur)) then
    update public.profiles set highest_tier = t where id = p_user;
  end if;
end $$;

create or replace function public.my_vip() returns jsonb language plpgsql stable security definer set search_path = public as $$
declare uid uuid := auth.uid(); spend bigint; t text; nxt record; pr record;
begin
  if uid is null then raise exception 'AUTH_REQUIRED'; end if;
  spend := public.vip_spend_12m(uid); t := public.active_tier(uid);
  select * into pr from public.profiles where id = uid;
  select code, name, min_spend_12m into nxt from public.vip_tiers
    where min_spend_12m > spend order by min_spend_12m asc limit 1;
  return jsonb_build_object('active_tier', t, 'highest_tier', pr.highest_tier, 'spend_12m', spend,
    'points', pr.points_balance, 'referral_code', pr.referral_code,
    'next_tier', nxt.name, 'next_threshold', nxt.min_spend_12m,
    'tiers', (select jsonb_agg(jsonb_build_object('code', code, 'name', name, 'min', min_spend_12m, 'mult', points_multiplier, 'perks', perks) order by sort) from public.vip_tiers));
end $$;

-- ---------- Coupon (xem trước, KHÔNG khóa dòng; kiểm tra thật nằm trong place_order) ----------
create or replace function public.coupon_discount(c public.coupons, sub bigint) returns bigint language sql immutable as $$
  select least(sub, case when c.kind = 'percent'
      then least(floor(sub * c.value / 100.0)::bigint, coalesce(c.max_discount, 2147483647))
      else c.value end)::bigint $$;

create or replace function public.preview_coupon(p_code text, p_subtotal bigint) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare c public.coupons; uid uuid := auth.uid();
begin
  select * into c from public.coupons where code = upper(trim(coalesce(p_code, '')));
  if not found or not c.active then return jsonb_build_object('valid', false, 'reason', 'COUPON_INVALID'); end if;
  if (c.starts_at is not null and c.starts_at > now()) or (c.ends_at is not null and c.ends_at < now()) then
    return jsonb_build_object('valid', false, 'reason', 'COUPON_EXPIRED'); end if;
  if c.usage_limit is not null and c.used_count >= c.usage_limit then
    return jsonb_build_object('valid', false, 'reason', 'COUPON_EXHAUSTED'); end if;
  if p_subtotal < c.min_subtotal then
    return jsonb_build_object('valid', false, 'reason', 'COUPON_MIN_SUBTOTAL', 'min', c.min_subtotal); end if;
  if uid is not null and (select count(*) from public.coupon_redemptions r where r.coupon_id = c.id and r.user_id = uid) >= c.per_user_limit then
    return jsonb_build_object('valid', false, 'reason', 'COUPON_ALREADY_USED'); end if;
  return jsonb_build_object('valid', true, 'code', c.code, 'discount', public.coupon_discount(c, p_subtotal));
end $$;

-- ---------- ĐẶT HÀNG: giá, tồn kho, voucher, điểm đều tính lại ở server ----------
create or replace function public.place_order(
  p_items jsonb, p_name text, p_phone text, p_province text, p_ward text, p_street text,
  p_note text, p_pay_method text, p_coupon text default null, p_points int default 0, p_idem text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  it jsonb; r record; qty int; k text; seen text[] := '{}';
  sub bigint := 0; disc bigint := 0; pdisc bigint := 0; total bigint; dep bigint; bal bigint;
  dep_pct int := public.setting_int('deposit_percent', 30);
  vnd_pt int := greatest(public.setting_int('redeem_vnd_per_point', 500), 1);
  c public.coupons; has_c boolean := false; pts_bal int; max_pts int;
  lines jsonb := '[]'::jsonb; oid uuid := gen_random_uuid(); ocode text;
  ex public.orders; had_prior boolean;
begin
  if uid is null then raise exception 'AUTH_REQUIRED'; end if;
  p_points := coalesce(p_points, 0);
  if p_idem is not null then
    select * into ex from public.orders where user_id = uid and idem_key = p_idem;
    if found then return jsonb_build_object('code', ex.code, 'total', ex.total, 'deposit', ex.deposit_amount,
      'balance', ex.balance_amount, 'status', ex.status, 'duplicate', true); end if;
  end if;
  if coalesce(p_phone, '') !~ '^0[0-9]{9}$' then raise exception 'INVALID_PHONE'; end if;
  if length(trim(coalesce(p_name, ''))) < 2 or length(coalesce(p_province, '')) = 0
     or length(coalesce(p_ward, '')) = 0 or length(trim(coalesce(p_street, ''))) < 3 then raise exception 'INVALID_ADDRESS'; end if;
  if p_pay_method not in ('cod_balance', 'bank_transfer_balance') then raise exception 'INVALID_PAY_METHOD'; end if;
  if p_points < 0 then raise exception 'INVALID_POINTS'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 or jsonb_array_length(p_items) > 30 then
    raise exception 'INVALID_ITEMS'; end if;
  if (select count(*) from public.orders where user_id = uid and status = 'pending') >= 5 then
    raise exception 'TOO_MANY_PENDING_ORDERS'; end if;

  -- Duyệt từng dòng theo thứ tự ổn định để giảm deadlock; khóa dòng tồn kho.
  for it in select value from jsonb_array_elements(p_items) order by value->>'variant_id', value->>'size' loop
    qty := (it->>'qty')::int;
    if qty is null or qty < 1 or qty > 20 then raise exception 'INVALID_QTY'; end if;
    k := (it->>'variant_id') || '|' || (it->>'size');
    if k = any(seen) then raise exception 'DUPLICATE_LINE'; end if;
    seen := seen || k;
    select vs.id as size_id, vs.stock, pv.id as variant_id, pv.name as variant_name, pv.sku as vsku,
           p.id as product_id, p.name as pname, p.price, p.status
      into r
      from public.variant_sizes vs
      join public.product_variants pv on pv.id = vs.variant_id
      join public.products p on p.id = pv.product_id
     where pv.id = (it->>'variant_id')::uuid and vs.size = it->>'size'
       for update of vs;
    if not found then raise exception 'ITEM_NOT_FOUND'; end if;
    if r.status <> 'active' then raise exception 'PRODUCT_UNAVAILABLE'; end if;
    if r.stock < qty then raise exception 'OUT_OF_STOCK:%', r.pname; end if;
    update public.variant_sizes set stock = stock - qty where id = r.size_id;
    sub := sub + r.price::bigint * qty;
    lines := lines || jsonb_build_object('product_id', r.product_id, 'variant_id', r.variant_id, 'size', it->>'size',
      'pname', r.pname, 'vname', r.variant_name, 'sku', r.vsku, 'price', r.price, 'qty', qty);
  end loop;

  if p_coupon is not null and length(trim(p_coupon)) > 0 then
    select * into c from public.coupons where code = upper(trim(p_coupon)) for update;
    if not found or not c.active then raise exception 'COUPON_INVALID'; end if;
    if (c.starts_at is not null and c.starts_at > now()) or (c.ends_at is not null and c.ends_at < now()) then raise exception 'COUPON_EXPIRED'; end if;
    if c.usage_limit is not null and c.used_count >= c.usage_limit then raise exception 'COUPON_EXHAUSTED'; end if;
    if sub < c.min_subtotal then raise exception 'COUPON_MIN_SUBTOTAL:%', c.min_subtotal; end if;
    if (select count(*) from public.coupon_redemptions where coupon_id = c.id and user_id = uid) >= c.per_user_limit then raise exception 'COUPON_ALREADY_USED'; end if;
    if c.min_tier is not null and coalesce((select sort from public.vip_tiers where code = public.active_tier(uid)), 0)
         < (select sort from public.vip_tiers where code = c.min_tier) then raise exception 'COUPON_TIER'; end if;
    disc := public.coupon_discount(c, sub); has_c := true;
  end if;

  if p_points > 0 then
    select points_balance into pts_bal from public.profiles where id = uid for update;
    if p_points > pts_bal then raise exception 'NOT_ENOUGH_POINTS'; end if;
    max_pts := floor(((sub - disc) * public.setting_int('max_redeem_percent', 30) / 100.0) / vnd_pt)::int;
    if p_points > max_pts then raise exception 'POINTS_OVER_LIMIT:%', max_pts; end if;
    pdisc := p_points::bigint * vnd_pt;
  end if;

  total := sub - disc - pdisc;
  dep := least(total, (ceil(total * dep_pct / 100000.0))::bigint * 1000);
  bal := total - dep;
  ocode := 'VS' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10));

  insert into public.orders(id, code, user_id, idem_key, customer_name, phone, province, ward, street, note, pay_method,
      subtotal, discount, points_discount, total, coupon_code, points_used, deposit_percent, deposit_amount, balance_amount)
  values (oid, ocode, uid, p_idem, left(trim(p_name), 120), p_phone, p_province, p_ward, left(trim(p_street), 200),
      left(p_note, 500), p_pay_method, sub, disc, pdisc, total, case when has_c then c.code end, p_points,
      dep_pct, dep, bal);

  insert into public.order_items(order_id, product_id, variant_id, size, product_name, variant_name, sku, unit_price, qty, line_total)
  select oid, (l->>'product_id')::uuid, (l->>'variant_id')::uuid, l->>'size', l->>'pname', l->>'vname', l->>'sku',
         (l->>'price')::int, (l->>'qty')::int, (l->>'price')::int * (l->>'qty')::int
  from jsonb_array_elements(lines) l;

  insert into public.order_events(order_id, status, note, actor) values (oid, 'pending', 'Khách đặt hàng', uid);
  if has_c then
    update public.coupons set used_count = used_count + 1 where id = c.id;
    insert into public.coupon_redemptions(coupon_id, user_id, order_id) values (c.id, uid, oid);
  end if;
  if p_points > 0 then
    insert into public.loyalty_ledger(user_id, delta, reason, order_id) values (uid, -p_points, 'redeem_order', oid);
  end if;
  delete from public.cart_snapshots where user_id = uid;
  select exists (select 1 from public.orders where user_id = uid and id <> oid) into had_prior;
  insert into public.events(user_id, name, props) values (uid, 'purchase', jsonb_build_object('order', ocode, 'total', total));
  if had_prior then insert into public.events(user_id, name, props) values (uid, 'repeat_purchase', jsonb_build_object('order', ocode)); end if;

  return jsonb_build_object('code', ocode, 'subtotal', sub, 'discount', disc, 'points_discount', pdisc, 'total', total,
    'deposit', dep, 'balance', bal, 'deposit_percent', dep_pct, 'status', 'pending');
end $$;

-- ---------- Tra cứu đơn (khách chưa đăng nhập: cần mã đơn + SĐT) ----------
create or replace function public.track_order(p_code text, p_phone text) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare o public.orders;
begin
  select * into o from public.orders where code = upper(trim(coalesce(p_code, '')))
     and phone = regexp_replace(coalesce(p_phone, ''), '\D', '', 'g');
  if not found then return null; end if;
  return jsonb_build_object('code', o.code, 'status', o.status, 'deposit_status', o.deposit_status,
    'total', o.total, 'deposit', o.deposit_amount, 'balance', o.balance_amount, 'pay_method', o.pay_method,
    'carrier', o.carrier, 'tracking_code', o.tracking_code, 'eta_date', o.eta_date, 'created_at', o.created_at,
    'events', (select coalesce(jsonb_agg(jsonb_build_object('status', e.status, 'at', e.created_at, 'note', e.note) order by e.created_at), '[]'::jsonb)
               from public.order_events e where e.order_id = o.id),
    'items', (select coalesce(jsonb_agg(jsonb_build_object('name', i.product_name, 'variant', i.variant_name, 'size', i.size, 'qty', i.qty, 'price', i.unit_price)), '[]'::jsonb)
               from public.order_items i where i.order_id = o.id));
end $$;

-- ---------- Khách báo đã chuyển cọc (CHƯA phải bằng chứng; admin đối soát) ----------
create or replace function public.report_deposit_transfer(p_order uuid, p_reference text) returns void
language plpgsql security definer set search_path = public as $$
declare o public.orders;
begin
  select * into o from public.orders where id = p_order and user_id = auth.uid() for update;
  if not found then raise exception 'ORDER_NOT_FOUND'; end if;
  if o.deposit_status not in ('unpaid', 'pending_review') or o.status in ('cancelled', 'refunded') then raise exception 'INVALID_STATE'; end if;
  if o.deposit_amount <= 0 then raise exception 'NO_DEPOSIT_REQUIRED'; end if;
  if not exists (select 1 from public.payments where order_id = o.id and kind = 'deposit' and status = 'pending') then
    insert into public.payments(order_id, kind, amount, reference) values (o.id, 'deposit', o.deposit_amount, left(p_reference, 200));
  end if;
  update public.orders set deposit_status = 'pending_review' where id = o.id;
  insert into public.order_events(order_id, status, note, actor) values (o.id, o.status, 'Khách báo đã chuyển cọc, chờ shop đối soát', auth.uid());
end $$;

-- ---------- Hoàn tất thưởng khi đơn đã giao + thanh toán đủ ----------
create or replace function public.finalize_order_rewards(p_order uuid) returns void
language plpgsql security definer set search_path = public as $$
declare o public.orders; mult numeric; pts int; ref public.referrals; rp int := public.setting_int('referral_reward_points', 100);
begin
  select * into o from public.orders where id = p_order for update;
  if o.points_awarded or o.status <> 'delivered' then return; end if;
  mult := coalesce((select points_multiplier from public.vip_tiers where code = public.active_tier(o.user_id)), 1);
  pts := floor((o.total / greatest(public.setting_int('earn_vnd_per_point', 10000), 1)::numeric) * mult)::int;
  if pts > 0 then insert into public.loyalty_ledger(user_id, delta, reason, order_id) values (o.user_id, pts, 'order_reward', o.id); end if;
  update public.orders set points_awarded = true where id = o.id;
  update public.profiles set last_order_at = now() where id = o.user_id;
  perform public.refresh_highest_tier(o.user_id);
  select * into ref from public.referrals where referee_id = o.user_id and status = 'pending';
  if found then
    update public.referrals set status = 'rewarded', reward_points = rp where id = ref.id;
    if rp > 0 then
      insert into public.loyalty_ledger(user_id, delta, reason) values (ref.referrer_id, rp, 'referral_reward'), (ref.referee_id, rp, 'referral_reward');
    end if;
  end if;
end $$;

-- ---------- Admin/Staff: đổi trạng thái đơn (máy trạng thái ở server) ----------
create or replace function public.admin_set_order_status(p_order uuid, p_status text, p_note text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  o public.orders; allowed text[] := array[
    'pending>confirmed','pending>cancelled','confirmed>sourcing','confirmed>cancelled',
    'sourcing>supplier_ordered','sourcing>cancelled','supplier_ordered>in_transit_vn','supplier_ordered>cancelled',
    'in_transit_vn>inspecting','inspecting>shipping','shipping>delivered','shipping>return_requested',
    'delivered>return_requested','return_requested>delivered'];
  needs_refund boolean := false;
begin
  perform public.require_staff();
  select * into o from public.orders where id = p_order for update;
  if not found then raise exception 'ORDER_NOT_FOUND'; end if;
  if not ((o.status || '>' || p_status) = any(allowed)) then raise exception 'INVALID_TRANSITION:%>%', o.status, p_status; end if;
  if p_status = 'supplier_ordered' and o.deposit_status <> 'confirmed' and o.deposit_amount > 0 then raise exception 'DEPOSIT_NOT_CONFIRMED'; end if;

  update public.orders set status = p_status where id = o.id;
  if p_status = 'supplier_ordered' then
    update public.orders set supplier_ordered_at = now(), eta_date = current_date + public.setting_int('lead_days', 15) where id = o.id;
  elsif p_status = 'delivered' then
    update public.orders set delivered_at = coalesce(delivered_at, now()) where id = o.id;
    if o.balance_amount > 0 and not exists (select 1 from public.payments where order_id = o.id and kind = 'balance_cod') then
      insert into public.payments(order_id, kind, amount, reference) values (o.id, 'balance_cod', o.balance_amount, 'COD/đối soát khi giao');
    end if;
    if o.balance_amount = 0 then perform public.finalize_order_rewards(o.id); end if;
  elsif p_status = 'cancelled' then
    update public.variant_sizes vs set stock = vs.stock + i.qty
      from public.order_items i where i.order_id = o.id and vs.variant_id = i.variant_id and vs.size = i.size;
    if o.coupon_code is not null then
      delete from public.coupon_redemptions where order_id = o.id;
      update public.coupons set used_count = greatest(used_count - 1, 0) where code = o.coupon_code;
    end if;
    if o.points_used > 0 then
      insert into public.loyalty_ledger(user_id, delta, reason, order_id) values (o.user_id, o.points_used, 'refund_redeem', o.id);
    end if;
    needs_refund := o.deposit_status = 'confirmed';
  end if;
  insert into public.order_events(order_id, status, note, actor) values (o.id, p_status, p_note, auth.uid());
  perform public.log_audit('order_status', 'orders', o.code, jsonb_build_object('from', o.status, 'to', p_status));
  return jsonb_build_object('ok', true, 'status', p_status, 'needs_refund', needs_refund);
end $$;

create or replace function public.admin_set_shipping(p_order uuid, p_carrier text, p_tracking text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public.require_staff();
  update public.orders set carrier = left(p_carrier, 60), tracking_code = left(p_tracking, 80) where id = p_order;
  if not found then raise exception 'ORDER_NOT_FOUND'; end if;
  insert into public.order_events(order_id, status, note, actor)
    select id, status, 'Cập nhật vận đơn: ' || coalesce(p_carrier, '') || ' ' || coalesce(p_tracking, ''), auth.uid() from public.orders where id = p_order;
  perform public.log_audit('shipping', 'orders', p_order::text, jsonb_build_object('carrier', p_carrier, 'tracking', p_tracking));
end $$;

create or replace function public.admin_set_internal_note(p_order uuid, p_note text) returns void
language plpgsql security definer set search_path = public as $$
begin perform public.require_staff(); update public.orders set internal_note = left(p_note, 1000) where id = p_order; end $$;

-- ---------- Đối soát thanh toán ----------
create or replace function public.admin_confirm_payment(p_payment uuid) returns void
language plpgsql security definer set search_path = public as $$
declare p public.payments; o public.orders;
begin
  perform public.require_staff();
  select * into p from public.payments where id = p_payment for update;
  if not found or p.status <> 'pending' or p.kind = 'refund' then raise exception 'INVALID_STATE'; end if;
  select * into o from public.orders where id = p.order_id for update;
  update public.payments set status = 'confirmed', confirmed_by = auth.uid(), confirmed_at = now() where id = p.id;
  if p.kind = 'deposit' then
    update public.orders set deposit_status = 'confirmed' where id = o.id;
    insert into public.ledger_entries(direction, kind, amount, order_id, payment_id, note, created_by)
      values ('credit', 'deposit_received', p.amount, o.id, p.id, 'Xác nhận cọc ' || o.code, auth.uid());
    insert into public.order_events(order_id, status, note, actor) values (o.id, o.status, 'Shop đã xác nhận nhận cọc', auth.uid());
  else
    insert into public.ledger_entries(direction, kind, amount, order_id, payment_id, note, created_by)
      values ('credit', 'cod_received', p.amount, o.id, p.id, 'Đối soát COD ' || o.code, auth.uid());
    perform public.finalize_order_rewards(o.id);
  end if;
  perform public.log_audit('confirm_payment', 'payments', p.id::text, jsonb_build_object('order', o.code, 'amount', p.amount, 'kind', p.kind));
end $$;

create or replace function public.admin_reject_payment(p_payment uuid, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare p public.payments;
begin
  perform public.require_staff();
  select * into p from public.payments where id = p_payment for update;
  if not found or p.status <> 'pending' then raise exception 'INVALID_STATE'; end if;
  update public.payments set status = 'rejected', confirmed_by = auth.uid(), confirmed_at = now() where id = p.id;
  if p.kind = 'deposit' then update public.orders set deposit_status = 'unpaid' where id = p.order_id; end if;
  insert into public.order_events(order_id, status, note, actor) select id, status, coalesce(p_note, 'Shop chưa thấy tiền về, vui lòng kiểm tra lại'), auth.uid() from public.orders where id = p.order_id;
  perform public.log_audit('reject_payment', 'payments', p.id::text, jsonb_build_object('note', p_note));
end $$;

-- ---------- Hoàn tiền (chỉ admin) ----------
create or replace function public.admin_refund(p_order uuid, p_amount int, p_reason text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare o public.orders; received bigint; refunded bigint; pid uuid; rew int;
begin
  perform public.require_admin();
  perform pg_advisory_xact_lock(hashtext('verus_wallet'));
  select * into o from public.orders where id = p_order for update;
  if not found then raise exception 'ORDER_NOT_FOUND'; end if;
  select coalesce(sum(amount), 0) into received from public.payments where order_id = o.id and kind in ('deposit', 'balance_cod') and status = 'confirmed';
  select coalesce(sum(amount), 0) into refunded from public.payments where order_id = o.id and kind = 'refund' and status = 'confirmed';
  if p_amount is null or p_amount <= 0 or p_amount > received - refunded then raise exception 'REFUND_EXCEEDS_RECEIVED'; end if;
  insert into public.payments(order_id, kind, amount, reference, status, confirmed_by, confirmed_at)
    values (o.id, 'refund', p_amount, left(p_reason, 200), 'confirmed', auth.uid(), now()) returning id into pid;
  insert into public.ledger_entries(direction, kind, amount, order_id, payment_id, note, created_by)
    values ('debit', 'refund_paid', p_amount, o.id, pid, 'Hoàn tiền ' || o.code || ': ' || coalesce(p_reason, ''), auth.uid());
  if p_amount = received - refunded then
    update public.orders set deposit_status = 'refunded' where id = o.id;
    if o.status = 'return_requested' then update public.orders set status = 'refunded' where id = o.id; end if;
    select coalesce(sum(delta), 0) into rew from public.loyalty_ledger where order_id = o.id and reason = 'order_reward';
    if rew > 0 then
      insert into public.loyalty_ledger(user_id, delta, reason, order_id)
        select o.user_id, -least(rew, points_balance), 'reverse_reward', o.id from public.profiles where id = o.user_id and points_balance > 0;
    end if;
  end if;
  insert into public.order_events(order_id, status, note, actor) values (o.id, (select status from public.orders where id = o.id), 'Hoàn tiền ' || p_amount || ' VNĐ', auth.uid());
  insert into public.events(user_id, name, props) values (o.user_id, 'refund', jsonb_build_object('order', o.code, 'amount', p_amount));
  perform public.log_audit('refund', 'orders', o.code, jsonb_build_object('amount', p_amount, 'reason', p_reason));
  return jsonb_build_object('ok', true);
end $$;

-- ---------- Ví & rút tiền (chỉ admin; số dư tính từ sổ cái, không từ frontend) ----------
create or replace function public.wallet_summary() returns jsonb language plpgsql stable security definer set search_path = public as $$
declare cr bigint; db bigint; rsv bigint;
begin
  perform public.require_admin();
  select coalesce(sum(amount) filter (where direction = 'credit'), 0), coalesce(sum(amount) filter (where direction = 'debit'), 0) into cr, db from public.ledger_entries;
  select coalesce(sum(amount), 0) into rsv from public.withdrawal_requests where status in ('pending', 'approved');
  return jsonb_build_object('credits', cr, 'debits', db, 'reserved_for_withdrawal', rsv, 'available', cr - db - rsv,
    'cod_pending_reconcile', (select coalesce(sum(amount), 0) from public.payments where kind = 'balance_cod' and status = 'pending'),
    'deposit_pending_review', (select coalesce(sum(amount), 0) from public.payments where kind = 'deposit' and status = 'pending'));
end $$;

create or replace function public.admin_request_withdrawal(p_amount bigint, p_bank text, p_owner text, p_hint text) returns uuid
language plpgsql security definer set search_path = public as $$
declare w jsonb; wid uuid;
begin
  perform public.require_admin();
  perform pg_advisory_xact_lock(hashtext('verus_wallet'));
  w := public.wallet_summary();
  if p_amount is null or p_amount <= 0 or p_amount > (w->>'available')::bigint then raise exception 'INSUFFICIENT_AVAILABLE_BALANCE'; end if;
  if length(coalesce(p_hint, '')) > 4 then raise exception 'ONLY_LAST4_ALLOWED'; end if;
  insert into public.withdrawal_requests(amount, bank_name, account_owner, account_hint, requested_by)
    values (p_amount, left(p_bank, 80), left(p_owner, 120), p_hint, auth.uid()) returning withdrawal_requests.id into wid;
  perform public.log_audit('withdraw_request', 'withdrawal_requests', wid::text, jsonb_build_object('amount', p_amount));
  return wid;
end $$;

create or replace function public.admin_decide_withdrawal(p_id uuid, p_decision text, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare w public.withdrawal_requests;
begin
  perform public.require_admin();
  perform pg_advisory_xact_lock(hashtext('verus_wallet'));
  select * into w from public.withdrawal_requests where id = p_id for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if not ((w.status || '>' || p_decision) = any(array['pending>approved', 'pending>rejected', 'approved>rejected', 'approved>paid_manually'])) then
    raise exception 'INVALID_TRANSITION'; end if;
  update public.withdrawal_requests set status = p_decision, decided_by = auth.uid(), decided_at = now(), note = p_note where id = w.id;
  if p_decision = 'paid_manually' then   -- chỉ ghi nhận SAU KHI admin đã tự chuyển khoản ngoài hệ thống
    insert into public.ledger_entries(direction, kind, amount, note, created_by) values ('debit', 'withdrawal_paid', w.amount, 'Rút tiền ' || w.id, auth.uid());
  end if;
  perform public.log_audit('withdraw_' || p_decision, 'withdrawal_requests', w.id::text, jsonb_build_object('amount', w.amount));
end $$;

-- ---------- Đánh giá từ người mua thật ----------
create or replace function public.submit_review(p_order_item uuid, p_rating int, p_title text, p_body text, p_photos text[] default '{}') returns uuid
language plpgsql security definer set search_path = public as $$
declare i record; rid uuid;
begin
  select oi.id, oi.product_id, o.user_id, o.status into i from public.order_items oi join public.orders o on o.id = oi.order_id where oi.id = p_order_item;
  if not found or i.user_id <> auth.uid() then raise exception 'NOT_YOUR_ITEM'; end if;
  if i.status <> 'delivered' then raise exception 'ORDER_NOT_DELIVERED'; end if;
  if coalesce(array_length(p_photos, 1), 0) > 4 then raise exception 'TOO_MANY_PHOTOS'; end if;
  insert into public.reviews(product_id, user_id, order_item_id, rating, title, body, photo_urls)
    values (i.product_id, auth.uid(), i.id, p_rating, left(p_title, 120), p_body, coalesce(p_photos, '{}')) returning id into rid;
  return rid;
end $$;

create or replace function public.admin_moderate_review(p_id uuid, p_status text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public.require_staff();
  if p_status not in ('published', 'rejected', 'pending') then raise exception 'INVALID_STATUS'; end if;
  update public.reviews set status = p_status where id = p_id;
  perform public.log_audit('review_' || p_status, 'reviews', p_id::text);
end $$;

-- ---------- Phân quyền nhân sự ----------
create or replace function public.admin_set_role(p_user uuid, p_role text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public.require_admin();
  if p_role not in ('customer', 'staff', 'admin') then raise exception 'INVALID_ROLE'; end if;
  if p_user = auth.uid() and p_role <> 'admin' then raise exception 'CANNOT_DEMOTE_SELF'; end if;
  update public.profiles set role = p_role where id = p_user;
  perform public.log_audit('set_role', 'profiles', p_user::text, jsonb_build_object('role', p_role));
end $$;

-- ---------- CRM ----------
create or replace function public.crm_segment(p_user uuid) returns text language sql stable security definer set search_path = public as $$
  select case
    when coalesce((select sort from public.vip_tiers where code = public.active_tier(p_user)), 0) >= 3 then 'vip'
    when exists (select 1 from public.cart_snapshots c where c.user_id = p_user and jsonb_array_length(c.items) > 0 and c.updated_at < now() - interval '1 day') then 'abandoned_cart'
    when (select last_order_at from public.profiles where id = p_user) < now() - interval '90 days' then 'lapsed'
    when (select count(*) from public.orders where user_id = p_user and status = 'delivered') >= 2 then 'repeat'
    when (select count(*) from public.orders where user_id = p_user and status not in ('cancelled')) >= 1 then 'first_time'
    else 'new' end $$;

create or replace function public.admin_crm() returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.require_staff();
  return coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'name', p.full_name, 'phone', p.phone, 'segment', public.crm_segment(p.id),
      'tier', public.active_tier(p.id), 'points', p.points_balance, 'opt_in', p.marketing_opt_in, 'last_order_at', p.last_order_at,
      'spend_12m', public.vip_spend_12m(p.id)) order by p.created_at desc) from public.profiles p where p.role = 'customer'), '[]'::jsonb);
end $$;

-- Xếp hàng nội dung CRM: chỉ khách đã đồng ý nhận tin, tối đa 1 tin/7 ngày. Gửi thật cần dịch vụ email/Zalo ngoài.
create or replace function public.admin_queue_crm(p_segment text, p_template text) returns int
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  perform public.require_admin();
  with ins as (
    insert into public.crm_outbox(user_id, segment, template)
    select p.id, p_segment, left(p_template, 60) from public.profiles p
     where p.role = 'customer' and p.marketing_opt_in and public.crm_segment(p.id) = p_segment
       and not exists (select 1 from public.crm_outbox o where o.user_id = p.id and o.created_at > now() - interval '7 days')
    returning 1) select count(*) into n from ins;
  perform public.log_audit('crm_queue', 'crm_outbox', p_segment, jsonb_build_object('count', n));
  return n;
end $$;

-- ---------- Thống kê ----------
create or replace function public.admin_dashboard(p_days int default 30) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare since timestamptz := now() - (greatest(least(p_days, 365), 1) || ' days')::interval;
begin
  perform public.require_staff();
  return jsonb_build_object(
    'orders_by_status', (select coalesce(jsonb_object_agg(status, n), '{}'::jsonb) from (select status, count(*) n from public.orders where created_at >= since group by status) s),
    'gross_orders_value', (select coalesce(sum(total), 0) from public.orders where created_at >= since and status not in ('cancelled', 'refunded')),
    'confirmed_deposits', (select coalesce(sum(amount), 0) from public.payments where kind = 'deposit' and status = 'confirmed' and confirmed_at >= since),
    'funnel', (select coalesce(jsonb_object_agg(name, n), '{}'::jsonb) from (select name, count(*) n from public.events where created_at >= since group by name) f),
    'top_products', (select coalesce(jsonb_agg(t), '[]'::jsonb) from (select i.product_name as name, sum(i.qty) as qty, sum(i.line_total) as revenue
        from public.order_items i join public.orders o on o.id = i.order_id where o.created_at >= since and o.status not in ('cancelled') group by i.product_name order by 2 desc limit 5) t),
    'customers', (select count(*) from public.profiles where role = 'customer'),
    'repeat_customers', (select count(*) from (select user_id from public.orders where status = 'delivered' group by user_id having count(*) >= 2) r));
end $$;

-- END 002_functions.sql


-- ============================================================
-- BEGIN 003_rls.sql
-- ============================================================
-- =====================================================================
-- VERUS STORE V6 — 003_rls.sql
-- Mặc định TỪ CHỐI. Chỉ mở đúng những gì cần.
-- Bảng nhạy cảm (orders, payments, ledger, loyalty, ...) KHÔNG có policy ghi
-- cho trình duyệt: mọi thay đổi bắt buộc đi qua hàm RPC ở 002.
-- =====================================================================

-- 1) Bật RLS trên mọi bảng
do $$ declare t text; begin
  for t in select tablename from pg_tables where schemaname = 'public' loop
    execute format('alter table public.%I enable row level security', t);
  end loop; end $$;

-- 2) Thu hồi quyền mặc định của Supabase, rồi cấp lại tối thiểu
revoke all on all tables in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke all on all functions in schema public from anon, authenticated, public;
alter default privileges in schema public revoke all on tables from anon, authenticated;
alter default privileges in schema public revoke all on functions from anon, authenticated, public;

-- 3) Quyền đọc công khai (không cần đăng nhập): vitrin
grant select on public.categories, public.products, public.product_variants, public.variant_sizes,
  public.outfits, public.outfit_items, public.vip_tiers, public.site_settings to anon, authenticated;

create policy cat_read   on public.categories       for select using (true);
create policy prod_read  on public.products         for select using (status = 'active' or public.is_staff());
create policy var_read   on public.product_variants for select using (exists (select 1 from public.products p where p.id = product_id and (p.status = 'active' or public.is_staff())));
create policy size_read  on public.variant_sizes    for select using (exists (select 1 from public.product_variants v join public.products p on p.id = v.product_id where v.id = variant_id and (p.status = 'active' or public.is_staff())));
create policy outfit_read on public.outfits         for select using (active or public.is_staff());
create policy oitem_read on public.outfit_items     for select using (exists (select 1 from public.outfits o where o.id = outfit_id and (o.active or public.is_staff())));
create policy tier_read  on public.vip_tiers        for select using (true);
create policy set_read   on public.site_settings    for select using (is_public or public.is_admin());

-- 4) Ghi dữ liệu cửa hàng: chỉ ADMIN (kiểm tra ở policy, không tin client)
grant insert, update, delete on public.categories, public.products, public.product_variants, public.variant_sizes,
  public.outfits, public.outfit_items, public.vip_tiers, public.site_settings, public.coupons to authenticated;
create policy cat_w    on public.categories       for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy prod_w   on public.products         for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy var_w    on public.product_variants for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy size_w   on public.variant_sizes    for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy outfit_w on public.outfits          for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy oitem_w  on public.outfit_items     for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy tier_w   on public.vip_tiers        for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy set_w    on public.site_settings    for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Giá vốn & coupon: khách không đọc được (giá vốn không bao giờ lộ ra giao diện khách)
grant select, insert, update, delete on public.product_costs to authenticated;
create policy cost_admin on public.product_costs for all to authenticated using (public.is_admin()) with check (public.is_admin());
grant select on public.coupons to authenticated;
create policy coupon_read  on public.coupons for select to authenticated using (public.is_staff());
create policy coupon_write on public.coupons for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- 5) Hồ sơ: đọc của mình; sửa CHỈ các cột an toàn (role/điểm/hạng bị chặn bằng quyền cột)
grant select on public.profiles to authenticated;
grant update (full_name, phone, birthday, marketing_opt_in) on public.profiles to authenticated;
create policy prof_read   on public.profiles for select to authenticated using (id = auth.uid() or public.is_staff());
create policy prof_update on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

grant select, insert, update, delete on public.addresses to authenticated;
create policy addr_own on public.addresses for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- 6) Đơn hàng: chủ đơn đọc đơn của mình, staff đọc tất cả. KHÔNG có policy insert/update/delete.
grant select on public.orders, public.order_items, public.order_events, public.payments to authenticated;
create policy ord_read  on public.orders       for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy oi_read   on public.order_items  for select to authenticated using (exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_staff())));
create policy oe_read   on public.order_events for select to authenticated using (exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_staff())));
create policy pay_read  on public.payments     for select to authenticated using (exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_staff())));

-- 7) Tài chính nội bộ: chỉ admin đọc; không ai ghi trực tiếp
grant select on public.ledger_entries, public.withdrawal_requests, public.audit_log, public.crm_outbox, public.coupon_redemptions to authenticated;
create policy led_read  on public.ledger_entries     for select to authenticated using (public.is_admin());
create policy wd_read   on public.withdrawal_requests for select to authenticated using (public.is_admin());
create policy aud_read  on public.audit_log          for select to authenticated using (public.is_admin());
create policy crm_read  on public.crm_outbox         for select to authenticated using (public.is_admin());
create policy red_read  on public.coupon_redemptions for select to authenticated using (public.is_staff());

-- 8) Điểm & giới thiệu: chỉ đọc của mình
grant select on public.loyalty_ledger, public.referrals to authenticated;
create policy loy_read on public.loyalty_ledger for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy ref_read on public.referrals      for select to authenticated using (referrer_id = auth.uid() or referee_id = auth.uid() or public.is_staff());

-- 9) Đánh giá: công khai chỉ khi đã duyệt; tạo qua RPC submit_review (xác minh đã mua)
grant select on public.reviews to authenticated;
create policy rev_read on public.reviews for select to authenticated using (user_id = auth.uid() or public.is_staff());
create or replace view public.public_reviews as
  select r.id, r.product_id, r.rating, r.title, r.body, r.photo_urls, r.created_at,
         split_part(coalesce(nullif(p.full_name, ''), 'Khách hàng'), ' ', -1) as reviewer, true as verified_purchase
  from public.reviews r join public.profiles p on p.id = r.user_id where r.status = 'published';
create or replace view public.product_rating_stats as
  select product_id, count(*)::int as review_count, round(avg(rating)::numeric, 1) as rating_avg
  from public.reviews where status = 'published' group by product_id;
grant select on public.public_reviews, public.product_rating_stats to anon, authenticated;

-- 10) Yêu thích, giỏ: của chính mình
grant select, insert, update, delete on public.wishlist, public.cart_snapshots to authenticated;
create policy wl_own   on public.wishlist       for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy cart_own on public.cart_snapshots for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- 11) Chat / khiếu nại
grant select, insert on public.chat_threads, public.chat_messages to authenticated;
grant update (status) on public.chat_threads to authenticated;
grant usage, select on sequence public.chat_messages_id_seq to authenticated;
create policy th_read   on public.chat_threads  for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy th_insert on public.chat_threads  for insert to authenticated with check (user_id = auth.uid() and (order_id is null or exists (select 1 from public.orders o where o.id = order_id and o.user_id = auth.uid())));
create policy th_update on public.chat_threads  for update to authenticated using (public.is_staff()) with check (public.is_staff());
create policy msg_read   on public.chat_messages for select to authenticated using (exists (select 1 from public.chat_threads t where t.id = thread_id and (t.user_id = auth.uid() or public.is_staff())));
create policy msg_insert on public.chat_messages for insert to authenticated with check (exists (select 1 from public.chat_threads t where t.id = thread_id and (t.user_id = auth.uid() or public.is_staff())));

-- 12) Sự kiện phân tích: ai cũng ghi được (không gán user giả), chỉ staff đọc
grant insert on public.events to anon, authenticated;
grant usage, select on sequence public.events_id_seq to anon, authenticated;
grant select on public.events to authenticated;
create policy ev_insert on public.events for insert to anon, authenticated with check (user_id is null or user_id = auth.uid());
create policy ev_read   on public.events for select to authenticated using (public.is_staff());

-- 13) Quyền thực thi hàm: mặc định thu hồi; cấp đúng nhóm
grant execute on function public.is_staff(), public.is_admin(), public.setting_int(text, int) to anon, authenticated;
grant execute on function public.preview_coupon(text, bigint), public.track_order(text, text) to anon, authenticated;
grant execute on function public.place_order(jsonb, text, text, text, text, text, text, text, text, int, text),
  public.report_deposit_transfer(uuid, text), public.my_vip(), public.submit_review(uuid, int, text, text, text[]) to authenticated;
grant execute on function public.admin_set_order_status(uuid, text, text), public.admin_set_shipping(uuid, text, text),
  public.admin_set_internal_note(uuid, text), public.admin_confirm_payment(uuid), public.admin_reject_payment(uuid, text),
  public.admin_refund(uuid, int, text), public.wallet_summary(), public.admin_request_withdrawal(bigint, text, text, text),
  public.admin_decide_withdrawal(uuid, text, text), public.admin_moderate_review(uuid, text), public.admin_set_role(uuid, text),
  public.admin_crm(), public.admin_queue_crm(text, text), public.admin_dashboard(int) to authenticated;
-- Các hàm nội bộ (finalize_order_rewards, active_tier, vip_spend_12m, ...) KHÔNG cấp cho client.

-- END 003_rls.sql


-- ============================================================
-- BEGIN seed.sql
-- ============================================================
-- =====================================================================
-- VERUS STORE V6 — seed.sql  (DỮ LIỆU MẪU / DEMO — thay bằng dữ liệu thật trước khi bán)
-- Ngưỡng VIP và quyền lợi là GIẢ ĐỊNH, chỉnh được trong Admin > VIP.
-- =====================================================================
insert into public.site_settings(key, value, is_public) values
  ('shop_name',            '"VERUS STORE"', true),
  ('deposit_percent',      '30', true),
  ('lead_days',            '15', true),
  ('earn_vnd_per_point',   '10000', true),   -- 1 điểm / 10.000đ (chưa nhân hệ số hạng)
  ('redeem_vnd_per_point', '500', true),     -- 1 điểm = 500đ khi dùng ở checkout
  ('max_redeem_percent',   '30', true),      -- tối đa 30% giá trị đơn
  ('referral_reward_points','100', true),
  ('target_profit_default','100000', false),
  ('policy_text', to_jsonb('Khách đặt hàng và thanh toán trước 30% giá trị đơn hàng bằng chuyển khoản QR sau khi shop xác nhận đơn. Shop kiểm tra giao dịch ngân hàng thủ công trước khi xác nhận đã nhận cọc. 70% còn lại thanh toán khi nhận hàng hoặc theo phương thức được hiển thị tại bước đặt hàng. Nếu sản phẩm không thể cung cấp, shop liên hệ khách để thống nhất phương án hoặc hoàn lại khoản tiền đã nhận.'::text), true)
on conflict (key) do nothing;

insert into public.vip_tiers(code, name, min_spend_12m, points_multiplier, perks, sort) values
  ('member','Member',0,1.00,'["Tích điểm mọi đơn","Mã giới thiệu bạn bè"]',1),
  ('silver','Silver',2000000,1.10,'["Voucher sinh nhật (giả định)","Điểm x1.1"]',2),
  ('gold','Gold',5000000,1.25,'["Ưu tiên xem bộ sưu tập mới","Điểm x1.25"]',3),
  ('diamond','Diamond',12000000,1.50,'["Chăm sóc ưu tiên","Điểm x1.5"]',4),
  ('royal','Royal',30000000,2.00,'["Quà theo hạng (giả định)","Điểm x2"]',5)
on conflict (code) do nothing;

insert into public.categories(name, slug, sort) values
 ('Áo','ao',1),('Áo khoác','ao-khoac',2),('Quần','quan',3),('Giày','giay',4),('Dép','dep',5),('Mũ','mu',6),('Phụ kiện','phu-kien',7)
on conflict (name) do nothing;

-- Sản phẩm mẫu (giữ nguyên dữ liệu V5.0; ảnh Unsplash chỉ là minh họa)
with p as (
  insert into public.products(sku,name,category,badge,status,material,fit,care,delivery_note,description_html,style_tags,occasion,styling_tips,size_chart,size_rules,price,compare_price,featured)
  values ('VS-SHORT-001','Quần short camo','Quần','NEW DROP','active','Polyester','Form rộng','Giặt nhẹ, lộn trái khi giặt','Đặt trước khoảng 15 ngày (dự kiến)',
   '<h3>Điểm nổi bật</h3><p>Thiết kế streetwear dễ phối cùng áo thun oversize và sneaker. Vui lòng kiểm tra bảng size và thông số thực tế trước khi đặt.</p><p><b>Lưu ý:</b> Đây là dữ liệu mẫu để minh họa. Hãy thay bằng số đo đã kiểm tra của sản phẩm thật.</p>',
   array['streetwear','casual'],'Đi chơi, cuối tuần','Phối cùng áo thun oversize và sneaker (gợi ý mẫu).',
   '[{"size":"S","waist":"70–76 cm","length":"42 cm"},{"size":"M","waist":"76–82 cm","length":"44 cm"},{"size":"L","waist":"82–88 cm","length":"46 cm"},{"size":"XL","waist":"88–94 cm","length":"48 cm"}]',
   '[{"h_min":155,"h_max":165,"w_min":45,"w_max":55,"size":"S"},{"h_min":160,"h_max":170,"w_min":55,"w_max":65,"size":"M"},{"h_min":165,"h_max":175,"w_min":65,"w_max":75,"size":"L"},{"h_min":170,"h_max":185,"w_min":75,"w_max":90,"size":"XL"}]',
   289000,359000,true) on conflict (sku) do nothing returning id),
c as (insert into public.product_costs(product_id, base_cost, extra_cost, target_profit) select id, 150000, 39000, 100000 from p returning product_id),
v as (
  insert into public.product_variants(product_id,name,sku,image_urls,sort)
  select id,'Camo xanh','VS-SHORT-001-GRN',array['https://images.unsplash.com/photo-1591195853828-11db59a44f6b?auto=format&fit=crop&w=900&q=85'],1 from p
  union all
  select id,'Đen','VS-SHORT-001-BLK',array['https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&w=900&q=85'],2 from p
  returning id, sku)
insert into public.variant_sizes(variant_id,size,stock)
select v.id, s.size, case when v.sku like '%GRN' then s.g else s.b end
from v cross join (values ('S',3,2),('M',4,2),('L',3,2),('XL',2,2)) as s(size,g,b);

insert into public.coupons(code,name,kind,value,min_subtotal,max_discount,usage_limit,per_user_limit,active)
values ('VERUS10','Ưu đãi khai trương','percent',10,200000,50000,100,1,true) on conflict (code) do nothing;

-- Outfit mẫu: tạo thêm trong Admin khi có đủ sản phẩm

-- ---- Sản phẩm MINH HỌA để thử Outfit Builder (ảnh trống → giao diện hiển thị ảnh minh họa). XÓA khi có hàng thật. ----
with p as (
  insert into public.products(sku,name,category,badge,status,material,fit,delivery_note,description_html,style_tags,price)
  values
   ('DEMO-TEE-001','Áo thun oversize (mẫu minh họa)','Áo','DEMO','active','Dữ liệu minh họa','Oversize','Đặt trước khoảng 15 ngày (dự kiến)','<p>Sản phẩm minh họa để thử Outfit Builder.</p>',array['streetwear','casual'],219000),
   ('DEMO-SNK-001','Sneaker trắng (mẫu minh họa)','Giày','DEMO','active','Dữ liệu minh họa',null,'Đặt trước khoảng 15 ngày (dự kiến)','<p>Sản phẩm minh họa.</p>',array['streetwear'],549000),
   ('DEMO-CAP-001','Mũ lưỡi trai (mẫu minh họa)','Mũ','DEMO','active','Dữ liệu minh họa',null,'Đặt trước khoảng 15 ngày (dự kiến)','<p>Sản phẩm minh họa.</p>',array['casual'],149000)
  on conflict (sku) do nothing returning id, sku),
v as (
  insert into public.product_variants(product_id,name,sku,sort)
  select id, case sku when 'DEMO-TEE-001' then 'Trắng' when 'DEMO-SNK-001' then 'Trắng' else 'Đen' end, sku || '-V1', 1 from p returning id, sku)
insert into public.variant_sizes(variant_id,size,stock)
select v.id, s.size, 3 from v join lateral (select unnest(case when v.sku like 'DEMO-SNK%' then array['40','41','42'] when v.sku like 'DEMO-CAP%' then array['Free'] else array['M','L','XL'] end) as size) s on true;

with o as (insert into public.outfits(title,description,style_tag) values ('Street Weekend (minh họa)','Quần camo + áo thun + sneaker. Dữ liệu minh họa.','streetwear') returning id)
insert into public.outfit_items(outfit_id,product_id,sort)
select o.id, p.id, row_number() over () from o, public.products p where p.sku in ('VS-SHORT-001','DEMO-TEE-001','DEMO-SNK-001');

-- END seed.sql


-- ============================================================
-- BEGIN 004_verus_deposit_30_qr.sql
-- ============================================================
-- VERUS STORE: cố định chính sách cọc 30% bằng chuyển khoản QR.
-- Chỉ cập nhật cấu hình chính sách công khai; không chứa thông tin tài khoản ngân hàng.
update public.site_settings
set value = '30'::jsonb, is_public = true
where key = 'deposit_percent';

update public.site_settings
set value = to_jsonb('Khách đặt hàng và thanh toán trước 30% giá trị đơn hàng bằng chuyển khoản QR sau khi shop xác nhận đơn. Shop kiểm tra giao dịch ngân hàng thủ công trước khi xác nhận đã nhận cọc. 70% còn lại thanh toán khi nhận hàng hoặc theo phương thức được hiển thị tại bước đặt hàng. Nếu sản phẩm không thể cung cấp, shop liên hệ khách để thống nhất phương án hoặc hoàn lại khoản tiền đã nhận.'::text), is_public = true
where key = 'policy_text';

-- END 004_verus_deposit_30_qr.sql
