import json,sys
from playwright.sync_api import sync_playwright
URL='file:///home/claude/verus/index.html'
R={};errs=[]
with sync_playwright() as p:
    b=p.chromium.launch();ctx=b.new_context(viewport={'width':390,'height':844},is_mobile=True);pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)[:200]))
    pg.on('console',lambda m:errs.append('CONSOLE '+m.text[:150]) if m.type=='error' and 'ERR_NAME_NOT_RESOLVED' not in m.text and 'ERR_INTERNET' not in m.text and 'Failed to load resource' not in m.text else None)
    pg.on('dialog',lambda d:d.accept())
    pg.goto(URL);pg.wait_for_timeout(700)
    R['mode_badge']=pg.inner_text('#modeBadge')[:60]
    R['mode_online']=pg.evaluate('V.online')
    R['cards']=pg.locator('.product').count()
    R['outfit_cards']=pg.locator('.outfitcard').count()
    R['style_chips']=pg.locator('.stylechips .chip').count()
    R['brandstory']=pg.locator('.brandstory').count()
    R['hscroll']=pg.evaluate('document.documentElement.scrollWidth>document.documentElement.clientWidth')
    R['acc_btn']=pg.inner_text('#accBtn')
    # outfit builder flow
    pg.locator('.outfitcard button').first.click();pg.wait_for_timeout(300)
    R['outfit_modal_rows']=pg.locator('#modalBody .cartitem').count()
    pg.evaluate("vOfAll()");R['outfit_requires_size_cart']=pg.evaluate('db.cart.length')
    sels=pg.locator('#modalBody select')
    for i in range(pg.locator('#modalBody .cartitem').count()):
        row=pg.locator('#modalBody .cartitem').nth(i)
        row.locator('select').nth(1).select_option(index=1)
    pg.evaluate("vOfAll()");pg.wait_for_timeout(200)
    R['outfit_added_cart_lines']=pg.evaluate('db.cart.length')
    # product modal extras survive variant switch
    pg.evaluate("openProduct('p1')");pg.wait_for_timeout(400)
    R['extras_initial']=pg.locator('#vExtra').count()
    pg.evaluate("window.__variant(1)");pg.wait_for_timeout(500)
    R['extras_after_variant_switch']=pg.locator('#vExtra').count()
    pg.fill('#sH','168');pg.fill('#sW','60');pg.evaluate("vSizeAdvice()")
    R['size_advice']=pg.inner_text('#sOut')
    pg.evaluate("closeModal()")
    # style chip filter
    pg.locator('.stylechips .chip').first.click();pg.wait_for_timeout(300)
    R['filtered_cards']=pg.locator('.product').count()
    pg.fill('#search','');pg.evaluate("renderProducts()")
    # demo checkout still works (V5 behaviour)
    pg.evaluate("showCart()");pg.wait_for_timeout(200);pg.evaluate("checkout()");pg.wait_for_timeout(300)
    R['demo_checkout_title']=pg.inner_text('#modalTitle')
    # account in demo explains requirement
    pg.evaluate("closeModal()");pg.click('#accBtn');pg.wait_for_timeout(200)
    R['account_demo_text']=pg.inner_text('#modalBody')[:90]
    # demo admin still opens
    pg.evaluate("closeModal();goAdmin()");pg.wait_for_timeout(300)
    R['admin_active']=pg.evaluate("document.getElementById('admin').classList.contains('active')")
    R['errors']=errs
    print(json.dumps(R,ensure_ascii=False,indent=1))
    pg.screenshot(path='/home/claude/audit/demo_admin.png')
    b.close()
