import json
from playwright.sync_api import sync_playwright
URL='file:///home/claude/verus/index.html'
MOCK=open('/home/claude/verus/tests/mock_supabase.js',encoding='utf-8').read()
R={};errs=[]
def new(b,pre=''):
    ctx=b.new_context(viewport={'width':390,'height':844},is_mobile=True);pg=ctx.new_page()
    pg.add_init_script(pre+MOCK)
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)[:200]));pg.on('dialog',lambda d:d.accept())
    return pg
with sync_playwright() as p:
    b=p.chromium.launch()
    # ---- customer flow
    pg=new(b);pg.goto(URL);pg.wait_for_timeout(800)
    R['online']=pg.evaluate('V.online');R['badge']=pg.inner_text('#modeBadge')[:30]
    R['cards_from_server']=pg.locator('.product').count();R['local_demo_products_absent']=pg.evaluate("!db.products.some(p=>p.id==='d2')")
    R['nav_label']=pg.inner_text('#accBtn')
    pg.evaluate("openProduct('p1')");pg.wait_for_timeout(500)
    R['reviews_shown_in_pdp']=pg.locator('#vExtra .review-card').count()
    pg.get_by_role('button',name='M',exact=True).first.click();pg.get_by_role('button',name='Thêm vào giỏ').first.click();pg.wait_for_timeout(300)
    pg.evaluate("showCart()");pg.wait_for_timeout(200)
    pg.fill('#cartCoupon','VERUS10');pg.evaluate("applyCoupon()");pg.wait_for_timeout(300)
    R['coupon_feedback']=pg.inner_text('#couponFeedback')[:60];R['cart_total_after_coupon']=pg.inner_text('#cartTotal')
    pg.evaluate("checkout()");pg.wait_for_timeout(600)
    R['checkout_title']=pg.inner_text('#modalTitle');R['points_field']=pg.locator('#kPoints').count()
    pg.fill('#kName','Nguyen An');pg.fill('#kPhone','0901234567');pg.select_option('#kProv',index=1);pg.wait_for_timeout(100);pg.select_option('#kWard',index=2);pg.fill('#kAddr','12 Duong A');pg.check('#kAgree')
    pg.evaluate("document.getElementById('ckForm').requestSubmit()");pg.wait_for_timeout(700)
    call=[c for c in pg.evaluate('__mock.calls') if c[0]=='place_order']
    R['place_order_calls']=len(call)
    a=call[0][1] if call else {}
    R['payload_keys']=sorted(a.keys())
    R['payload_has_no_price']=not any('price' in k or 'total' in k for k in a.keys()) and not any('price' in k for it in a.get('p_items',[]) for k in it)
    R['item_fields']=sorted(a['p_items'][0].keys()) if call else None
    R['coupon_sent']=a.get('p_coupon');R['idem_present']=bool(a.get('p_idem'));R['pay_method']=a.get('p_pay_method')
    R['success_modal']=pg.inner_text('#modalBody')[:80]
    R['cart_emptied']=pg.evaluate('db.cart.length')
    R['events']=sorted(set(pg.evaluate('__mock.events')))
    pg.evaluate("vAccount()");pg.wait_for_timeout(500);R['account_has_order']='VSABC12345' in pg.inner_text('#modalBody');R['account_points']='120 điểm' in pg.inner_text('#modalBody')
    pg.evaluate("closeModal();trackOrder()");pg.fill('#trackCode','vsabc12345');pg.fill('#trackPhone','0901234567');pg.evaluate("trackOrderResult()");pg.wait_for_timeout(300)
    R['track_ok']='Đơn VSABC12345' in pg.inner_text('#trackResult')
    pg.evaluate("closeModal();goAdmin()");pg.wait_for_timeout(500)
    R['customer_denied_admin']=not pg.evaluate("document.getElementById('admin').classList.contains('active')")
    # ---- guest: checkout asks login
    pg2=new(b,"");pg2.add_init_script("window.__mock.signedIn=false");pg2.goto(URL);pg2.wait_for_timeout(700)
    pg2.evaluate("openProduct('p1')");pg2.wait_for_timeout(300);pg2.get_by_role('button',name='M',exact=True).first.click();pg2.get_by_role('button',name='Thêm vào giỏ').first.click();pg2.wait_for_timeout(200)
    pg2.evaluate("checkout()");pg2.wait_for_timeout(300);R['guest_checkout_shows_login']=pg2.inner_text('#modalTitle')
    # ---- staff admin
    pg3=new(b);pg3.add_init_script("window.__mock.role='admin'");pg3.goto(URL);pg3.wait_for_timeout(700)
    pg3.evaluate("goAdmin()");pg3.wait_for_timeout(800)
    R['admin_active']=pg3.evaluate("document.getElementById('admin').classList.contains('active')")
    R['admin_tabs']=pg3.locator('#admin .side').count();R['dash_text']=pg3.inner_text('#adminPanel')[:50]
    pg3.evaluate("vAdminTab('orders')");pg3.wait_for_timeout(500);R['orders_listed']='VSABC12345' in pg3.inner_text('#adminPanel')
    pg3.evaluate("vSetStatus('o-1','confirmed')");pg3.wait_for_timeout(500)
    R['status_rpc_called']=any(c[0]=='admin_set_order_status' and c[1]['p_status']=='confirmed' for c in pg3.evaluate('__mock.calls'))
    pg3.screenshot(path='/home/claude/audit/online_admin.png')
    R['errors']=errs
    print(json.dumps(R,ensure_ascii=False,indent=1));b.close()
