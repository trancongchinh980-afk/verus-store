(function(){
const U='11111111-1111-1111-1111-111111111111';
const state=window.__mock={calls:[],events:[],inserts:[],role:'customer',signedIn:true,orders:[{id:'o-1',code:'VSABC12345',customer_name:'Khach A',phone:'0901234567',total:260100,deposit_amount:53000,balance_amount:207100,deposit_status:'unpaid',status:'pending',created_at:new Date().toISOString(),user_id:U,pay_method:'cod_balance',subtotal:289000,discount:28900,points_discount:0,points_used:0,deposit_percent:20,province:'An Giang',ward:'P',street:'S',order_items:[{product_name:'Quần short camo',variant_name:'Camo xanh',size:'M',qty:1,line_total:289000,sku:'X'}],order_events:[{id:1,status:'pending',created_at:new Date().toISOString()}]}]};
const VID='aaaaaaaa-0000-0000-0000-000000000001';
const T={
 products:()=>[{id:'p1',name:'Quần short camo',category:'Quần',sku:'VS-SHORT-001',price:289000,compare_price:359000,status:'active',badge:'NEW DROP',delivery_note:'Đặt trước khoảng 15 ngày (dự kiến)',material:'Polyester',fit:'Form rộng',care:'',description_html:'<p>mô tả</p>',style_tags:['streetwear'],occasion:null,styling_tips:null,size_chart:null,size_rules:null,featured:true,created_at:'2026-01-01',product_variants:[{id:VID,name:'Camo xanh',sku:'VS-SHORT-001-GRN',image_urls:[],video_urls:[],sort:1,variant_sizes:[{id:'s1',size:'M',stock:4},{id:'s2',size:'L',stock:3}]}]}],
 product_rating_stats:()=>[],site_settings:()=>[{key:'deposit_percent',value:20},{key:'lead_days',value:15},{key:'redeem_vnd_per_point',value:500},{key:'max_redeem_percent',value:30}],
 outfits:()=>[],public_reviews:()=>[{id:'r1',product_id:'p1',rating:5,title:'Ok',body:'Mặc thoải mái',reviewer:'An',created_at:new Date().toISOString()}],
 profiles:()=>[{id:U,full_name:'Nguyen An',role:state.role,points_balance:120,marketing_opt_in:false}],
 orders:()=>state.orders,payments:()=>[],wishlist:()=>[],chat_threads:()=>[],cart_snapshots:()=>[]};
function chain(table){const st={table,filters:[],op:'select',single:false,payload:null};
 const api={select(){return api},eq(c,v){st.filters.push([c,v]);return api},neq(){return api},in(){return api},order(){return api},limit(){return api},single(){st.single=true;return api},
  insert(p){st.op='insert';st.payload=p;return api},update(p){st.op='update';st.payload=p;return api},upsert(p){st.op='upsert';st.payload=p;return api},delete(){st.op='delete';return api},
  then(res,rej){let r;
   if(table==='events'&&st.op==='insert'){state.events.push(st.payload.name);r={data:null,error:null}}
   else if(st.op!=='select'){state.inserts.push([table,st.op,st.payload]);r={data:st.single?{id:'new-id',...(st.payload||{})}:[],error:null}}
   else{let d=(T[table]?T[table]():[]);st.filters.forEach(([c,v])=>{d=d.filter(x=>x[c]===v||x[c]===undefined)});r={data:st.single?d[0]:d,error:null}}
   return Promise.resolve(r).then(res,rej)}};return api}
const RPC={
 my_vip:()=>({points:120,active_tier:'member',highest_tier:null,spend_12m:0,referral_code:'VS1234567',next_tier:'Silver',next_threshold:2000000,tiers:[{code:'member',name:'Member'}]}),
 preview_coupon:a=>a.p_code==='VERUS10'?{valid:true,code:'VERUS10',discount:Math.min(Math.floor(a.p_subtotal*.1),50000)}:{valid:false,reason:'COUPON_INVALID'},
 place_order:a=>({code:'VSTEST00001',subtotal:289000,discount:28900,points_discount:0,total:260100,deposit:53000,balance:207100,deposit_percent:20,status:'pending'}),
 track_order:a=>a.p_code==='VSABC12345'&&a.p_phone==='0901234567'?{code:'VSABC12345',status:'confirmed',deposit_status:'unpaid',total:260100,items:[{name:'Quần',variant:'x',size:'M',qty:1}],events:[{status:'pending',at:new Date().toISOString()}]}:null,
 admin_set_order_status:()=>({ok:true}),admin_dashboard:()=>({orders_by_status:{pending:1},gross_orders_value:260100,confirmed_deposits:0,funnel:{view_product:10,add_to_cart:4,begin_checkout:2,purchase:1},top_products:[],customers:1,repeat_customers:0})};
window.supabase={createClient:()=>({
 from:chain,
 rpc:(n,a)=>{state.calls.push([n,a]);if(n==='admin_set_order_status'&&state.role==='customer')return Promise.resolve({data:null,error:{message:'FORBIDDEN'}});return Promise.resolve({data:(RPC[n]||(()=>null))(a||{}),error:null})},
 auth:{getSession:()=>Promise.resolve({data:{session:state.signedIn?{user:{id:U,email:'an@test.local'}}:null}}),onAuthStateChange:()=>({}),signInWithPassword:()=>Promise.resolve({error:null}),signUp:()=>Promise.resolve({data:{},error:null}),signOut:()=>Promise.resolve({})}})};
Object.defineProperty(window,'VERUS_CONFIG',{get:()=>({SUPABASE_URL:'https://mock.supabase.co',SUPABASE_ANON_KEY:'anon-mock'}),set(){}});
})();
