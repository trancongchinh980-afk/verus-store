/* VERUS STORE V6 — lớp kết nối Supabase. Chế độ DEMO nếu chưa cấu hình. */
(function(){
const cfg=window.VERUS_CONFIG||{};
const V=window.V={cfg,online:false,sb:null,session:null,profile:null,isStaff:false,isAdmin:false,vip:null,outfits:[],reviews:[],settings:{},coupon:null,cur:null,of:null,lastQty:0,placing:false};
V.sid=(sessionStorage.getItem('vs_sid')||(()=>{const s=(crypto.randomUUID?crypto.randomUUID():String(Math.random()).slice(2));sessionStorage.setItem('vs_sid',s);return s})());
const ST={pending:'Chờ xác nhận',confirmed:'Đã xác nhận',sourcing:'Đang kiểm tra nguồn hàng',supplier_ordered:'Đã đặt nhà cung cấp',in_transit_vn:'Đang vận chuyển về Việt Nam',inspecting:'Đang kiểm tra hàng',shipping:'Đang giao cho khách',delivered:'Đã giao thành công',return_requested:'Yêu cầu đổi trả',cancelled:'Đã hủy',refunded:'Hoàn tiền'};
const DEP={unpaid:'Chưa cọc',pending_review:'Chờ shop đối soát cọc',confirmed:'Shop đã xác nhận cọc',refunded:'Đã hoàn cọc'};
const CST={pending:'Chờ shop xác nhận',confirmed:'Shop đã xác nhận đơn',sourcing:'Shop đang chuẩn bị đơn',supplier_ordered:'Đơn đang được xử lý',in_transit_vn:'Đơn đang trên đường về',inspecting:'Đang kiểm tra đơn',shipping:'Đang giao cho bạn',delivered:'Đã giao thành công',return_requested:'Đang xử lý yêu cầu đổi trả',cancelled:'Đã hủy',refunded:'Đã hoàn tiền'};
const FLOW=['pending','confirmed','sourcing','supplier_ordered','in_transit_vn','inspecting','shipping','delivered'];
const ERR={AUTH_REQUIRED:'Bạn cần đăng nhập.',INVALID_PHONE:'Số điện thoại cần 10 chữ số, bắt đầu bằng 0.',INVALID_ADDRESS:'Vui lòng nhập đủ họ tên và địa chỉ.',INVALID_QTY:'Số lượng không hợp lệ.',ITEM_NOT_FOUND:'Một sản phẩm không còn tồn tại.',PRODUCT_UNAVAILABLE:'Một sản phẩm đã ngừng bán.',COUPON_INVALID:'Mã không tồn tại hoặc đã tắt.',COUPON_EXPIRED:'Mã đã hết hạn hoặc chưa bắt đầu.',COUPON_EXHAUSTED:'Mã đã hết lượt.',COUPON_ALREADY_USED:'Bạn đã dùng mã này rồi.',COUPON_TIER:'Mã dành cho hạng thành viên cao hơn.',NOT_ENOUGH_POINTS:'Bạn không đủ điểm.',TOO_MANY_PENDING_ORDERS:'Bạn đang có quá nhiều đơn chờ xác nhận.',FORBIDDEN:'Bạn không có quyền thực hiện thao tác này.',DEPOSIT_NOT_CONFIRMED:'Chưa xác nhận cọc nên chưa thể đặt nhà cung cấp.',INSUFFICIENT_AVAILABLE_BALANCE:'Vượt số dư khả dụng.',REFUND_EXCEEDS_RECEIVED:'Số hoàn vượt số tiền đã nhận.',ORDER_NOT_DELIVERED:'Chỉ đánh giá được sau khi nhận hàng.',NOT_YOUR_ITEM:'Sản phẩm này không thuộc đơn của bạn.',INVALID_STATE:'Trạng thái hiện tại không cho phép thao tác này.'};
const fd=d=>d?new Date(d).toLocaleString('vi-VN'):'—';
const ph=(t)=>'data:image/svg+xml;utf8,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="600" height="750"><rect width="100%" height="100%" fill="#ece8e3"/><text x="50%" y="48%" font-family="sans-serif" font-size="64" fill="#b8472b" text-anchor="middle">${esc((t||'V').trim().charAt(0).toUpperCase())}</text><text x="50%" y="58%" font-family="sans-serif" font-size="20" fill="#777" text-anchor="middle">ẢNH MINH HỌA</text></svg>`);
const errMsg=e=>{const m=String(e?.message||e||'');const c=m.split(':')[0].trim();if(c==='OUT_OF_STOCK')return 'Hết hàng hoặc không đủ tồn kho: '+m.split(':').slice(1).join(':');if(c==='COUPON_MIN_SUBTOTAL')return 'Đơn chưa đạt mức tối thiểu của mã.';if(c==='POINTS_OVER_LIMIT')return 'Chỉ được dùng tối đa '+m.split(':')[1]+' điểm cho đơn này.';if(c==='INVALID_TRANSITION')return 'Không thể chuyển trạng thái: '+m.split(':')[1];return ERR[c]||('Lỗi: '+m)};
const run=async(fn)=>{try{return await fn()}catch(e){console.error(e);toast(errMsg(e));return undefined}};
const rpc=async(n,a)=>{const {data,error}=await V.sb.rpc(n,a||{});if(error)throw error;return data};
const q=async(p)=>{const {data,error}=await p;if(error)throw error;return data};
window.vh={ST,DEP,FLOW,fd,errMsg,run,rpc,q,ph};

/* ---------- Tiện ích hiển thị / ảnh dự phòng ---------- */
const _pi=window.productImg;window.productImg=(p,v)=>_pi(p,v)||ph(p?.name);
function track(name,props){ if(!V.online)return; V.sb.from('events').insert({user_id:V.session?.user?.id||null,session_id:V.sid,name,props:props||{}}).then(()=>{},()=>{}) }
V.track=track;
function banner(){const a=document.getElementById('announcement');if(!a)return;const b=document.createElement('div');b.id='modeBadge';b.style.cssText='margin-top:4px;font-weight:800;letter-spacing:.06em;color:'+(V.online?'#9be7b4':'#ffd27a');b.textContent=V.online?'● ONLINE — dữ liệu lưu trên máy chủ Supabase':'● DEMO — dữ liệu chỉ nằm trong trình duyệt này, không có đăng nhập, không nhận tiền thật';a.appendChild(b)}

/* ---------- Dữ liệu mẫu cho DEMO (đánh dấu rõ là minh họa) ---------- */
const DEMO_EXTRA=[
 {id:'d2',name:'Áo thun oversize (mẫu minh họa)',category:'Áo',sku:'DEMO-TEE-001',price:219000,compare:0,status:'active',badge:'DEMO',material:'Dữ liệu minh họa',fit:'Oversize',care:'',delivery:'Đặt trước khoảng 15 ngày (dự kiến)',description:'<p>Sản phẩm minh họa để thử Outfit Builder. Thay bằng dữ liệu thật.</p>',styleTags:['streetwear','casual'],variants:[{name:'Trắng',sku:'DEMO-TEE-001-W',images:[],videos:[],stock:9,sizes:[{name:'M',stock:3},{name:'L',stock:3},{name:'XL',stock:3}]}]},
 {id:'d3',name:'Sneaker trắng (mẫu minh họa)',category:'Giày',sku:'DEMO-SNK-001',price:549000,compare:0,status:'active',badge:'DEMO',material:'Dữ liệu minh họa',fit:'',care:'',delivery:'Đặt trước khoảng 15 ngày (dự kiến)',description:'<p>Sản phẩm minh họa.</p>',styleTags:['streetwear'],variants:[{name:'Trắng',sku:'DEMO-SNK-001-W',images:[],videos:[],stock:6,sizes:[{name:'40',stock:2},{name:'41',stock:2},{name:'42',stock:2}]}]},
 {id:'d4',name:'Mũ lưỡi trai (mẫu minh họa)',category:'Mũ',sku:'DEMO-CAP-001',price:149000,compare:0,status:'active',badge:'DEMO',material:'Dữ liệu minh họa',fit:'',care:'',delivery:'Đặt trước khoảng 15 ngày (dự kiến)',description:'<p>Sản phẩm minh họa.</p>',styleTags:['casual'],variants:[{name:'Đen',sku:'DEMO-CAP-001-B',images:[],videos:[],stock:8,sizes:[{name:'Free',stock:8}]}]}];
const SIZE_RULES=[{h_min:155,h_max:165,w_min:45,w_max:55,size:'S'},{h_min:160,h_max:170,w_min:55,w_max:65,size:'M'},{h_min:165,h_max:175,w_min:65,w_max:75,size:'L'},{h_min:170,h_max:185,w_min:75,w_max:90,size:'XL'}];
function demoInit(){
  DEMO_EXTRA.forEach(d=>{if(!db.products.find(p=>p.id===d.id))db.products.push(structuredClone(d))});
  const p1=db.products.find(p=>p.id==='p1');if(p1&&!p1.size_rules)p1.size_rules=SIZE_RULES;
  V.outfits=[{id:'o1',title:'Street Weekend (minh họa)',description:'Bộ phối mẫu: quần camo + áo thun + sneaker. Dữ liệu minh họa.',style_tag:'streetwear',items:['p1','d2','d3']}];
}

/* ---------- Ánh xạ dữ liệu server → mô hình V5 ---------- */
const SZ=['XS','S','M','L','XL','XXL','XXXL'];const szCmp=(a,b)=>{const x=SZ.indexOf(a.name),y=SZ.indexOf(b.name);return x>=0&&y>=0?x-y:String(a.name).localeCompare(String(b.name),'vi',{numeric:true})};
function mapProduct(r){return{id:r.id,name:r.name,category:r.category,sku:r.sku,price:r.price,compare:r.compare_price||0,status:r.status,badge:r.badge,delivery:r.delivery_note,material:r.material,fit:r.fit,care:r.care,description:r.description_html,styleTags:r.style_tags||[],occasion:r.occasion,stylingTips:r.styling_tips,sizeChart:r.size_chart,size_rules:r.size_rules,rating:0,reviewCount:0,featured:r.featured,
 variants:(r.product_variants||[]).slice().sort((a,b)=>a.sort-b.sort).map(v=>{const sizes=(v.variant_sizes||[]).map(s=>({id:s.id,name:s.size,stock:s.stock})).sort(szCmp);return{id:v.id,name:v.name,sku:v.sku,images:v.image_urls||[],videos:v.video_urls||[],sizes,stock:sizes.reduce((n,s)=>n+s.stock,0)}})}}
async function loadCatalog(){
  const rows=await q(V.sb.from('products').select('*, product_variants(*, variant_sizes(*))').eq('status','active').order('created_at',{ascending:false}));
  db.products=rows.map(mapProduct);
  const st=await q(V.sb.from('product_rating_stats').select('*')).catch(()=>[]);
  st.forEach(s=>{const p=db.products.find(x=>x.id===s.product_id);if(p){p.rating=+s.rating_avg;p.reviewCount=s.review_count}});
  const ss=await q(V.sb.from('site_settings').select('key,value')).catch(()=>[]);const m=Object.fromEntries(ss.map(x=>[x.key,x.value]));
  if(m.deposit_percent!=null)db.settings.deposit=+m.deposit_percent;if(m.lead_days!=null)db.settings.days=+m.lead_days;if(m.policy_text)db.settings.policy=m.policy_text;V.settings=m;
  const of=await q(V.sb.from('outfits').select('*, outfit_items(product_id,role,sort)').eq('active',true)).catch(()=>[]);
  V.outfits=of.map(o=>({id:o.id,title:o.title,description:o.description,style_tag:o.style_tag,items:(o.outfit_items||[]).sort((a,b)=>a.sort-b.sort).map(i=>i.product_id)}));
  const rv=await q(V.sb.from('public_reviews').select('*').order('created_at',{ascending:false}).limit(6)).catch(()=>[]);V.reviews=rv;
}
async function loadProfile(){
  if(!V.session){V.profile=null;V.isStaff=V.isAdmin=false;V.vip=null;return}
  V.profile=await q(V.sb.from('profiles').select('*').eq('id',V.session.user.id).single()).catch(()=>null);
  V.isStaff=['staff','admin'].includes(V.profile?.role);V.isAdmin=V.profile?.role==='admin';
  V.vip=await rpc('my_vip').catch(()=>null);
}
function navLabel(){const b=document.getElementById('accBtn');if(b)b.textContent=V.session?(V.profile?.full_name?.split(' ').slice(-1)[0]||'Tài khoản'):'Đăng nhập'}

/* ---------- Giỏ hàng / voucher / checkout ---------- */
const cartItemsForServer=()=>db.cart.map(x=>{const p=db.products.find(p=>p.id===x.pid);return p&&p.variants[x.vi]?{variant_id:p.variants[x.vi].id,size:x.size,qty:x.qty}:null}).filter(Boolean);
let cartT;function syncCart(){if(!V.online||!V.session)return;clearTimeout(cartT);cartT=setTimeout(()=>{V.sb.from('cart_snapshots').upsert({user_id:V.session.user.id,items:cartItemsForServer(),updated_at:new Date().toISOString()}).then(()=>{},()=>{})},1500)}
const _cc=window.cartCalc;window.cartCalc=function(code){const r=_cc('');if(V.online&&V.coupon?.valid&&V.coupon.code===code){r.d=Math.min(V.coupon.discount,r.sub);r.c={code};r.total=Math.max(0,r.sub-r.d)}return r};
const _ac=window.applyCoupon;window.applyCoupon=async function(){if(!V.online)return _ac();
  const code=document.getElementById('cartCoupon').value.trim().toUpperCase(),sub=window.__cartSubtotal||0;
  const r=await run(()=>rpc('preview_coupon',{p_code:code,p_subtotal:sub}));if(!r)return;V.coupon=r.valid?r:null;
  document.getElementById('couponFeedback').textContent=r.valid?'Đã áp dụng mã '+r.code+' (máy chủ sẽ kiểm tra lại khi đặt hàng).':(ERR[r.reason]||'Mã không hợp lệ')+(r.min?' Tối thiểu '+money(r.min)+'.':'');
  window.__appliedCoupon=r.valid?r.code:'';const d=r.valid?r.discount:0;document.getElementById('cartDiscount').textContent=money(d);document.getElementById('cartTotal').textContent=money(Math.max(0,sub-d))};
const _sc=window.showCart;window.showCart=function(){_sc();if(!V.online)return;const b=document.getElementById('modalBody');b.innerHTML=b.innerHTML.replace('Tổng demo','Tổng tạm tính').replace('Tiếp tục đặt hàng (demo)','Tiếp tục đặt hàng');b.querySelectorAll('.notice').forEach(n=>{if(n.textContent.includes('giỏ hàng thử nghiệm'))n.textContent='Giá, tồn kho và mã giảm giá sẽ được máy chủ tính lại khi bạn đặt hàng. Chưa thu tiền ở bước này.'})};
const _co=window.checkout;window.checkout=async function(){
  if(!V.online)return _co();
  if(!V.session){toast('Đăng nhập (hoặc đăng ký nhanh) để đặt hàng nhé.');vAuth('checkout');return}
  if(!db.cart.length){toast('Giỏ hàng trống.');return}
  track('begin_checkout',{items:db.cart.length});_co();if(!document.getElementById('ckForm'))return;
  if(!V.vip)await loadProfile();
  const mb=document.getElementById('modalBody');document.getElementById('modalTitle').textContent='Đặt hàng';
  const ckForm=document.getElementById('ckForm');
  if(ckForm&&!document.getElementById('savedAddressPicker')){
    ckForm.insertAdjacentHTML('afterbegin',`<div class="field" id="savedAddressWrap"><label for="savedAddressPicker">Địa chỉ đã lưu</label><select id="savedAddressPicker"><option value="">Nhập địa chỉ mới</option></select><p class="formhint">Lưu địa chỉ để lần mua sau chọn nhanh, không cần nhập lại.</p></div>`);
    ckForm.insertAdjacentHTML('beforeend',`<label class="auth-consent" style="margin:12px 0"><input type="checkbox" id="saveAddressAfterOrder" checked> Lưu địa chỉ này vào tài khoản để dùng cho những lần mua sau.</label>`);
    try{const {data:addresses,error}=await V.sb.from('addresses').select('*').eq('user_id',V.session.user.id).order('is_default',{ascending:false}).order('created_at',{ascending:false});if(error)throw error;
      const sel=document.getElementById('savedAddressPicker');(addresses||[]).forEach(a=>{const o=document.createElement('option');o.value=a.id;o.textContent=`${a.recipient} · ${a.phone} · ${a.street}, ${a.ward}, ${a.province}${a.is_default?' (Mặc định)':''}`;sel.appendChild(o)});
      sel.addEventListener('change',()=>{const a=(addresses||[]).find(x=>x.id===sel.value);if(!a)return;document.getElementById('kName').value=a.recipient||'';document.getElementById('kPhone').value=a.phone||'';document.getElementById('kProv').value=a.province||'';if(typeof addressProvinceChanged==='function')addressProvinceChanged();document.getElementById('kWard').value=a.ward||'';document.getElementById('kAddr').value=a.street||'';});
    }catch(e){console.warn('Không tải được địa chỉ đã lưu',e);}
  }

  mb.querySelectorAll('.notice').forEach(n=>{const t=n.textContent;if(t.includes('ĐƠN DEMO'))n.textContent='Đơn sẽ được gửi tới shop. Shop kiểm tra và liên hệ xác nhận TRƯỚC khi bạn chuyển cọc.';else if(t.includes('Tiền cọc'))n.textContent=`Cọc ${db.settings.deposit}% chuyển sau khi shop xác nhận đơn, rồi bạn báo lại trong mục Tài khoản. Shop chỉ ghi nhận khi đối soát được giao dịch thật. Chưa có cổng thanh toán tự động.`});
  const pts=V.vip?.points||0,rate=+(V.settings?.redeem_vnd_per_point||500);
  const kp=document.getElementById('kPay')?.closest('.field');
  if(kp&&pts>0)kp.insertAdjacentHTML('beforebegin',`<div class="field"><label>Dùng điểm thưởng (bạn có ${pts} điểm, 1 điểm = ${money(rate)}, tối đa ${V.settings?.max_redeem_percent||30}% giá trị đơn)</label><input id="kPoints" type="number" min="0" max="${pts}" value="0" inputmode="numeric"></div>`);
  const idem=(crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random());
  document.getElementById('ckForm').onsubmit=async e=>{e.preventDefault();if(V.placing)return;
    const ph=kPhone.value.replace(/[\s.]/g,'');if(!/^0\d{9}$/.test(ph)){toast(ERR.INVALID_PHONE);return}
    const prov=kProv.value,ward=kWard.value;if(!prov||!ward){toast('Bạn chọn tỉnh/thành phố và phường/xã nhé.');return}
    V.placing=true;const btn=document.getElementById('kBtn');if(btn)btn.disabled=true;
    try{const r=await rpc('place_order',{p_items:cartItemsForServer(),p_name:kName.value.trim(),p_phone:ph,p_province:prov,p_ward:ward,p_street:kAddr.value.trim(),p_note:kNote.value.trim(),p_pay_method:kPay.value==='COD'?'cod_balance':'bank_transfer_balance',p_coupon:window.__appliedCoupon||null,p_points:+(document.getElementById('kPoints')?.value||0),p_idem:idem});
      if(document.getElementById('saveAddressAfterOrder')?.checked){try{await V.sb.from('addresses').update({is_default:false}).eq('user_id',V.session.user.id);const {data:existing}=await V.sb.from('addresses').select('id').eq('user_id',V.session.user.id).eq('phone',ph).eq('province',prov).eq('ward',ward).eq('street',kAddr.value.trim()).limit(1);if(existing?.length)await V.sb.from('addresses').update({recipient:kName.value.trim(),is_default:true}).eq('id',existing[0].id);else await V.sb.from('addresses').insert({user_id:V.session.user.id,recipient:kName.value.trim(),phone:ph,province:prov,ward,street:kAddr.value.trim(),is_default:true});}catch(addrErr){console.warn('Đơn đã lưu nhưng không lưu được địa chỉ',addrErr);toast('Đơn đã tạo, nhưng địa chỉ chưa lưu được.')}}
      db.cart=[];save();window.__appliedCoupon='';V.coupon=null;await loadCatalog();renderProducts();loadProfile().then(navLabel);
      modal('Đã gửi đơn hàng',`<div class="notice">Đơn đã được lưu trên máy chủ và shop có thể thấy ngay. <b>Chưa thu tiền.</b></div><h3>Mã đơn: ${esc(r.code)}</h3><div class="totalrow"><span>Tổng</span><b>${money(r.total)}</b></div><div class="totalrow"><span>Cọc ${r.deposit_percent}% qua QR (chuyển sau khi shop xác nhận)</span><b>${money(r.deposit)}</b></div><div class="totalrow"><span>Còn lại khi nhận hàng</span><b>${money(r.balance)}</b></div><p class="tiny muted">Dự kiến giao hàng khoảng ${db.settings.days} ngày (ước tính, không phải cam kết tuyệt đối). Lưu mã đơn để tra cứu cùng số điện thoại.</p><button class="orange" style="width:100%" onclick="vAccount()">Xem đơn của tôi</button>`)
    }catch(err){toast(errMsg(err));if(/OUT_OF_STOCK|ITEM_NOT|UNAVAILABLE/.test(String(err.message))){await loadCatalog();renderProducts()}}
    finally{V.placing=false;if(btn)btn.disabled=false}}
};

/* ---------- Tra cứu đơn ---------- */
function timeline(ev){return `<div class="timeline">${ev.map(h=>`<div class="timelineitem"><i></i><div><b>${esc(CST[h.status]||h.status)}</b>${h.note?`<div class="tiny">${esc(h.note)}</div>`:''}<div class="tiny muted">${fd(h.at)}</div></div></div>`).join('')}</div>`}
const _tr=window.trackOrderResult;window.trackOrderResult=async function(){if(!V.online)return _tr();
  const code=(document.getElementById('trackCode')?.value||'').trim().toUpperCase(),phone=(document.getElementById('trackPhone')?.value||'').replace(/\D/g,''),box=document.getElementById('trackResult');
  if(!code||!phone){box.innerHTML='<div class="notice">Bạn nhập cả mã đơn và số điện thoại nhé.</div>';return}
  const o=await run(()=>rpc('track_order',{p_code:code,p_phone:phone}));if(o===undefined)return;
  if(!o){box.innerHTML='<div class="notice">Không tìm thấy đơn khớp mã và số điện thoại.</div>';return}
  box.innerHTML=`<div class="trackbox"><div class="row" style="justify-content:space-between;align-items:center"><b>Đơn ${esc(o.code)}</b><span class="pill">${esc(CST[o.status]||o.status)}</span></div><p class="tiny muted">${esc(DEP[o.deposit_status]||'')} · Tạo lúc ${fd(o.created_at)}${o.eta_date?' · Dự kiến khoảng '+new Date(o.eta_date).toLocaleDateString('vi-VN')+' (ước tính)':''}</p>${o.carrier?`<p class="tiny">Vận chuyển: ${esc(o.carrier)} ${esc(o.tracking_code||'')}</p>`:''}${o.items.map(i=>`<div class="tiny">${esc(i.name)} · ${esc(i.variant)} · ${esc(i.size)} × ${i.qty}</div>`).join('')}<div class="totalrow"><span>Tổng</span><b>${money(o.total)}</b></div>${timeline(o.events)}</div>`};

/* ---------- Đăng nhập / đăng ký ---------- */
window.vAuth=function(next,view='login'){
  if(!V.online){modal('Tài khoản',`<div class="auth-shell"><div class="auth-brand"><span class="auth-mark">V.</span><div><b>VERUS STORE</b><small>YOUR STYLE. YOUR RULES.</small></div></div><div class="notice"><b>Chế độ DEMO</b><br>Đăng nhập và đăng ký chỉ hoạt động sau khi kết nối Supabase. Cần chạy SQL khởi tạo cơ sở dữ liệu trước khi dùng tài khoản thật.</div><button class="outline" style="width:100%" onclick="closeModal()">Quay lại cửa hàng</button></div>`);return}
  window.__authNext=next||window.__authNext||''; window.__authView=view==='register'?'register':'login';
  const isReg=window.__authView==='register';
  modal(isReg?'Tạo tài khoản VERUS':'Chào mừng trở lại',`<div class="auth-shell"><div class="auth-brand"><span class="auth-mark">V.</span><div><b>VERUS STORE</b><small>YOUR STYLE. YOUR RULES.</small></div></div><div class="auth-heading"><span class="customer-kicker">${isReg?'THAM GIA VERUS CLUB':'TÀI KHOẢN CỦA BẠN'}</span><h2>${isReg?'Tạo tài khoản mới':'Đăng nhập'}</h2><p>${isReg?'Lưu địa chỉ giao hàng, theo dõi đơn và tích điểm thành viên.':'Đăng nhập để xem đơn hàng, địa chỉ đã lưu và quyền lợi thành viên.'}</p></div><div class="field"><label for="aEmail">Địa chỉ email</label><input id="aEmail" type="email" autocomplete="email" placeholder="ban@email.com" required></div><div class="field"><label for="aPass">Mật khẩu</label><input id="aPass" type="password" autocomplete="${isReg?'new-password':'current-password'}" placeholder="Tối thiểu 8 ký tự" minlength="8" required></div>${isReg?`<div class="field"><label for="aName">Họ và tên</label><input id="aName" autocomplete="name" placeholder="Tên của bạn" required></div><div class="field"><label for="aRef">Mã giới thiệu <span class="muted">(không bắt buộc)</span></label><input id="aRef" style="text-transform:uppercase" placeholder="Mã giới thiệu"></div><label class="auth-consent"><input type="checkbox" id="aMkt"> Tôi đồng ý nhận tin ưu đãi từ VERUS STORE (có thể tắt bất cứ lúc nào).</label><button class="orange auth-primary" style="width:100%;margin-top:14px" onclick="vSignUp()">Tạo tài khoản</button>`:`<button class="orange auth-primary" style="width:100%" onclick="vSignIn()">Đăng nhập</button><button class="auth-forgot" onclick="vForgotPassword()">Quên mật khẩu?</button>`}<div class="auth-divider"><span>hoặc</span></div><button class="outline auth-google" style="width:100%" onclick="vGoogleAuth()"><span class="google-g">G</span> Tiếp tục với Google</button><div class="auth-switch">${isReg?'Đã có tài khoản?':'Chưa có tài khoản?'} <button type="button" onclick="vAuthPage('${isReg?'login':'register'}')">${isReg?'Đăng nhập':'Tạo tài khoản'}</button></div><p class="auth-terms">Bằng việc tiếp tục, bạn đồng ý với các điều khoản và chính sách của VERUS STORE.</p></div>`);
};
window.vAuthPage=function(view){vAuth(window.__authNext,view)};
window.vForgotPassword=()=>run(async()=>{const email=document.getElementById('aEmail')?.value.trim();if(!email){toast('Nhập email trước để nhận liên kết đặt lại mật khẩu.');return}const {error}=await V.sb.auth.resetPasswordForEmail(email,{redirectTo:window.location.href.split('#')[0]});if(error)throw error;toast('Đã gửi yêu cầu đặt lại mật khẩu. Kiểm tra hộp thư nếu email được xác nhận.')});
window.vSignIn=()=>run(async()=>{const {error}=await V.sb.auth.signInWithPassword({email:aEmail.value.trim(),password:aPass.value});if(error)throw error;closeModal();toast('Đã đăng nhập');const n=window.__authNext;if(n==='checkout')checkout();if(n==='admin')goAdmin()});
window.vGoogleAuth=()=>run(async()=>{if(!V.online||!V.sb){toast('Cần cấu hình Supabase trước khi dùng Google.');return}const {error}=await V.sb.auth.signInWithOAuth({provider:'google',options:{redirectTo:window.location.href.split('#')[0]}});if(error){console.error('Google OAuth:',error);if(/provider.*not.*enabled|unsupported provider|provider is not enabled/i.test(error.message||'')){toast('Google chưa được bật trong Supabase. Chủ shop cần cấu hình Authentication → Providers → Google.');return}throw error}});
window.vSignUp=()=>run(async()=>{if(aPass.value.length<8){toast('Mật khẩu cần tối thiểu 8 ký tự.');return}
  const {data,error}=await V.sb.auth.signUp({email:aEmail.value.trim(),password:aPass.value,options:{data:{full_name:aName.value.trim(),referral_code:aRef.value.trim()}}});if(error)throw error;
  if(aMkt.checked&&data.session){await V.sb.from('profiles').update({marketing_opt_in:true}).eq('id',data.session.user.id)}
  closeModal();toast(data.session?'Đã tạo tài khoản':'Kiểm tra email để xác nhận tài khoản rồi đăng nhập.')});
window.vSignOut=async()=>{await V.sb.auth.signOut();closeModal();toast('Đã đăng xuất');goStore()};

/* ---------- Tài khoản ---------- */
window.vAccount=async function(){
  if(!V.online){
    db.orders=db.orders||[];db.customerProfile=db.customerProfile||{};
    const cp=db.customerProfile;
    const orders=db.orders.slice().sort((a,b)=>new Date(b.created)-new Date(a.created));
    modal('Tài khoản & lịch sử mua hàng',`<div class="notice">Bạn đang xem dữ liệu DEMO được lưu trên trình duyệt/thiết bị này. Khi website kết nối máy chủ, lịch sử sẽ đồng bộ theo tài khoản trên mọi thiết bị.</div>
    <div class="trackbox"><h3 style="margin:0 0 10px">THÔNG TIN KHÁCH HÀNG</h3><div class="field"><label>Họ và tên</label><input id="demoCustName" value="${esc(cp.name||'')}" placeholder="Tên người nhận"></div><div class="field"><label>Số điện thoại</label><input id="demoCustPhone" inputmode="tel" value="${esc(cp.phone||'')}" placeholder="0xxxxxxxxx"></div><button class="outline" onclick="saveDemoProfile()">Lưu thông tin</button></div>
    <div class="row" style="gap:8px;flex-wrap:wrap;margin:14px 0"><button class="outline" onclick="vWish()">♡ SẢN PHẨM YÊU THÍCH</button><button class="outline" onclick="showCart()">GIỎ HÀNG</button></div>
    <h3>LỊCH SỬ MUA HÀNG (${orders.length})</h3>${orders.map(o=>`<div class="supportitem"><div class="row" style="justify-content:space-between;gap:8px"><b>${esc(o.id)}</b><span class="pill">${esc(o.status)}</span></div><div class="tiny muted">${fd(o.created)} · ${money(o.total)}</div><div class="tiny">${o.items.map(i=>`${esc(i.name)} × ${i.qty}`).join(' · ')}</div><div class="row" style="gap:7px;margin-top:9px;flex-wrap:wrap"><button class="outline" onclick="vDemoOrder('${o.id}')">THEO DÕI ĐƠN</button><button class="outline" onclick="copyCode('${o.id}')">Sao chép mã</button></div></div>`).join('')||'<p class="muted">Bạn chưa có đơn hàng nào. Đơn vừa đặt sẽ tự xuất hiện tại đây.</p>'}`);
    return;
  }
  if(!V.session)return vAuth();
  await loadProfile();const pr=V.profile||{},v=V.vip||{};
  const orders=await run(()=>q(V.sb.from('orders').select('*, order_items(*)').eq('user_id',V.session.user.id).order('created_at',{ascending:false})))||[];
  const tn=(v.tiers||[]).find(t=>t.code===v.active_tier)?.name||'Member';
  modal('Tài khoản của tôi',`<div class="trackbox"><b>${esc(pr.full_name||V.session.user.email)}</b><div class="tiny muted">${esc(V.session.user.email)}</div>
  <div class="row" style="margin-top:8px;gap:8px;flex-wrap:wrap"><span class="pill">Hạng: ${esc(tn)}</span><span class="pill">${v.points||0} điểm</span>${v.highest_tier?`<span class="pill">Cột mốc cao nhất: ${esc((v.tiers||[]).find(t=>t.code===v.highest_tier)?.name||v.highest_tier)}</span>`:''}</div>
  <p class="tiny">Chi tiêu đủ điều kiện 12 tháng: <b>${money(v.spend_12m||0)}</b>${v.next_tier?` · Còn ${money(v.next_threshold-v.spend_12m)} để lên ${esc(v.next_tier)}`:''}</p>
  <p class="tiny">Mã giới thiệu: <b>${esc(v.referral_code||'')}</b> — bạn và người được giới thiệu nhận điểm sau khi đơn đầu của họ được giao và thanh toán đủ.</p></div>
  <div class="row" style="margin:10px 0;gap:8px;flex-wrap:wrap"><button class="outline" onclick="vProfile()">Sửa hồ sơ</button><button class="outline" onclick="vWish()">Yêu thích</button><button class="outline" onclick="vChat()">Nhắn shop</button><button class="outline" onclick="vSignOut()">Đăng xuất</button></div>
  <h3>Đơn hàng</h3>${orders.map(o=>`<div class="supportitem"><div class="row" style="justify-content:space-between"><b>${esc(o.code)}</b><span class="pill">${esc(CST[o.status]||o.status)}</span></div><div class="tiny muted">${esc(DEP[o.deposit_status])} · ${money(o.total)} · ${fd(o.created_at)}</div><div class="row" style="gap:6px;margin-top:6px;flex-wrap:wrap"><button class="outline" onclick="vOrder('${o.id}')">Chi tiết</button>${o.deposit_status==='unpaid'&&!['cancelled','refunded','pending'].includes(o.status)?`<button class="orange" onclick="vReportDeposit('${o.id}',${o.deposit_amount})">Tôi đã chuyển cọc</button>`:''}${o.status==='delivered'?`<button class="outline" onclick="vReviewPick('${o.id}')">Đánh giá</button>`:''}</div></div>`).join('')||'<p class="muted">Chưa có đơn hàng.</p>'}`)};
window.vProfile=()=>modal('Hồ sơ',`<div class="field"><label>Họ tên</label><input id="pName" value="${esc(V.profile?.full_name||'')}"></div><div class="field"><label>Số điện thoại</label><input id="pPhone" value="${esc(V.profile?.phone||'')}"></div><label class="tiny" style="display:flex;gap:8px"><input type="checkbox" id="pMkt" ${V.profile?.marketing_opt_in?'checked':''} style="min-height:auto"> Nhận tin ưu đãi (tối đa 1 tin/7 ngày, tắt bất cứ lúc nào)</label><button class="orange" style="width:100%;margin-top:10px" onclick="vSaveProfile()">Lưu</button>`);
window.vSaveProfile=()=>run(async()=>{await q(V.sb.from('profiles').update({full_name:pName.value.trim(),phone:pPhone.value.trim()||null,marketing_opt_in:pMkt.checked}).eq('id',V.session.user.id));await loadProfile();navLabel();toast('Đã lưu');vAccount()});
window.vReportDeposit=(id,amt)=>{const ref=prompt(`Nhập nội dung chuyển khoản bạn đã dùng (số tiền cọc: ${money(amt)}). Shop sẽ đối soát trước khi xác nhận.`);if(ref===null)return;run(async()=>{await rpc('report_deposit_transfer',{p_order:id,p_reference:ref});toast('Đã báo cho shop. Chờ đối soát.');vAccount()})};
window.vOrder=async id=>{const o=await run(()=>q(V.sb.from('orders').select('*, order_items(*), order_events(*)').eq('id',id).single()));if(!o)return;
  modal('Đơn '+o.code,`<div class="row" style="justify-content:space-between"><b>${esc(ST[o.status])}</b><span class="tiny muted">${esc(DEP[o.deposit_status])}</span></div>${o.order_items.map(i=>`<div class="tiny">${esc(i.product_name)} · ${esc(i.variant_name)} · ${esc(i.size)} × ${i.qty} — ${money(i.line_total)}</div>`).join('')}<div class="totalrow"><span>Tạm tính</span><b>${money(o.subtotal)}</b></div>${o.discount?`<div class="totalrow"><span>Giảm giá (${esc(o.coupon_code||'')})</span><b>−${money(o.discount)}</b></div>`:''}${o.points_discount?`<div class="totalrow"><span>Dùng ${o.points_used} điểm</span><b>−${money(o.points_discount)}</b></div>`:''}<div class="totalrow"><b>Tổng</b><b>${money(o.total)}</b></div><div class="totalrow"><span>Cọc ${o.deposit_percent}% qua QR</span><b>${money(o.deposit_amount)}</b></div><div class="totalrow"><span>Còn lại khi nhận hàng</span><b>${money(o.balance_amount)}</b></div>${o.eta_date?`<p class="tiny">Dự kiến khoảng ${new Date(o.eta_date).toLocaleDateString('vi-VN')} (ước tính).</p>`:''}${o.carrier?`<p class="tiny">Vận chuyển: ${esc(o.carrier)} ${esc(o.tracking_code||'')}</p>`:''}${timeline(o.order_events.map(e=>({status:e.status,note:e.note,at:e.created_at})))}<button class="outline" style="width:100%;margin-top:8px" onclick="vChat('${o.id}')">Nhắn shop về đơn này</button>`)};

/* ---------- Đánh giá từ người mua thật ---------- */
window.vReviewPick=async id=>{const o=await run(()=>q(V.sb.from('orders').select('order_items(*)').eq('id',id).single()));if(!o)return;
  modal('Chọn sản phẩm để đánh giá',o.order_items.map(i=>`<div class="supportitem"><b>${esc(i.product_name)}</b><div class="tiny muted">${esc(i.variant_name)} · ${esc(i.size)}</div><button class="outline" onclick="vReviewForm('${i.id}')">Viết đánh giá</button></div>`).join(''))};
window.vReviewForm=id=>modal('Đánh giá của bạn',`<div class="field"><label>Số sao</label><select id="rvRate"><option>5</option><option>4</option><option>3</option><option>2</option><option>1</option></select></div><div class="field"><label>Tiêu đề</label><input id="rvTitle" maxlength="120"></div><div class="field"><label>Nội dung (tối thiểu 5 ký tự)</label><textarea id="rvBody" rows="4" maxlength="2000"></textarea></div><div class="notice">Đánh giá được gắn nhãn "đã mua hàng" và hiển thị sau khi shop duyệt (shop không được sửa nội dung).</div><button class="orange" style="width:100%" onclick="vReviewSend('${id}')">Gửi đánh giá</button>`);
window.vReviewSend=id=>run(async()=>{await rpc('submit_review',{p_order_item:id,p_rating:+rvRate.value,p_title:rvTitle.value.trim(),p_body:rvBody.value.trim(),p_photos:[]});toast('Cảm ơn bạn! Đánh giá đang chờ duyệt.');closeModal()});

/* ---------- Yêu thích ---------- */
window.vWish=async()=>{
  if(!V.online){db.wishlist=db.wishlist||[];const items=db.wishlist.map(id=>db.products.find(p=>p.id===id)).filter(Boolean);modal('SẢN PHẨM YÊU THÍCH',items.map(p=>`<div class="cartitem"><img src="${esc(productImg(p,p.variants?.[0]))}"><div style="flex:1"><b>${esc(p.name)}</b><div class="tiny muted">${money(p.price)}</div><div class="row" style="gap:7px;margin-top:8px"><button class="outline" onclick="openProduct('${p.id}')">Xem sản phẩm</button><button class="outline" onclick="vWishToggle('${p.id}',true)">Bỏ yêu thích</button></div></div></div>`).join('')||'<div class="notice">Bạn chưa lưu sản phẩm nào. Hãy chạm biểu tượng ♡ trên ảnh sản phẩm để thêm vào đây.</div>');return}
  if(!V.session){vAuth();return}
  const w=await run(()=>q(V.sb.from('wishlist').select('product_id')))||[];modal('Yêu thích',w.map(x=>{const p=db.products.find(p=>p.id===x.product_id);return p?`<div class="supportitem row" style="justify-content:space-between"><b>${esc(p.name)}</b><span><button class="outline" onclick="openProduct('${p.id}')">Xem</button> <button class="outline" onclick="vWishToggle('${p.id}',true)">Bỏ</button></span></div>`:''}).join('')||'<p class="muted">Chưa có sản phẩm yêu thích.</p>')};
window.vWishToggle=(pid,fromList)=>{
  if(!V.online){db.wishlist=db.wishlist||[];const i=db.wishlist.indexOf(pid);if(i>=0){db.wishlist.splice(i,1);toast('Đã bỏ khỏi yêu thích')}else{db.wishlist.push(pid);toast('Đã thêm vào yêu thích')}save();if(fromList)vWish();return}
  if(!V.session){vAuth();return}run(async()=>{const ex=await q(V.sb.from('wishlist').select('product_id').eq('product_id',pid));if(ex.length){await q(V.sb.from('wishlist').delete().eq('product_id',pid));toast('Đã bỏ khỏi yêu thích')}else{await q(V.sb.from('wishlist').insert({user_id:V.session.user.id,product_id:pid}));track('add_to_wishlist',{pid});toast('Đã thêm vào yêu thích')}if(fromList)vWish()})};
window.saveDemoProfile=()=>{db.customerProfile=db.customerProfile||{};const name=document.getElementById('demoCustName').value.trim(),phone=document.getElementById('demoCustPhone').value.trim();if(phone&&!/^0\d{9}$/.test(phone)){toast('Số điện thoại cần 10 chữ số, bắt đầu bằng 0.');return}db.customerProfile={name,phone};save();toast('Đã lưu thông tin trên thiết bị này')};
window.vDemoOrder=id=>{const o=(db.orders||[]).find(x=>x.id===id);if(!o)return;modal('THEO DÕI ĐƠN HÀNG',`<div class="trackbox"><div class="row" style="justify-content:space-between"><b>${esc(o.id)}</b><span class="pill">${esc(o.status)}</span></div><p class="tiny muted">Đặt lúc ${fd(o.created)}</p>${o.items.map(i=>`<div class="totalrow"><span>${esc(i.name)} · ${esc(i.variant)} · ${esc(i.size||'—')} × ${i.qty}</span><b>${money(i.price*i.qty)}</b></div>`).join('')}<div class="totalrow"><span>Tổng đơn</span><b>${money(o.total)}</b></div><div class="totalrow"><span>Tiền cọc</span><b>${money(o.deposit)}</b></div><div class="totalrow"><span>Còn lại</span><b>${money(o.balance)}</b></div><h4>TIẾN TRÌNH XỬ LÝ</h4>${(o.history||[]).map(h=>`<div class="timelineitem"><b>${esc(h.s)}</b><div class="tiny muted">${fd(h.t)}</div></div>`).join('')}<p class="tiny muted">Đây là đơn DEMO lưu trên thiết bị này, chưa được gửi đến shop thật.</p></div>`)};

/* ---------- Chat / khiếu nại ---------- */
window.vChat=async(orderId)=>{if(!V.online||!V.session){vAuth();return}
  const th=await run(()=>q(V.sb.from('chat_threads').select('*').eq('user_id',V.session.user.id).order('last_message_at',{ascending:false})))||[];
  modal('Nhắn shop',`<div class="field"><label>Chủ đề</label><input id="cSub" maxlength="120" placeholder="Ví dụ: Hỏi về size / Khiếu nại đơn"></div><div class="field"><select id="cKind"><option value="support">Hỗ trợ</option><option value="complaint">Khiếu nại</option></select></div><div class="field"><textarea id="cBody" rows="3" placeholder="Nội dung"></textarea></div><button class="orange" style="width:100%" onclick="vChatNew('${orderId||''}')">Gửi</button><h3 style="margin-top:16px">Cuộc trò chuyện</h3>${th.map(t=>`<div class="supportitem row" style="justify-content:space-between"><span><b>${esc(t.subject)}</b><div class="tiny muted">${t.kind==='complaint'?'Khiếu nại':'Hỗ trợ'} · ${fd(t.last_message_at)}</div></span><button class="outline" onclick="vThread('${t.id}')">Mở</button></div>`).join('')||'<p class="muted tiny">Chưa có. Đây là chat không thời gian thực: shop trả lời khi online, hãy mở lại để xem.</p>'}`)};
window.vChatNew=oid=>run(async()=>{if(!cSub.value.trim()||!cBody.value.trim()){toast('Nhập chủ đề và nội dung.');return}
  const t=await q(V.sb.from('chat_threads').insert({user_id:V.session.user.id,order_id:oid||null,kind:cKind.value,subject:cSub.value.trim()}).select().single());
  await q(V.sb.from('chat_messages').insert({thread_id:t.id,body:cBody.value.trim()}));vThread(t.id)});
window.vThread=async(id,staff)=>{const m=await run(()=>q(V.sb.from('chat_messages').select('*').eq('thread_id',id).order('created_at')))||[];
  modal('Hội thoại',`<div style="max-height:45vh;overflow:auto">${m.map(x=>`<div class="supportitem" style="${x.sender_role==='staff'?'background:#f7eee9':''}"><b class="tiny">${x.sender_role==='staff'?'Verus':'Khách'}</b> <span class="tiny muted">${fd(x.created_at)}</span><div>${esc(x.body)}</div></div>`).join('')}</div><div class="field"><textarea id="cReply" rows="2"></textarea></div><button class="orange" style="width:100%" onclick="vReply('${id}',${!!staff})">Gửi</button>`)};
window.vReply=(id,staff)=>run(async()=>{if(!cReply.value.trim())return;await q(V.sb.from('chat_messages').insert({thread_id:id,body:cReply.value.trim()}));vThread(id,staff)});

/* ---------- Trang sản phẩm: yêu thích, tư vấn size, phối đồ, đánh giá thật ---------- */
const _op=window.openProduct;window.openProduct=function(id){V.cur=db.products.find(p=>p.id===id)||null;if(V.cur)track('view_product',{pid:id});_op(id)};
const _md=window.modal;window.modal=function(t,h){_md(t,h);if(V.cur&&t===V.cur.name)decorate()};
window.vSizeAdvice=()=>{const p=V.cur,h=+sH.value,w=+sW.value,out=document.getElementById('sOut');const r=(p.size_rules||[]).filter(x=>h>=x.h_min&&h<=x.h_max&&w>=x.w_min&&w<=x.w_max);out.textContent=r.length?'Gợi ý tham khảo: size '+r.map(x=>x.size).join(' hoặc ')+'. Luôn đối chiếu bảng số đo thực tế.':'Chưa có gợi ý khớp. Hãy xem bảng số đo hoặc nhắn shop.'};
async function decorate(){const p=V.cur,mb=document.getElementById('modalBody');if(!p||mb.querySelector('#vExtra'))return;
  let rv=[];V.rvc=V.rvc||{};if(V.online){if(!V.rvc[p.id])V.rvc[p.id]=await q(V.sb.from('public_reviews').select('*').eq('product_id',p.id).order('created_at',{ascending:false}).limit(10)).catch(()=>[]);rv=V.rvc[p.id]}
  if(mb.querySelector('#vExtra')||V.cur!==p)return;
  const outfits=V.outfits.filter(o=>o.items.includes(p.id));
  mb.insertAdjacentHTML('beforeend',`<div id="vExtra" class="detailsection">
  <div class="row" style="gap:8px;flex-wrap:wrap"><button class="outline" onclick="vWishToggle('${p.id}')">♡ Yêu thích</button></div>
  ${p.stylingTips||p.occasion?`<h4 style="margin-top:14px">Phối đồ & hoàn cảnh</h4>${p.occasion?`<div class="tiny">Phù hợp: ${esc(p.occasion)}</div>`:''}${p.stylingTips?`<div class="tiny">${esc(p.stylingTips)}</div>`:''}`:''}
  ${(p.size_rules||[]).length?`<h4 style="margin-top:14px">Gợi ý chọn size</h4><div class="row" style="gap:8px"><input id="sH" type="number" placeholder="Cao (cm)" style="flex:1"><input id="sW" type="number" placeholder="Nặng (kg)" style="flex:1"><button class="outline" onclick="vSizeAdvice()">Gợi ý</button></div><div class="tiny muted" id="sOut" style="margin-top:6px"></div>`:''}
  ${outfits.length?`<h4 style="margin-top:14px">Có trong bộ phối</h4>${outfits.map(o=>`<button class="outline" onclick="vOutfit('${o.id}')">${esc(o.title)}</button>`).join(' ')}`:''}
  ${V.online?`<h4 style="margin-top:14px">Đánh giá từ người đã mua (${rv.length})</h4>${rv.map(r=>`<div class="review-card"><b>${'★'.repeat(r.rating)}</b> ${esc(r.title||'')}<div class="tiny">${esc(r.body)}</div><div class="tiny muted">${esc(r.reviewer)} · Đã mua hàng</div></div>`).join('')||'<div class="tiny muted">Chưa có đánh giá được duyệt.</div>'}`:''}</div>`)}
const _cm=window.closeModal;window.closeModal=function(){V.cur=null;_cm()};
new MutationObserver(()=>{const mb=document.getElementById('modalBody');if(V.cur&&document.getElementById('modalbg').classList.contains('show')&&!mb.querySelector('#vExtra')&&document.getElementById('modalTitle').textContent===V.cur.name)decorate()}).observe(document.getElementById('modalBody'),{childList:true});
const _rp=window.renderProducts;let st;window.renderProducts=function(){_rp();const s=document.getElementById('search')?.value||'';clearTimeout(st);if(s.length>=2)st=setTimeout(()=>track('search',{q:s.slice(0,60)}),900)};

/* ---------- Outfit Builder ---------- */
function renderOutfits(){const el=document.getElementById('outfitSlot');if(!el)return;const os=V.outfits.filter(o=>o.items.map(i=>db.products.find(p=>p.id===i)).filter(Boolean).length>=2);
  el.innerHTML=os.length?`<section class="outfitband"><div class="eyebrow muted">OUTFIT BUILDER</div><h2>Phối sẵn, chọn size, thêm cả bộ</h2><div class="outfitgrid">${os.map(o=>{const ps=o.items.map(i=>db.products.find(p=>p.id===i)).filter(Boolean);return `<div class="outfitcard"><div class="outfitthumbs">${ps.map(p=>`<img src="${esc(productImg(p,p.variants[0]))}" alt="${esc(p.name)}">`).join('')}</div><b>${esc(o.title)}</b><div class="tiny muted">${esc(o.description||'')}</div><div class="row" style="justify-content:space-between;margin-top:8px"><b>${money(ps.reduce((n,p)=>n+price(p),0))}</b><button class="orange" onclick="vOutfit('${o.id}')">Phối bộ này</button></div></div>`}).join('')}</div></section>`:'';
  const tags=[...new Set(db.products.flatMap(p=>p.styleTags||[]))];const sl=document.getElementById('styleSlot');
  if(sl)sl.innerHTML=tags.length?`<div class="stylechips"><span class="eyebrow muted">THEO PHONG CÁCH</span>${tags.map(t=>`<button class="chip" onclick="document.getElementById('search').value='${esc(t)}';renderProducts();document.getElementById('productArea').scrollIntoView({behavior:'smooth'})">${esc(t)}</button>`).join('')}</div>`:'';
  const rs=document.getElementById('reviewSlot');if(rs)rs.innerHTML=V.reviews.length?`<section class="brandstory"><div class="eyebrow muted">ĐÁNH GIÁ TỪ NGƯỜI ĐÃ MUA</div>${V.reviews.slice(0,3).map(r=>`<div class="review-card"><b>${'★'.repeat(r.rating)}</b> ${esc(r.title||'')}<div class="tiny">${esc(r.body)}</div><div class="tiny muted">${esc(r.reviewer)} · Đã mua hàng</div></div>`).join('')}</section>`:''}
window.vOutfit=id=>{const o=V.outfits.find(x=>x.id===id);if(!o)return;track('view_outfit',{id});V.of={o,rows:o.items.map(pid=>({pid,vi:0,size:''})).filter(r=>db.products.find(p=>p.id===r.pid))};drawOutfit()};
function drawOutfit(){const {o,rows}=V.of;let tot=0;
  modal(o.title,`<p class="tiny muted">${esc(o.description||'')}</p>${rows.map((r,i)=>{const p=db.products.find(x=>x.id===r.pid),v=p.variants[r.vi]||p.variants[0];tot+=price(p);const alts=db.products.filter(x=>x.category===p.category&&x.id!==p.id);
   return `<div class="cartitem" style="align-items:flex-start"><img src="${esc(productImg(p,v))}"><div style="flex:1"><b>${esc(p.name)}</b><div>${money(price(p))}</div><div class="row" style="gap:6px;margin-top:6px;flex-wrap:wrap"><select onchange="vOfV(${i},this.value)">${p.variants.map((x,k)=>`<option value="${k}" ${k===r.vi?'selected':''}>${esc(x.name)}</option>`).join('')}</select><select onchange="vOfS(${i},this.value)"><option value="">Chọn size</option>${(v?.sizes||[]).map(s=>`<option ${s.stock<=0?'disabled':''} ${r.size===s.name?'selected':''}>${esc(s.name)}</option>`).join('')}</select>${alts.length?`<select onchange="vOfSwap(${i},this.value)"><option value="">Đổi món…</option>${alts.map(a=>`<option value="${a.id}">${esc(a.name)}</option>`).join('')}</select>`:''}</div></div></div>`}).join('')}<div class="totalrow" style="font-size:18px"><b>Tổng bộ phối</b><b>${money(tot)}</b></div><button class="orange" style="width:100%" onclick="vOfAll()">Thêm cả bộ vào giỏ</button>`)}
window.vOfV=(i,v)=>{V.of.rows[i].vi=+v;V.of.rows[i].size='';drawOutfit()};window.vOfS=(i,s)=>{V.of.rows[i].size=s};window.vOfSwap=(i,id)=>{if(id){V.of.rows[i]={pid:id,vi:0,size:''};drawOutfit()}};
window.vOfAll=()=>{const miss=V.of.rows.find(r=>!r.size);if(miss){toast('Chọn size cho từng món trước nhé.');return}
  for(const r of V.of.rows){const p=db.products.find(x=>x.id===r.pid),v=p.variants[r.vi];if(stock(p,v,r.size)<=0){toast(p.name+' hết hàng ở size này.');return}}
  V.of.rows.forEach(r=>{const key=r.pid+'|'+r.vi+'|'+r.size,it=db.cart.find(x=>x.key===key);if(it)it.qty++;else db.cart.push({key,pid:r.pid,vi:r.vi,size:r.size,qty:1})});save();renderProducts();closeModal();toast('Đã thêm cả bộ vào giỏ')};

/* ---------- V6.4: luồng tài khoản / yêu thích / checkout an toàn ---------- */
const guestWishKey='verus_guest_wishlist_v1';
function guestWishRead(){try{return JSON.parse(localStorage.getItem(guestWishKey)||'[]').filter(x=>typeof x==='string')}catch(_){return []}}
function guestWishWrite(a){try{localStorage.setItem(guestWishKey,JSON.stringify([...new Set(a)]))}catch(_){} }
function wishMarkup(ids,guest){
  const items=ids.map(id=>db.products.find(p=>p.id===id)).filter(Boolean);
  return `<div class="tiny muted" style="margin-bottom:12px">${guest?'Danh sách lưu trên thiết bị này. Đăng nhập để đồng bộ giữa các thiết bị.':'Danh sách yêu thích của tài khoản.'}</div>`+
    (items.map(p=>`<div class="cartitem" style="align-items:center"><img src="${esc(productImg(p,p.variants?.[0]))}" alt="${esc(p.name)}"><div style="flex:1;min-width:0"><b>${esc(p.name)}</b><div class="tiny muted">${money(p.price)}</div><div class="row" style="gap:7px;margin-top:8px"><button class="outline" onclick="openProduct('${p.id}')">Xem sản phẩm</button><button class="outline" onclick="vWishToggle('${p.id}',true)">Bỏ yêu thích</button></div></div></div>`).join('')||'<div class="notice">Bạn chưa lưu sản phẩm nào. Hãy chạm biểu tượng ♡ trên ảnh sản phẩm.</div>');
}
const _vAccount64=window.vAccount;
window.vAccount=async function(){
  try{
    if(!V.online){
      db.orders=db.orders||[];db.customerProfile=db.customerProfile||{};const cp=db.customerProfile;
      const orders=db.orders.slice().sort((a,b)=>new Date(b.created)-new Date(a.created));const ids=guestWishRead();
      modal('TÀI KHOẢN CỦA TÔI',`<div class="notice"><b>CHẾ ĐỘ DEMO.</b> Tài khoản và lịch sử mua hàng chưa thể đồng bộ vì shop chưa cấu hình máy chủ. Đặt hàng đang bị khóa để tránh tạo đơn giả.</div><h3>THÔNG TIN KHÁCH HÀNG</h3><div class="field"><label>Họ và tên</label><input id="demoCustName" value="${esc(cp.name||'')}" placeholder="Tên của bạn"></div><div class="field"><label>Số điện thoại</label><input id="demoCustPhone" inputmode="tel" value="${esc(cp.phone||'')}" placeholder="0xxxxxxxxx"></div><button class="outline" onclick="saveDemoProfile()">LƯU THÔNG TIN TRÊN THIẾT BỊ</button><h3 style="margin-top:18px">YÊU THÍCH (${ids.length})</h3><div id="accountGuestWish">${wishMarkup(ids,true)}</div><h3 style="margin-top:18px">LỊCH SỬ MUA HÀNG (${orders.length})</h3>${orders.map(o=>`<div class="supportitem"><b>${esc(o.id)}</b><div class="tiny muted">${fd(o.created)} · ${money(o.total)}</div><button class="outline" onclick="vDemoOrder('${o.id}')">THEO DÕI ĐƠN DEMO</button></div>`).join('')||'<p class="muted">Chưa có đơn hàng. Đơn thật chỉ xuất hiện khi website được kết nối máy chủ.</p>'}<button class="orange" style="width:100%;margin-top:16px" onclick="closeModal();goAdmin()">QUẢN TRỊ SHOP (BẢN DEMO)</button>`);return;
    }
    if(V.online&&!V.session){
      const ids=guestWishRead();
      modal('TÀI KHOẢN CỦA TÔI',`<div class="notice">Bạn chưa đăng nhập. Đăng nhập hoặc tạo tài khoản để xem lịch sử mua hàng, địa chỉ và trạng thái đơn. Đơn hàng chỉ được ghi vào lịch sử sau khi đăng nhập và đặt hàng thành công.</div><div class="row" style="gap:8px;margin:12px 0"><button class="orange" style="flex:1" onclick="vAuth()">ĐĂNG NHẬP</button><button class="outline" style="flex:1" onclick="vAuth()">TẠO TÀI KHOẢN</button></div><h3>YÊU THÍCH (${ids.length})</h3><div id="accountGuestWish">${wishMarkup(ids,true)}</div><div class="tiny muted" style="margin-top:12px">Giỏ hàng không thay thế lịch sử mua hàng. Chưa có đơn nào được tạo.</div>`);return;
    }
    await _vAccount64();
    if(V.online&&V.session&&V.isStaff){document.getElementById('modalBody')?.insertAdjacentHTML('beforeend','<button class="orange" style="width:100%;margin-top:14px" onclick="closeModal();goAdmin()">MỞ TRANG QUẢN TRỊ SHOP</button>')}
  }catch(e){console.error(e);toast('Không mở được tài khoản: '+(e.message||'Lỗi tải dữ liệu. Vui lòng thử lại.'))}
};
window.vWish=async function(){
  try{
    if(!V.session){const ids=guestWishRead();modal('SẢN PHẨM YÊU THÍCH',wishMarkup(ids,true));return}
    const w=await q(V.sb.from('wishlist').select('product_id').eq('user_id',V.session.user.id));
    modal('SẢN PHẨM YÊU THÍCH',wishMarkup((w||[]).map(x=>x.product_id),false));
  }catch(e){console.error(e);toast('Không tải được danh sách yêu thích. Kiểm tra kết nối rồi thử lại.')}
};
window.vWishToggle=async function(pid,fromList){
  if(!V.session){let a=guestWishRead(),i=a.indexOf(pid);if(i>=0){a.splice(i,1);toast('Đã bỏ khỏi yêu thích')}else{a.push(pid);toast('Đã thêm vào yêu thích')}guestWishWrite(a);if(typeof renderProducts==='function')renderProducts();if(fromList)window.vWish();return}
  try{const ex=await q(V.sb.from('wishlist').select('product_id').eq('user_id',V.session.user.id).eq('product_id',pid));
    if(ex?.length){await q(V.sb.from('wishlist').delete().eq('user_id',V.session.user.id).eq('product_id',pid));toast('Đã bỏ khỏi yêu thích')}
    else{await q(V.sb.from('wishlist').insert({user_id:V.session.user.id,product_id:pid}));track('add_to_wishlist',{pid});toast('Đã thêm vào yêu thích')}
    if(typeof renderProducts==='function')renderProducts();if(fromList)vWish();
  }catch(e){console.error(e);toast('Không cập nhật được yêu thích: '+(e.message||'Vui lòng thử lại.'))}
};
// Không cho phép tạo đơn giả trong DEMO hoặc mua khi chưa đăng nhập.
const _checkout64=window.checkout;
window.checkout=async function(){
  if(!V.online){modal('CHƯA THỂ ĐẶT HÀNG',`<div class="notice"><b>Website hiện đang ở chế độ DEMO.</b> Chưa có đăng nhập, máy chủ lưu đơn hay quản trị đơn tập trung. Vì vậy VERUS STORE tạm khóa đặt hàng để tránh khách tưởng đơn đã gửi thành công.</div><p>Chủ shop cần cấu hình Supabase và kiểm tra đăng ký/đăng nhập trước khi mở bán thật.</p><button class="outline" style="width:100%" onclick="closeModal()">ĐÃ HIỂU</button>`);return}
  if(!V.session){toast('Vui lòng đăng nhập hoặc đăng ký trước khi đặt hàng.');vAuth('checkout');return}
  return _checkout64();
};
// Đồng bộ danh sách yêu thích khách lưu trước đăng nhập sau khi xác thực thành công.
async function mergeGuestWishlist(){if(!V.online||!V.session)return;const ids=guestWishRead();if(!ids.length)return;
  try{const existing=await q(V.sb.from('wishlist').select('product_id').eq('user_id',V.session.user.id));const have=new Set((existing||[]).map(x=>x.product_id));const add=ids.filter(id=>!have.has(id)&&db.products.some(p=>p.id===id));if(add.length)await q(V.sb.from('wishlist').insert(add.map(product_id=>({user_id:V.session.user.id,product_id}))));guestWishWrite([])}catch(e){console.warn('Guest wishlist merge deferred',e)}
}
const _vSignIn64=window.vSignIn;
window.vSignIn=async function(){await _vSignIn64();if(V.session)await mergeGuestWishlist()};
const _vSignUp64=window.vSignUp;
window.vSignUp=async function(){await _vSignUp64();if(V.session)await mergeGuestWishlist()};

/* ---------- V6.5 customer account dashboard ---------- */
(function(){
  const V = window.V;
  const readGuestWish = () => { try { return JSON.parse(localStorage.getItem('verus_guest_wishlist_v1') || '[]').filter(x => typeof x === 'string'); } catch (_) { return []; } };
  const writeGuestWish = a => { try { localStorage.setItem('verus_guest_wishlist_v1', JSON.stringify([...new Set(a)])); } catch (_) {} };
  const originalModal = window.modal;
  window.modal = function(title, html){
    originalModal(title, html);
    const box = document.querySelector('#modalbg .modal');
    if(box) box.classList.toggle('customer-dashboard-modal', !!document.getElementById('customerDashboard'));
  };
  const originalCloseModal = window.closeModal;
  window.closeModal = function(){
    document.querySelector('#modalbg .modal')?.classList.remove('customer-dashboard-modal');
    originalCloseModal();
  };
  const statusLabel = s => ({pending:'Chờ shop xác nhận',confirmed:'Shop đã xác nhận',sourcing:'Đang chuẩn bị hàng',supplier_ordered:'Đang xử lý đơn',in_transit_vn:'Đang vận chuyển',inspecting:'Đang kiểm tra hàng',shipping:'Đang giao hàng',delivered:'Đã giao thành công',return_requested:'Đang xử lý đổi trả',cancelled:'Đã hủy',refunded:'Đã hoàn tiền'}[s]||s||'Chưa cập nhật');
  const customerOrders = () => window.__customerData?.orders || [];
  const customerWishIds = () => window.__customerData?.wishIds || [];
  function nav(tab){
    const items=[['overview','Tổng quan','⌂'],['orders','Đơn hàng','▤'],['wishlist','Yêu thích','♡'],['profile','Hồ sơ cá nhân','♙'],['rewards','Điểm & VIP','♛']];
    return `<div class="customer-tabs" role="tablist">${items.map(([id,label,ico])=>`<button class="customer-tab ${window.__customerTab===id?'active':''}" role="tab" aria-selected="${window.__customerTab===id?'true':'false'}" onclick="vCustomerTab('${id}')"><span>${ico}</span>${label}${id==='orders'?`<small>${customerOrders().length}</small>`:''}</button>`).join('')}</div>`;
  }
  function productCard(p){return `<article class="customer-product"><img src="${esc(productImg(p,p.variants?.[0]))}" alt="${esc(p.name)}" onerror="this.style.opacity='.25'"><div class="customer-product-info"><b>${esc(p.name)}</b><strong>${money(p.price)}</strong><div class="customer-product-actions"><button class="outline" onclick="openProduct('${esc(p.id)}')">Xem sản phẩm</button><button class="outline" onclick="vCustomerRemoveWish('${esc(p.id)}')">Bỏ lưu</button></div></div></article>`}
  function orderCard(o){
    const online=!!window.__customerData?.online;
    const id=online?o.id:o.id;
    const code=online?(o.code||o.id):o.id;
    const created=online?o.created_at:o.created;
    const total=o.total||0;
    const status=online?o.status:o.status;
    const items=online?(o.order_items||[]).map(i=>`${esc(i.product_name||i.name||'Sản phẩm')} × ${i.qty}`).join(' · '):(o.items||[]).map(i=>`${esc(i.name)} × ${i.qty}`).join(' · ');
    return `<article class="customer-order"><div class="customer-order-top"><div><span class="customer-kicker">MÃ ĐƠN</span><b>${esc(code)}</b></div><span class="customer-status ${status==='delivered'?'is-done':''}">${esc(statusLabel(status))}</span></div><div class="customer-order-meta">${esc(window.vh.fd(created))} <span>·</span> <b>${money(total)}</b></div><p class="customer-order-items">${items||'Thông tin sản phẩm sẽ hiển thị khi tải được chi tiết đơn.'}</p><div class="customer-order-actions"><button class="outline" onclick="${online?`vOrder('${esc(id)}')`:`vDemoOrder('${esc(id)}')`}">Xem chi tiết đơn</button>${online&&status==='delivered'?`<button class="outline" onclick="vReviewPick('${esc(id)}')">Đánh giá sản phẩm</button>`:''}</div></article>`;
  }
  function vipBlock(){
    const d=window.__customerData||{},v=d.vip||{},tiers=v.tiers||[];
    const active=tiers.find(t=>t.code===v.active_tier)?.name||'Member';
    const spend=Number(v.spend_lifetime??v.lifetime_spend??v.spend_12m??0);
    const next=Number(v.next_threshold||0), remaining=Math.max(0,next-spend);
    const percent=next>0?Math.min(100,Math.round(spend/next*100)):100;
    const label=(v.spend_lifetime!=null||v.lifetime_spend!=null)?'Chi tiêu tích lũy trọn đời':'Chi tiêu được backend ghi nhận';
    return `<section class="customer-vip"><div class="customer-vip-top"><div><span class="customer-kicker">VERUS MEMBER CLUB</span><h3>Hạng ${esc(active)}</h3><p>${esc(label)}: <b>${money(spend)}</b></p></div><div class="customer-vip-icon">♛</div></div><div class="customer-vip-bar"><span style="width:${percent}%"></span></div><div class="customer-vip-foot">${next>0?`Còn <b>${money(remaining)}</b> để đạt ${esc(v.next_tier||'hạng tiếp theo')}`:'Bạn đang ở hạng cao nhất theo dữ liệu hiện có.'}</div>${v.spend_lifetime==null&&v.lifetime_spend==null&&d.online?'<p class="customer-data-note">Lưu ý: backend hiện tại trả về chi tiêu 12 tháng. Cần cập nhật logic VIP sang tổng chi tiêu tích lũy trọn đời theo yêu cầu của shop trước khi dùng dữ liệu này làm căn cứ chính thức.</p>':''}</section>`;
  }
  function overview(){
    const d=window.__customerData||{},pr=d.profile||{},orders=d.orders||[],wishes=d.wishIds||[],v=d.vip||{};
    const name=pr.full_name||pr.name||d.email||'Khách hàng VERUS';
    const points=Number(v.points||0);
    return `<div class="customer-welcome"><div><span class="customer-kicker">KHÔNG GIAN CỦA BẠN</span><h2>Xin chào, ${esc(name.split(' ')[0])}.</h2><p>Quản lý đơn hàng, sản phẩm yêu thích và quyền lợi thành viên tại một nơi.</p></div><div class="customer-avatar">${esc(name.trim().charAt(0).toUpperCase()||'V')}</div></div>
      ${!d.online?'<div class="customer-demo-note"><b>'+ (d.demo?'Chế độ DEMO':'Bạn chưa đăng nhập') +'</b> — '+ (d.demo?'Thông tin được lưu trên thiết bị này. Đồng bộ giữa thiết bị và đặt hàng thật chưa khả dụng khi Supabase chưa được cấu hình.':'Đăng nhập để xem lịch sử mua hàng, đồng bộ yêu thích và quyền lợi thành viên.') +'</div>':''}
      <div class="customer-stat-grid"><button class="customer-stat" onclick="vCustomerTab('orders')"><span>ĐƠN HÀNG</span><b>${orders.length}</b><small>Xem lịch sử mua</small></button><button class="customer-stat" onclick="vCustomerTab('wishlist')"><span>YÊU THÍCH</span><b>${wishes.length}</b><small>Sản phẩm đã lưu</small></button><button class="customer-stat" onclick="vCustomerTab('rewards')"><span>ĐIỂM THƯỞNG</span><b>${d.online?points.toLocaleString('vi-VN'):'—'}</b><small>${d.online?'Điểm hiện có':'Chưa khả dụng ở DEMO'}</small></button></div>
      ${d.online?vipBlock():'<section class="customer-vip customer-vip-demo"><span class="customer-kicker">VERUS MEMBER CLUB</span><h3>Khám phá quyền lợi thành viên</h3><p>Hạng VIP và điểm thưởng sẽ hiển thị sau khi cửa hàng kết nối máy chủ và đăng nhập tài khoản.</p><button class="outline" onclick="vAuth()">Đăng nhập / đăng ký</button></section>'}
      <div class="customer-section-head"><div><span class="customer-kicker">CẬP NHẬT GẦN ĐÂY</span><h3>Đơn hàng gần nhất</h3></div><button class="outline" onclick="vCustomerTab('orders')">Xem tất cả</button></div>
      ${orders.slice(0,3).map(orderCard).join('')||'<div class="customer-empty"><span>▤</span><b>Chưa có đơn hàng</b><p>Đơn hàng của bạn sẽ xuất hiện tại đây sau khi được tạo thành công.</p><button class="outline" onclick="closeModal();goStore();document.getElementById(\'productArea\')?.scrollIntoView({behavior:\'smooth\'})">Khám phá sản phẩm</button></div>'}`;
  }
  function ordersPage(){const os=customerOrders();return `<div class="customer-page-heading"><span class="customer-kicker">LỊCH SỬ MUA SẮM</span><h2>Đơn hàng của tôi</h2><p>Theo dõi trạng thái và xem lại chi tiết từng đơn.</p></div>${os.map(orderCard).join('')||'<div class="customer-empty"><span>▤</span><b>Chưa có đơn hàng nào</b><p>Khi bạn có đơn hàng, thông tin sẽ được lưu tại đây.</p><button class="outline" onclick="closeModal();goStore();document.getElementById(\'productArea\')?.scrollIntoView({behavior:\'smooth\'})">Mua sắm ngay</button></div>'}`}
  function wishlistPage(){const ps=customerWishIds().map(id=>db.products.find(p=>p.id===id)).filter(Boolean);return `<div class="customer-page-heading"><span class="customer-kicker">ĐÃ LƯU CHO LẦN SAU</span><h2>Sản phẩm yêu thích</h2><p>${ps.length} sản phẩm trong danh sách của bạn.</p></div>${ps.length?`<div class="customer-product-grid">${ps.map(productCard).join('')}</div>`:'<div class="customer-empty"><span>♡</span><b>Danh sách còn trống</b><p>Chạm biểu tượng trái tim ở sản phẩm để lưu những món bạn thích.</p><button class="outline" onclick="closeModal();goStore();document.getElementById(\'productArea\')?.scrollIntoView({behavior:\'smooth\'})">Tìm sản phẩm</button></div>'}`}
  function profilePage(){const d=window.__customerData||{},p=d.profile||{};return `<div class="customer-page-heading"><span class="customer-kicker">THÔNG TIN TÀI KHOẢN</span><h2>Hồ sơ cá nhân</h2><p>Giữ thông tin liên hệ chính xác để shop hỗ trợ đơn hàng tốt hơn.</p></div>${d.online?`<div class="customer-profile-card"><div class="field"><label>Email tài khoản</label><input value="${esc(d.email||'')}" disabled></div><div class="field"><label>Họ và tên</label><input id="customerName" value="${esc(p.full_name||'')}" autocomplete="name" placeholder="Nhập họ và tên"></div><div class="field"><label>Số điện thoại</label><input id="customerPhone" value="${esc(p.phone||'')}" inputmode="tel" autocomplete="tel" placeholder="0xxxxxxxxx"></div><label class="customer-checkbox"><input id="customerMarketing" type="checkbox" ${p.marketing_opt_in?'checked':''}> Tôi đồng ý nhận tin ưu đãi từ VERUS STORE.</label><button class="orange" onclick="vCustomerSaveProfile()">Lưu thay đổi</button></div>`:`<div class="customer-profile-card"><div class="customer-demo-note">Thông tin dưới đây chỉ lưu trên thiết bị này, không được gửi đến cửa hàng.</div><div class="field"><label>Họ và tên</label><input id="customerName" value="${esc(p.name||'')}" autocomplete="name" placeholder="Nhập họ và tên"></div><div class="field"><label>Số điện thoại</label><input id="customerPhone" value="${esc(p.phone||'')}" inputmode="tel" autocomplete="tel" placeholder="0xxxxxxxxx"></div><button class="orange" onclick="vCustomerSaveProfile()">Lưu trên thiết bị</button></div>`}`}
  function rewardsPage(){const d=window.__customerData||{};return `<div class="customer-page-heading"><span class="customer-kicker">VERUS MEMBER CLUB</span><h2>Điểm thưởng & hạng VIP</h2><p>Quyền lợi được tính theo quy tắc chương trình thành viên của cửa hàng.</p></div>${d.online?vipBlock():'<div class="customer-vip customer-vip-demo"><h3>Chưa có dữ liệu thành viên</h3><p>Điểm và hạng VIP cần tài khoản đăng nhập cùng kết nối máy chủ. Ở chế độ DEMO, hệ thống không giả lập số dư điểm.</p><button class="outline" onclick="vAuth()">Đăng nhập / đăng ký</button></div>'}<div class="customer-tier-grid">${(d.vip?.tiers||[{code:'member',name:'Member',min:0,mult:1,perks:['Tích điểm theo chương trình']},{code:'silver',name:'Silver',min:2000000,mult:1.1,perks:['Điểm x1.1']},{code:'gold',name:'Gold',min:5000000,mult:1.25,perks:['Ưu tiên xem bộ sưu tập mới']},{code:'diamond',name:'Diamond',min:12000000,mult:1.5,perks:['Chăm sóc ưu tiên']},{code:'royal',name:'Royal',min:30000000,mult:2,perks:['Quà theo hạng']}]).map(t=>`<article class="customer-tier"><span class="customer-kicker">${esc(t.code||'VIP')}</span><h3>${esc(t.name)}</h3><b>${money(t.min||0)}+</b><p>Hệ số điểm: ×${Number(t.mult||1).toLocaleString('vi-VN')}</p><ul>${(Array.isArray(t.perks)?t.perks:[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ul></article>`).join('')}</div><p class="customer-data-note">Mốc VIP hiển thị là cấu hình tham khảo trong bộ mã hiện tại. Trước khi mở bán, cần chốt chính thức quy tắc chi tiêu tích lũy trọn đời và chỉ tính đơn giao thành công, đồng thời xử lý đơn hoàn tiền.</p>`}
  function render(){
    const d=window.__customerData||{};let body='';
    if(window.__customerTab==='orders')body=ordersPage();else if(window.__customerTab==='wishlist')body=wishlistPage();else if(window.__customerTab==='profile')body=profilePage();else if(window.__customerTab==='rewards')body=rewardsPage();else body=overview();
    const name=d.profile?.full_name||d.profile?.name||d.email||'Khách hàng';
    modal('TÀI KHOẢN CỦA TÔI',`<div id="customerDashboard"><aside class="customer-side"><div class="customer-brand"><span class="customer-brand-mark">V<span>.</span></span><div><b>VERUS</b><small>STORE / ACCOUNT</small></div></div><div class="customer-side-user"><div class="customer-avatar">${esc(name.trim().charAt(0).toUpperCase()||'V')}</div><div><b>${esc(name)}</b><small>${esc(d.email|| (d.demo?'Chế độ DEMO':'Chưa đăng nhập'))}</small></div></div>${nav()}<div class="customer-side-bottom"><button class="outline" onclick="closeModal();goStore()">← Quay lại cửa hàng</button>${d.online?`<button class="customer-logout" onclick="vSignOut()">Đăng xuất</button>`:`<button class="orange" onclick="vAuth()">Đăng nhập / tạo tài khoản</button>`}</div></aside><main class="customer-main"><div class="customer-mobile-brand"><b>VERUS / TÀI KHOẢN</b><button class="outline" onclick="closeModal()">Đóng ✕</button></div>${body}<div class="customer-footer-note">VERUS STORE · YOUR STYLE. YOUR RULES.</div></main></div>`);
  }
  window.vCustomerTab=function(tab){window.__customerTab=tab;render()};
  window.vCustomerSaveProfile=async function(){
    const name=document.getElementById('customerName')?.value.trim()||'',phone=document.getElementById('customerPhone')?.value.trim()||'';
    if(!name){toast('Vui lòng nhập họ và tên.');return}if(phone&&!/^0\d{9}$/.test(phone)){toast('Số điện thoại cần 10 chữ số, bắt đầu bằng 0.');return}
    const d=window.__customerData||{};
    if(d.online){try{const {error}=await V.sb.from('profiles').update({full_name:name,phone:phone||null,marketing_opt_in:!!document.getElementById('customerMarketing')?.checked}).eq('id',V.session.user.id);if(error)throw error;V.profile=await V.sb.from('profiles').select('*').eq('id',V.session.user.id).single().then(r=>r.data).catch(()=>null);d.profile=V.profile||{full_name:name,phone};d.email=V.session.user.email;toast('Đã lưu hồ sơ.');render()}catch(e){console.error(e);toast('Chưa lưu được hồ sơ. Kiểm tra kết nối rồi thử lại.')}}
    else{db.customerProfile={...(db.customerProfile||{}),name,phone};save();d.profile=db.customerProfile;toast('Đã lưu trên thiết bị này.');render()}
  };
  window.vCustomerRemoveWish=async function(pid){const d=window.__customerData||{};if(d.online){try{const {error}=await V.sb.from('wishlist').delete().eq('user_id',V.session.user.id).eq('product_id',pid);if(error)throw error;d.wishIds=d.wishIds.filter(x=>x!==pid);toast('Đã bỏ khỏi yêu thích.');renderProducts();render()}catch(e){console.error(e);toast('Không cập nhật được yêu thích.')}}else{const ids=guestWishRead().filter(x=>x!==pid);guestWishWrite(ids);d.wishIds=ids;toast('Đã bỏ khỏi yêu thích.');renderProducts();render()}};
  window.vIsWished=function(pid){const d=window.__customerData||{};if(d.online&&Array.isArray(d.wishIds))return d.wishIds.includes(pid);try{return JSON.parse(localStorage.getItem('verus_guest_wishlist_v1')||'[]').includes(pid)}catch(_){return false}};
  window.vAccount=async function(){
    try{
      if(!V.online){
        // In DEMO mode there is no real auth server: show the customer dashboard with a clear setup notice instead of leaving the store unchanged.
        db.orders=db.orders||[];db.customerProfile=db.customerProfile||{};
        window.__customerData={demo:true,online:false,profile:db.customerProfile,orders:db.orders.slice().sort((a,b)=>new Date(b.created)-new Date(a.created)),wishIds:guestWishRead(),email:''};
        window.__customerTab='overview';render();return;
      }
      if(!V.session){vAuth();return}
      V.profile=await V.sb.from('profiles').select('*').eq('id',V.session.user.id).single().then(r=>r.data).catch(()=>null);
      V.isStaff=['staff','admin'].includes(V.profile?.role);V.isAdmin=V.profile?.role==='admin';
      V.vip=await V.sb.rpc('my_vip').then(r=>r.data).catch(()=>null);
      const [orders,wish]=await Promise.all([
        q(V.sb.from('orders').select('*, order_items(*)').eq('user_id',V.session.user.id).order('created_at',{ascending:false})),
        q(V.sb.from('wishlist').select('product_id').eq('user_id',V.session.user.id))
      ]);
      window.__customerData={demo:false,online:true,profile:V.profile||{},orders:orders||[],wishIds:(wish||[]).map(x=>x.product_id),vip:V.vip||{},email:V.session.user.email};window.__customerTab='overview';render();
    }catch(e){console.error(e);toast('Không tải được trang khách hàng. Kiểm tra kết nối rồi thử lại.')}
  };
  // Use the same customer dashboard and wishlist data source for the mobile dock.
  window.vWish=async function(){
    try{
      if(!V.session){const ids=guestWishRead();modal('SẢN PHẨM YÊU THÍCH',wishMarkup(ids,true));return}
      const w=await q(V.sb.from('wishlist').select('product_id').eq('user_id',V.session.user.id));
      modal('SẢN PHẨM YÊU THÍCH',wishMarkup((w||[]).map(x=>x.product_id),false));
    }catch(e){console.error(e);toast('Không tải được danh sách yêu thích. Kiểm tra kết nối rồi thử lại.')}
  };
})();


/* ---------- Khởi động ---------- */
async function boot(){
  const nav=document.querySelector('.nav'),cartBtn=[...nav.children].find(b=>/Giỏ hàng/.test(b.textContent));
  const acc=document.createElement('button');acc.id='accBtn';acc.textContent=V.online?'Đăng nhập':'Tài khoản';acc.onclick=()=>vAccount();nav.insertBefore(acc,cartBtn);
  if(cfg.SUPABASE_URL&&cfg.SUPABASE_ANON_KEY&&window.supabase){
    V.sb=window.supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY,{auth:{persistSession:true,autoRefreshToken:true}});V.online=true;
    db.orders=[];db.coupons=[];db.finance={received:[],withdrawals:[],bank:{}};
    try{db.cart=JSON.parse(localStorage.getItem('verus_cart_online')||'[]')}catch(e){db.cart=[]}
    window.save=function(){try{localStorage.setItem('verus_cart_online',JSON.stringify(db.cart))}catch(e){}const n=db.cart.reduce((a,x)=>a+x.qty,0);if(n>V.lastQty)track('add_to_cart',{n});V.lastQty=n;syncCart()};
    V.lastQty=db.cart.reduce((a,x)=>a+x.qty,0);
    const {data}=await V.sb.auth.getSession();V.session=data.session;
    V.sb.auth.onAuthStateChange((_e,s)=>{V.session=s;loadProfile().then(async()=>{navLabel();if(s){await mergeGuestWishlist();if(window.__customerData)window.vAccount()}})});
    await run(loadCatalog);await loadProfile();navLabel();
  }else{
    if(cfg.SUPABASE_URL&&!window.supabase)toast('Không tải được thư viện Supabase. Đang chạy chế độ DEMO.');
    demoInit();
  }
  banner();renderProducts();renderOutfits();renderEvent&&renderEvent();
  if(V.online&&V.settings?.policy_text)db.settings.policy=V.settings.policy_text;
  window.__vBootDone=true;document.dispatchEvent(new Event('verus-ready'));
}
document.addEventListener('DOMContentLoaded',boot);
})();
